"""Regression benchmarks for the integrated Code Atlas HTTP boundary module.

Benchmarks (all frozen earlier in this session):
  A. EngAIn EngAInOS <-> Godotsim: 8 expected matches, /dialogue/say unmatched, no Godotsim false match
  B. devpi static: 24 add_route, 47 view_config, 36 client call sites all accounted for
  C. devpi live run: every runtime request attributed to an outgoing record, methods agree,
     every server-logged path matches an extracted route
Run: python3 -I bench.py   (reads only; writes bench_result.json next to this file)
"""

import json
import os
import re
import sys
from urllib.parse import urlsplit

sys.path.insert(0, "/mnt/data-drive/code_atlas")
from code_atlas.core.http_boundaries import build_http_inventory  # noqa: E402
from code_atlas.core.boundary_matcher import match_boundaries  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ENGAIN = "/home/mytruelove/Desktop/burdens_of_a_forgotten_past/EngAIn"
DEVPI = os.path.join(HERE, "..", "devpi_test", "src", "devpi")
LIVE = os.path.join(HERE, "..", "devpi_live")
SKIP = {"__pycache__", "node_modules", ".git", ".venv", "venv", "build", "dist", "env"}  # same as the Atlas scanner
failures, out = [], {}


def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if detail else ""))
    if not ok:
        failures.append(name)


def py_files(root, subdirs):
    rels = []
    for sub in subdirs:
        for d, dirs, files in os.walk(os.path.join(root, sub)):
            dirs[:] = sorted(x for x in dirs if x not in SKIP)
            rels += [os.path.relpath(os.path.join(d, f), root).replace(os.sep, "/") for f in files if f.endswith(".py")]
    return rels


def by_prefix(mapping):
    return lambda rel: next((s for p, s in mapping.items() if rel.startswith(p + "/")), "other")


# ---- A. EngAIn
exp = json.load(open(os.path.join(HERE, "..", "http_proto", "expected.json")))
inv = build_http_inventory(ENGAIN, py_files(ENGAIN, ["tier1/engainos", "tier2/godotsim"]),
                           by_prefix({"tier1/engainos": "EngAInOS", "tier2/godotsim": "Godotsim"}))
res = match_boundaries([inv])["results"]
prod = [r for r in res if r["call"]["path_role"] == "production"]
matched = {(r["call"]["file"], r["call"]["method"], r["destination"]["path"]) for r in prod if r["outcome"] == "matched"}
want = {(e["client"], e["method"], e["path"]) for e in exp["should_match"]}
check("A1 all 8 expected EngAInOS->Godotsim matches", want <= matched, f"{len(want & matched)}/{len(want)}")
check("A2 no extra production matches", matched == want, str(sorted(matched - want)))
unm = {(r["call"]["file"], r["call"]["method"], r["destination"]["path"]) for r in prod if r["outcome"] == "unmatched"}
check("A3 /dialogue/say unmatched", unm == {(e["client"], e["method"], e["path"]) for e in exp["should_be_unmatched"]}, str(unm))
bad = [r for r in res if r["outcome"] in ("matched", "candidate")
       and any(s["system"] == "Godotsim" for s in r.get("servers", []))
       and (r["call"]["file"], r["call"]["method"], r["destination"]["path"]) not in want]
check("A4 no false match to Godotsim (incl. /health traps)", not bad, str([(b["call"]["file"], b["destination"]["path"]) for b in bad]))
out["engain"] = {"summary": match_boundaries([inv])["summary"], "coverage": inv["coverage_summary"]}

# ---- B. devpi static
dinv = build_http_inventory(DEVPI, py_files(DEVPI, ["server", "client"]),
                            by_prefix({"server": "server", "client": "client"}))
cov = dinv["coverage"]
n_decl = sum(1 for c in cov if c["detail"] == "add_route declaration")
n_view = sum(1 for c in cov if c["detail"].startswith("view_config for route"))
check("B1 24 add_route declarations interpreted", n_decl == 24, str(n_decl))
check("B2 47 view_config handlers linked to routes", n_view == 47, str(n_view))
dexp = json.load(open(os.path.join(HERE, "expected_devpi.json")))["client_call_sites"]["sites"]
client_cov = {(c["file"].replace("client/devpi/", ""), c["line"]): c["status"] for c in cov
              if c["side"] == "client" and c["file"].startswith("client/devpi/")}
missing = [s for s in dexp if (s.split(":")[0], int(s.split(":")[1])) not in client_cov]
check("B3 all 36 client call sites have a coverage entry", not missing, str(missing))
silent = [s for s in dexp if client_cov.get((s.split(":")[0], int(s.split(":")[1]))) == "not-interpreted"]
check("B4 none of the 36 is left not-interpreted", not silent, str(silent))
mirror_gap = [c for c in cov if c["file"] == "server/devpi_server/mirror.py" and c["status"] == "not-interpreted"]
check("B5 mirror.py async_get reported per call site", any("async_get" in c["detail"] for c in mirror_gap),
      str([(c["line"], c["detail"]) for c in mirror_gap]))
out["devpi_static"] = {"coverage": dinv["coverage_summary"],
                       "imports_only": dinv["files_importing_http_without_operations"]}

# ---- C. devpi live
reqs = [json.loads(l) for l in open(os.path.join(LIVE, "client_requests.jsonl")) if l.strip()]
sites = {}
for o in dinv["outgoing"]:
    if o["file"].startswith("client/devpi/") and o["path_role"] == "production":
        sites.setdefault((o["file"].replace("client/", "", 1), o["line"]), []).append(o)
missed, mism, observed = [], [], set()
for r in reqs:
    hit = [k for k in reversed([(f["file"], f["line"]) for f in r["frames"]]) if k in sites][:1]
    if not hit:
        missed.append((r["label"], r["method"], urlsplit(r["url"]).path))
        continue
    observed.add(hit[0])
    mism += [(hit[0], o["method"], r["method"]) for o in sites[hit[0]] if o["method"] and o["method"] != r["method"]]
check("C1 every runtime request attributed to an outgoing record", not missed, str(missed))
check("C2 static method agrees with runtime method", not mism, str(mism))
server_lines = re.findall(r"\[req\d+\] (\w+) (\S+)", open(os.path.join(LIVE, "server.log")).read())
routes = [x for x in dinv["incoming"] if x["file"].startswith("server/") and x["path_role"] == "production"]
no_route = [(m, p) for m, p in server_lines if not any(
    x["method"] in ("ANY", m) and (re.fullmatch(x["regex"], p.split("?")[0]) or re.fullmatch(x["regex"], p.split("?")[0] + "/"))
    for x in routes)]
check("C3 every server-logged request matches an extracted route", not no_route, str(no_route))
out["devpi_live"] = {"requests": len(reqs), "observed_sites": len(observed), "static_sites": len(sites),
                     "identified_not_run": len(set(sites) - observed)}

json.dump(out, open(os.path.join(HERE, "bench_result.json"), "w"), indent=2)
print(f"\n{len(failures)} failure(s)")
sys.exit(1 if failures else 0)
