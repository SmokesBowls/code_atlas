# Code Atlas Component Relationship Report: EngAIn

**Scanned at:** 2026-11-13T15:06:40.208227Z

## 1. Project Overview
- **Total Files Scanned:** 727
- **Source Defects (Python parser rejected the file):** 1
- **Files Atlas Could Not Read (analysis limitation):** 0
- **Unresolved Imports (analysis limitation, no edge recorded):** 18
- **Detected Entrypoints:** start_button.py, engainos_boot_kernel.py, tier1/mrlore/mrlore_control_center.py, tier1/mrlore/mrlore_scene_intake_runner.py, tier1/mrlore/mrlore_claim_extraction_runner.py, tier1/mrlore/mrlore_proposed_claim_shape_gate.py, tier1/mrlore/mrlore_proposed_claim_audit_summary.py, tier1/mrlore/mrlore_high_claim_scene_review_manifest.py, tier1/mrlore/mrlore_contradiction_candidate_grouper.py, tier1/mrlore/mrlore_contradiction_candidate_audit_summary.py, tier1/mrlore/mrlore_review_queue_builder.py, tier1/mrlore/mrlore_review_queue_noise_audit.py, tier1/mrlore/mrlore_review_queue_clean_view.py, tier1/mrlore/mrlore_review_rail_health_runner.py, tier1/mrlore/mrlore_manual_review_decision_schema.py, tier1/mrlore/mrlore_manual_review_decision_example_writer.py, tier1/mrlore/mrlore_entity_candidate_quality_gate.py, tier1/mrlore/mrlore_quality_aware_review_queue_builder.py, tier1/mrlore/mrlore_quality_aware_queue_summary.py, tier1/mrlore/mrlore_accepted_lore_packet_schema.py, tier1/mrlore/mrlore_preserve_entity_allowlist_registry_gate.py, tier1/mrlore/mrlore_temporal_claim_context_enrichment.py, tier1/mrlore/mrlore_temporal_collision_classification.py, tier1/mrlore/mrlore_temporal_aware_review_queue_builder.py, tier1/mrlore/mrlore_temporal_aware_queue_summary.py, tier1/mrlore/mrlore_temporal_aware_review_by_chapter_view.py, tier1/mrlore/mrlore_predicate_collision_policy_registry_gate.py, tier1/mrlore/mrlore_p3_sequential_entity_second_pass_quality_audit.py, tier1/mrlore/mrlore_coming_calendar_registry_gate.py, tier1/mrlore/mrlore_cosmic_year_context_enrichment.py, tier1/mrlore/mrlore_revision_breathing_map.py, tier1/mrlore/mrlore_revision_breathing_map_guidance_gate.py, tier1/mrlore/mrlore_major_event_internal_receipt_map.py, tier1/mrlore/evidence/proofs/phase_4/collect_delta.py, tier1/mrlore/archive/old_tools/mrlore_session.py, tier1/mrlore/archive/old_tools/lint_wiki.py, tier1/mrlore/archive/old_tools/write_changed_manifest.py, tier1/mrlore/archive/old_tools/propose_corrections.py, tier1/mrlore/archive/old_tools/continuity_audit.py, tier1/mrlore/archive/old_tools/mrlore_run_changed.py, tier1/mrlore/archive/old_tools/build_codex_candidates.py, tier1/mrlore/archive/old_tools/lint_codex_candidates.py, tier1/mrlore/archive/old_tools/promotion_eligibility_gate.py, tier1/mrlore/archive/old_tools/promote_candidate.py, tier1/mrlore/archive/old_tools/lint_relationship_schema.py, tier1/mrlore/archive/old_tools/populate_registry.py, tier1/mrlore/archive/old_tools/extract_member_of.py, tier1/mrlore/archive/old_tools/propose_rel_summaries.py, tier1/mrlore/archive/old_tools/propose_rel_source_stubs.py, tier1/mrlore/archive/old_tools/draft_rel_evidence_review.py, tier1/mrlore/archive/old_tools/stb_scanner.py, tier1/mrlore/archive/old_tools/build_registry.py, tier1/mrlore/archive/old_tools/stb_lint.py, tier1/mrlore/archive/old_tools/extract_candidates.py, tier1/mrlore/archive/old_tools/ollama_ingest_cockpit.py, tier1/mrlore/archive/old_tools/compile_entity_states.py, tier1/mrlore/archive/old_tools/chapter_ledger_extractor.py, tier1/mrlore/archive/old_tools/identity_signal_math.py, tier1/mrlore/archive/old_tools/provisional_identity_router.py, tier1/mrlore/archive/old_tools/identity_review_queue.py, tier1/mrlore/archive/old_tools/artifact_extractor.py, tier1/mrlore/archive/old_tools/pass2_math.py, tier1/mrlore/archive/old_tools/registry_builder.py, tier1/mrlore/archive/old_tools/identity_reviewer.py, tier1/mrlore/archive/old_tools/mrlore_query.py, tier1/mrlore/archive/old_tools/lint_scene_contract.py, tier1/mrlore/archive/old_tools/lint_entity_contract.py, tier1/mrlore/archive/old_tools/authority_score_calculator.py, tier1/mrlore/archive/old_tools/ingest_source_stub.py, tier1/mrlore/archive/old_tools/mrlore_rebuild_findings.py, tier1/mrlore/tools/mrlore_full_output_dump.py, tier1/engainos/launch_engine.py, tier1/engainos/engainos_control_center.py, tier1/engainos/engainos_server.py, tier1/engainos/gates/gate_ap_core_migration_authority.py, tier1/engainos/gates/gate_ap_core_behavior_parity.py, tier1/engainos/gates/gate_ap_core_signature_probe.py, tier1/engainos/gates/gate_ap_core_rule_activation.py, tier1/engainos/gates/gate_ap_engine_migration_authority.py, tier1/engainos/gates/gate_ap_engine_historical_probe.py, tier1/engainos/gates/gate_ap_engine_historical_source_map.py, tier1/engainos/gates/gate_ap_zw_engine_migration.py, tier1/engainos/gates/gate_ap_runtime_repair_readiness.py, tier1/engainos/gates/gate_ap_runtime_behavior_probe.py, tier1/engainos/gates/run_active_gates.py, tier1/engainos/gates/gate_ap_runtime_blocker_lane.py, tier1/engainos/gates/gate_server_runtime_preflight_lane.py, tier1/engainos/gates/gate_server_entrypoint_repair_lane.py, tier1/engainos/gates/gate_safe_server_wrapper_blueprint_lane.py, tier1/engainos/gates/gate_controlled_runtime_salvage_lane.py, tier1/engainos/gates/gate_vault_boot_side_effect_fence_lane.py, tier1/engainos/gates/gate_gamestate_draft_review_ready.py, tier1/engainos/gates/gate_ap_default_rules_registered.py, tier1/engainos/gates/gate_ap_zw_engine_timeline_fence.py, tier1/engainos/gates/gate_ap_zw_engine_canonical_claim.py, tier1/engainos/gates/gate_ap_runtime_relay_readiness.py, tier1/engainos/gates/gate_ap_runtime_relay_behavior.py, tier1/engainos/gates/gate_ap_runtime_relay_real_integration.py, tier1/engainos/gates/gate_governance_contract_board.py, tier1/engainos/gates/gate_gamestate_draft_review_contract.py, tier1/engainos/gates/gate_safe_server_wrapper_implementation_lane.py, tier1/engainos/gates/gate_safe_server_wrapper_behavior_lane.py, tier1/engainos/gates/gate_trixel32d_handshake.py, tier1/engainos/adapters/zonj_to_gamestate.py, tier1/engainos/core/no_godot_scene_proof.py, tier1/engainos/tests/test_trixel32d_request_assembler.py, tier1/engainos/tests/test_scene_loader_stageroom.py, tier1/engainos/server/presence_authority_server.py, tier1/engainos/aproom/ap_engine.py, tier1/engainos/aproom/ap_quest_rules.py, tier1/engainos/aproom/ap_rule_loader.py, tier1/engainos/aproom/ap_world_rules.py, tier1/engainos/aproom/engine_summary.py, tier1/engainos/aproom/protocol_envelope.py, tier1/engainos/aproom/ap_zw_engine.py, tier1/engainos/aproom/ap_runtime.py, tier1/engainos/bridgeroom/godot_adapter.py, tier1/engainos/bridgeroom/zon_to_game.py, tier1/engainos/bridgeroom/quest3d_integration.py, tier1/engainos/bridgeroom/scene_loader.py, tier1/engainos/bridgeroom/editor_edit_route.py, tier1/engainos/bridgeroom/scene_server.py, tier1/engainos/tools/vault_discovery.py, tier1/engainos/tools/chapter_discovery.py, tier1/engainos/tools/live_avatar_continuity_integration_proof.py, tier1/engainos/tools/live_hermes_continuity_proof.py, tier1/engainos/tools/live_claude_code_continuity_proof.py, tier1/engainos/tools/live_cross_provider_portability_proof.py, tier1/engainos/tools/live_cross_provider_mailbox_portability_proof.py, tier1/engainos/tools/live_dispatch_mutex_contention_proof.py, tier1/engainos/tools/live_journal_restart_proofs.py, tier1/engainos/tools/live_torn_tail_recovery_proof.py, tier1/engainos/tools/chapter_splitter/chapter_to_stage_packets.py, tier1/engainos/tools/chapter_splitter/promote_stage_draft.py, tier1/engainos/validators/runtime_stage_identity.py, tier1/engainos/validators/runtime_stage_manifest.py, tier1/paradox_machine/proofs/read_paradox_machine_gate_triad_result.py, tier1/paradox_machine/proofs/run_paradox_machine_gate_triad.py, tier1/paradox_machine/proofs/proof_008_spatiotemporal_gate_stub.py, tier1/paradox_machine/proofs/proof_007b_temporal_rejection.py, tier1/paradox_machine/proofs/proof_007_temporal_mvp.py, tier1/paradox_machine/proofs/export_gate_triad_result_zw.py, tier2/godotsim/scan_old_vault_paths.py, tier2/godotsim/scene_extractor.py, tier2/godotsim/test_bridge_entities_manifestation.py, tier2/godotsim/test_scene_load_handshake.py, tier2/godotsim/test_snapshot_ownership.py, tier2/godotsim/test_combat3d_adapter.py, tier2/godotsim/test_stageroom_scene_delivery.py, tier2/godotsim/test_gateway_combat_rules.py, tier2/godotsim/test_combat_commit.py, tier2/godotsim/sim_runtime.py, tier2/godotsim/test_snapshot_peek.py, tier2/godotsim/test_presentation_observation.py, tier2/godotsim/test_scene_provenance.py, tier2/godotsim/kernels/quest3d_mr.py, tier2/godotsim/kernels/navigation_mr.py, tier2/godotsim/kernels/perception_mr.py, tier2/godotsim/kernels/dialogue3d_mr.py, tier2/godotsim/kernels/inventory3d_mr.py, tier2/godotsim/adapters/navigation_adapter.py, tier2/godotsim/adapters/combat3d_integration.py, tier2/godotsim/adapters/spatial3d_adapter.py, tier2/godotsim/adapters/inventory3d_integration.py, tier2/godotsim/adapters/dialogue3d_integration.py, tier2/godotsim/gates/gate_piece3d_baseline.py, tier2/godotsim/gates/gate_floor_headless_parse_proof.py, tier2/godotsim/gates/gate_visible_floor_render_proof.py, tier2/godotsim/gates/gate_static_room_visible_proof.py, tier2/godotsim/gates/gate_player_body_visible_proof.py, tier2/godotsim/gates/gate_player_movement_proof.py, tier2/godotsim/gates/gate_player_movement_visible_observer_proof.py, tier2/godotsim/gates/gate_piece_recipe_pack_001_visible_proof.py, tier2/godotsim/gates/gate_piece_recipe_pack_002_door_proof.py, tier2/godotsim/gates/gate_ollama_diff_patcher_tests.py, tier2/godotsim/gates/gate_piece_recipe_pack_001.py, tier2/godotsim/gates/gate_trigger_zone_light_off_proof.py, tier2/godotsim/gates/gate_trigger_zone_multi_trigger_light_route_proof.py, tier2/engionality/engionality_control_center.py, tier2/engionality/controlroom/zon4d_kernel.py, tier2/engionality/controlroom/bootstrap.py, tier2/engionality/controlroom/performance_harness.py, tier2/topologist/classroom/run_topologist_classroom_probe.py, tier2/worldfield/world_field_nucleus.py, tier2/worldfield/terrain_thresholds.py, tier2/worldfield/trixel_world_adapter.py, tier2/worldfield/grid_facts_emitter.py, tier3/mettaext/engain_ingest.py, tier3/mettaext/narrative_to_game.py, tier3/mettaext/segmenter.py, tier3/mettaext/zwify_python.py, tier3/mettaext/zw_compiler.py, tier3/mettaext/pipeline_runner.py, tier3/mettaext/master_pipeline.py, tier3/mettaext/zw_world_rules_compiler.py, tier3/mettaext/run1time.py, tier3/mettaext/build_scene_index.py, tier3/mettaext/semantic_environment_extractor.py, tier3/mettaext/world_rules_loader.py, tier3/mettaext/stageroom_manifest.py, tier3/mettaext/passroom/pass2_event_builder.py, tier3/mettaext/passroom/pass1_explicit.py, tier3/mettaext/passroom/pass1_spatial.py, tier3/mettaext/passroom/pass3_merge.py, tier3/mettaext/passroom/pass2_enhanced.py, tier3/mettaext/passroom/pass4_zon_bridge.py, tier3/mettaext/passroom/pass5_game_bridge.py, tier3/mettaext/chapterroom/chapterroom_runner.py, tier3/mettaext/chapterroom/passA_chapter_intake.py, tier3/mettaext/chapterroom/chapterroom_index_runner.py, tier3/mettaext/chapterroom/passB5_environment_detector.py, tier3/mettaext/chapterroom/passB_scene_boundary_provider.py, tier3/mettaext/chapterroom/passC_scene_packet_writer.py, tier3/mettaext/vaultroom/vault_source_index.py, tier3/mettaext/tests/test_identity_hierarchy.py, tier3/mettaext/tests/test_entity_filter.py, tier3/mettaext/tests/test_metadata_leakage.py, tier3/mettaext/tests/test_manifest_scoping.py, tier3/mettaext/tests/test_orchestration_characterization.py, tier3/mettaext/tests/test_entity_evidence_lifecycle.py, tier3/mettaext/tests/test_scene_content_observations.py, tier3/mettaext/tests/test_pass3_pass4_entity_handoff.py, tier3/mettaext/tests/test_pattern4_participant_seeding.py, tier3/mettaext/tests/test_scene_local_manifestation.py, tier3/mettaext/tests/test_authored_scene_boundary_splitter.py, tier3/mettaext/tests/test_pattern1_physicality_attribution.py, tier3/mettaext/tests/test_authored_scene_markers_fenced_yaml.py, tier3/mettaext/tests/test_pass4_explicit_empty_entities.py, tier3/mettaextgen2/orchestrator.py, tier3/mettaextgen2/compare_legacy.py, tier3/mettaextgen2/corpus_runner.py, tier3/mettaextgen2/tests/test_gen2_scene_048_5.py, tier3/mettaextgen2/tests/test_gen2_units.py, tier3/mettaextgen2/tests/test_gen2_grammar.py, tools/ollama_diff_patcher.py, tools/stop_stack_safe.py, tools/gameproof/run_gameproof_001.py, tools/gameproof/run_gameproof_002.py, tools/gameproof/run_gameproof_003.py, tools/gameproof/run_gameproof_004.py, tools/gameproof/run_gameproof_005.py, tools/gameproof/run_gameproof_006.py, tools/gameproof/run_gameproof_007.py, tools/gameproof/run_gameproof_008.py, tools/passB_fix/passB_day_boundary_runner.py, tools/retired/ollama_patcher.py, scratch/gameproof_003/retired_cli_bridge/run_gameproof_003_cli.py, scratch/tier_relocation/trixel/legacy_payloads/harvest_legacy_trixel_payloads.py, gates/gate_engainos_bootstrap_preflight_v1.py, gates/gate_engainos_system_health_preflight_v1.py, gates/gate_boot_scene_authorization_request_v1.py, gates/gate_boot_scene_load_executor_request_v1.py, gates/gate_boot_shell_presentation_ready_v1.py, gates/gate_player_input_authorization_request_v1.py, gates/gate_player_input_listener_executor_request_v1.py, executors/boot_scene_load_executor_v1.py, executors/player_input_listener_executor_v1.py, executors/trixel32d_built_drop_intake_proof_v1.py, executors/trixel32d_request_loop_proof_v1.py, executors/trixel32d_complete_edge_loop_proof_v1.py, executors/trixel32d_apply_authorization_export_v1.py, executors/trixel32d_editor_handshake_proof_v1.py, interface/000_status.py, interface/010_show_protected_files.py, interface/020_show_ledger.py, interface/060_run_py_compile.py, interface/070_run_headless_gate.py, interface/080_stamp_result.py, interface/999_console.py, interface/030_create_task_packet.py, interface/040_show_next_command.py, interface/050_record_command_output.py, interface/090_recover_file_from_git.py, command_center/app.py, mechanimation/pose_editor.py, mechanimation/primeanim_v4a.py, mechanimation/pose_studio.py, out of root/okarchitect/okarchitect.py, out of root/okarchitect/okarchitect_v2.py, out of root/okarchitect/okarchitect_v2_fixed.py, out of root/okarchitect/okarchitect_v2_multiline_fix.py, out of root/okarchitect/okarchitect_v2_robust_input.py, out of root/gui/old_zw_gui_enhanced.py, out of root/gui/older_zw_gui_enhanced.py, out of root/gui/zw_gui.py, out of root/gui/official_zw_validator.py, out of root/gui/official_zw_spec_rules.py, out of root/gui/tests/test_gui_ux.py, out of root/gui/tests/test_tab_switch.py, out of root/gui/tests/test_gui_local_zonb_roundtrip.py, out of root/gui/cli/pack_zon.py, out of root/gui/cli/unpack_zon.py, out of root/gui/zw/zw_parser.py, out of root/gui/archive_gui/zw.py, out of root/gui/archive_gui/official_zw_validator.py, out of root/gui/archive_gui/official_zw_spec_rules.py, out of root/facade/facade_control_center.py, out of root/trae/trae-agent-main/evaluation/run_evaluation.py, out of root/trae/trae-agent-main/evaluation/patch_selection/analysis.py, out of root/trae/trae-agent-main/evaluation/patch_selection/selector.py, out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/execute_bash.py, out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/execute_str_replace_editor.py, out of root/trae/trae-agent-main/tests/test_cli.py, out of root/trae/trae-agent-main/tests/agent/test_trae_agent.py, out of root/trae/trae-agent-main/tests/tools/test_bash_tool.py, out of root/trae/trae-agent-main/tests/tools/test_edit_tool.py, out of root/trae/trae-agent-main/tests/tools/test_json_edit_tool.py, out of root/trae/trae-agent-main/tests/tools/test_mcp_tool.py, out of root/trae/trae-agent-main/tests/utils/test_config.py, out of root/trae/trae-agent-main/tests/utils/test_google_client.py, out of root/trae/trae-agent-main/tests/utils/test_mcp_client.py, out of root/trae/trae-agent-main/tests/utils/test_ollama_client_utils.py, out of root/trae/trae-agent-main/tests/utils/test_openrouter_client_utils.py, out of root/trae/trae-agent-main/trae_agent/cli.py, out of root/trae/trae-agent-main/trae_agent/tools/edit_tool_cli.py, out of root/trae/trae-agent-main/trae_agent/tools/json_edit_tool_cli.py, out of root/star_needle_toolbag_patch/blender_scripts/blender_entrypoint.py, out of root/star_needle_toolbag_patch/blender_scripts/blender_mcp_server.py, out of root/star_needle_toolbag_patch/blender_scripts/engain_git_mcp.py, out of root/tools/audit_godot_spawns.py, out of root/tools/patch_bridge_integration_upbge_coords_v1.py, out of root/tools/patch_sim_runtime_autorelink_v1.py, out of root/tools/patch_sim_runtime_autorelink_v2.py, out of root/tools/patch_sim_runtime_autorelink_v3.py, out of root/tools/patch_sim_runtime_autorelink_v3b.py, out of root/tools/patch_sim_runtime_bridge_entities.py, out of root/tools/patch_sim_runtime_bridge_entities_v1.py, out of root/tools/patch_upbge_bridge_use_position_v1.py, out of root/tools/patch_zonjrender_transforms_guard_v1.py, out of root/tools/upbge_list_logic_scripts.py, out of root/tools/scene_identity_audit.py, out of root/tools/rebuild_scene_cache.py, out of root/tools/proofroom/engionality_showroom/run_showroom_probe_suite.py, out of root/tools/proofroom/engionality_showroom/probe_scene_track.py, out of root/tools/proofroom/engionality_showroom/probe_performer_engine.py, out of root/tools/proofroom/engionality_showroom/probe_dialogue_engine.py, out of root/tools/proofroom/engionality_showroom/probe_audio_engine.py, out of root/tools/proofroom/engionality_showroom/probe_animation_engine.py, out of root/tools/proofroom/engionality_showroom/probe_domain_views.py, out of root/legacy2beused/blender/blender-open-mcp-main/addon.py, out of root/legacy2beused/blender/blender-open-mcp-main/main.py, out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/mcp_server.py, out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/server.py, out of root/legacy2beused/blender/blender-open-mcp-main/tests/test_addon.py, out of root/legacy2beused/blender/blender-open-mcp-main/tests/test_server.py, out of root/legacy2beused/blender_scripts/engain_blender_ops.py, engain_control/engain_master_control_center.py, tests/test_safe_stack_stop.py, mettaextgen2/corpus/build_gen2_corpus.py

### Status Distribution
- **Likely_active:** 636
- **Stubbed:** 18
- **Orphaned:** 38
- **Dormant:** 35
- **Unresolved:** 0
- **Active (Runtime Confirmed):** 0

## 2. Candidate Subsystem Groups
### Adapters Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 10
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/engainos/adapters, tier2/godotsim/adapters'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 12 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier1/engainos/adapters/zonj_to_gamestate.py`
  - `tier2/godotsim/adapters/__init__.py`
  - `tier2/godotsim/adapters/behavior_adapter.py`
  - `tier2/godotsim/adapters/combat3d_adapter.py`
  - `tier2/godotsim/adapters/combat3d_integration.py`
  - `tier2/godotsim/adapters/dialogue3d_integration.py`
  - `tier2/godotsim/adapters/inventory3d_integration.py`
  - `tier2/godotsim/adapters/navigation_adapter.py`
  - `tier2/godotsim/adapters/perception_adapter.py`
  - `tier2/godotsim/adapters/spatial3d_adapter.py`
- **Inbound Interface Files (3):**
  - `tier2/godotsim/runtime_core.py`
  - `tier2/godotsim/test_combat3d_adapter.py`
  - `tier2/godotsim/test_stageroom_scene_delivery.py`
- **Outbound Interface Files (9):**
  - `tier2/godotsim/kernels/behavior3d_mr.py`
  - `tier2/godotsim/kernels/combat3d_mr.py`
  - `tier2/godotsim/kernels/dialogue3d_mr.py`
  - `tier2/godotsim/kernels/inventory3d_mr.py`
  - `tier2/godotsim/kernels/perception_mr.py`
  - `tier2/godotsim/kernels/spatial3d_mr.py`
  - `tier2/godotsim/slice_builders.py`
  - `tier2/godotsim/slice_types.py`
  - `tier2/godotsim/spatial3d.py`

### Agent Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 6
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/trae/trae-agent-main/trae_agent/agent'
  - Internal cohesion: 9 internal dependency edges
  - Cross-group coupling: 19 external dependency edges
- **Member Files:**
  - `out of root/trae/trae-agent-main/trae_agent/agent/__init__.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/agent_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/base_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/docker_manager.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/trae_agent.py`
- **Inbound Interface Files (9):**
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/selector_agent.py`
  - `out of root/trae/trae-agent-main/tests/agent/test_trae_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/__init__.py`
  - `out of root/trae/trae-agent-main/trae_agent/cli.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/docker_tool_executor.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/cli/cli_console.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/cli/rich_console.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/cli/simple_console.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/lake_view.py`
- **Outbound Interface Files (10):**
  - `out of root/trae/trae-agent-main/trae_agent/prompt/agent_prompt.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg/ckg_database.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/docker_tool_executor.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/cli/cli_console.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/mcp_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py`

### Aproom Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 16
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/engainos/aproom'
  - Internal cohesion: 6 internal dependency edges
  - Cross-group coupling: 8 external dependency edges
- **Member Files:**
  - `tier1/engainos/aproom/ap_complex_rules.py`
  - `tier1/engainos/aproom/ap_core.py`
  - `tier1/engainos/aproom/ap_engine.py`
  - `tier1/engainos/aproom/ap_quest_rules.py`
  - `tier1/engainos/aproom/ap_rule_evaluator.py`
  - `tier1/engainos/aproom/ap_rule_loader.py`
  - `tier1/engainos/aproom/ap_runtime.py`
  - `tier1/engainos/aproom/ap_world_rules.py`
  - `tier1/engainos/aproom/ap_zw_engine.py`
  - `tier1/engainos/aproom/authority_gate.py`
  - `tier1/engainos/aproom/authority_validator.py`
  - `tier1/engainos/aproom/canon.py`
  - `tier1/engainos/aproom/contract_validator.py`
  - `tier1/engainos/aproom/engine_summary.py`
  - `tier1/engainos/aproom/protocol_envelope.py`
  - `tier1/engainos/aproom/reality_mode.py`
- **Inbound Interface Files (8):**
  - `tier1/engainos/engainos_server.py`
  - `tier1/engainos/launch_engine.py`
  - `tier2/godotsim/http_handlers.py`
  - `tier2/godotsim/runtime_core.py`
  - `tier2/godotsim/runtime_gateway.py`
  - `tier2/godotsim/test_combat_commit.py`
  - `tier2/godotsim/test_snapshot_peek.py`
  - `tier2/godotsim/test_stageroom_scene_delivery.py`
- **Outbound Interface Files (0):**

### Archive_gui Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 3
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/gui/archive_gui'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 1 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `out of root/gui/archive_gui/official_zw_spec_rules.py`
  - `out of root/gui/archive_gui/official_zw_validator.py`
  - `out of root/gui/archive_gui/zw.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (1):**
  - `out of root/gui/official_zw_validator.py`

### Artifactroom Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 5
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier2/cartographer/artifactroom, tier2/topologist/artifactroom'
  - Internal cohesion: 1 internal dependency edges
  - Cross-group coupling: 3 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier2/cartographer/artifactroom/__init__.py`
  - `tier2/cartographer/artifactroom/metric_layout_artifact.py`
  - `tier2/topologist/artifactroom/__init__.py`
  - `tier2/topologist/artifactroom/passroom_signal_converter.py`
  - `tier2/topologist/artifactroom/topology_artifact.py`
- **Inbound Interface Files (3):**
  - `tier2/cartographer/layoutroom/topology_metric_layout_solver.py`
  - `tier2/topologist/classroom/run_topologist_classroom_probe.py`
  - `tier2/topologist/reckoningroom/topology_validator.py`
- **Outbound Interface Files (0):**

### Authority Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 5
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/engainos/authority'
  - Internal cohesion: 2 internal dependency edges
  - Cross-group coupling: 17 external dependency edges
- **Member Files:**
  - `tier1/engainos/authority/editor_edit_authority.py`
  - `tier1/engainos/authority/local_signed_transport.py`
  - `tier1/engainos/authority/trixel32d_application_grant.py`
  - `tier1/engainos/authority/trixel32d_live_application_issuer.py`
  - `tier1/engainos/authority/trixel32d_live_authority_state.py`
- **Inbound Interface Files (14):**
  - `tier1/engainos/bridgeroom/editor_edit_route.py`
  - `tier1/engainos/bridgeroom/scene_server.py`
  - `tier1/engainos/bridgeroom/trixel32d_live_route.py`
  - `tier1/engainos/launch_engine.py`
  - `tier1/engainos/tests/test_editor_edit_authority.py`
  - `tier1/engainos/tests/test_editor_edit_mandates.py`
  - `tier1/engainos/tests/test_local_signed_transport.py`
  - `tier1/engainos/tests/test_trixel32d_live_application_issuer.py`
  - `tier1/engainos/tests/test_trixel32d_live_godot_integration.py`
  - `tier1/engainos/tests/test_trixel32d_live_route.py`
  - `tier1/engainos/tests/test_trixel32d_semantic_integration.py`
  - `tier2/godotsim/http_handlers.py`
  - `tier2/godotsim/presentation_observation.py`
  - `tier2/godotsim/test_presentation_observation.py`
- **Outbound Interface Files (3):**
  - `tier1/engainos/core/intent_shadow.py`
  - `tier1/engainos/gates/gate_trixel32d_handshake.py`
  - `tier1/engainos/gates/gate_trixel32d_surface_apply.py`

### Blender-open-mcp-main Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 3
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/legacy2beused/blender/blender-open-mcp-main'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 2 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `out of root/legacy2beused/blender/blender-open-mcp-main/addon.py`
  - `out of root/legacy2beused/blender/blender-open-mcp-main/blender_mcp_addon.py`
  - `out of root/legacy2beused/blender/blender-open-mcp-main/main.py`
- **Inbound Interface Files (1):**
  - `out of root/legacy2beused/blender/blender-open-mcp-main/tests/test_addon.py`
- **Outbound Interface Files (1):**
  - `out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/server.py`

### Blender_open_mcp Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 3
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp'
  - Internal cohesion: 1 internal dependency edges
  - Cross-group coupling: 2 external dependency edges
- **Member Files:**
  - `out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/__init__.py`
  - `out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/mcp_server.py`
  - `out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/server.py`
- **Inbound Interface Files (2):**
  - `out of root/legacy2beused/blender/blender-open-mcp-main/main.py`
  - `out of root/legacy2beused/blender/blender-open-mcp-main/tests/test_server.py`
- **Outbound Interface Files (0):**

### Blender_scripts Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 11
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/legacy2beused/blender_scripts, out of root/star_needle_toolbag_patch/blender_scripts'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `out of root/legacy2beused/blender_scripts/engain_blender_ops.py`
  - `out of root/star_needle_toolbag_patch/blender_scripts/blender_asgi.py`
  - `out of root/star_needle_toolbag_patch/blender_scripts/blender_entrypoint.py`
  - `out of root/star_needle_toolbag_patch/blender_scripts/blender_mcp_server.py`
  - `out of root/star_needle_toolbag_patch/blender_scripts/engain_git_mcp.py`
  - `out of root/star_needle_toolbag_patch/blender_scripts/engain_runtime_mcp.py`
  - `out of root/star_needle_toolbag_patch/blender_scripts/export_glb.py`
  - `out of root/star_needle_toolbag_patch/blender_scripts/list_objects.py`
  - `out of root/star_needle_toolbag_patch/blender_scripts/mcp_hub_asgi.py`
  - `out of root/star_needle_toolbag_patch/blender_scripts/render_still.py`
  - `out of root/star_needle_toolbag_patch/blender_scripts/runtime_asgi.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Bridgeroom Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 22
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/engainos/bridgeroom'
  - Internal cohesion: 17 internal dependency edges
  - Cross-group coupling: 40 external dependency edges
- **Member Files:**
  - `tier1/engainos/bridgeroom/claude_code_provider_adapter.py`
  - `tier1/engainos/bridgeroom/editor_edit_route.py`
  - `tier1/engainos/bridgeroom/godot_adapter.py`
  - `tier1/engainos/bridgeroom/hermes_provider_adapter.py`
  - `tier1/engainos/bridgeroom/mailbox_request_handler.py`
  - `tier1/engainos/bridgeroom/mesh_intake.py`
  - `tier1/engainos/bridgeroom/mesh_manifest.py`
  - `tier1/engainos/bridgeroom/quest3d_integration.py`
  - `tier1/engainos/bridgeroom/scene_loader.py`
  - `tier1/engainos/bridgeroom/scene_server.py`
  - `tier1/engainos/bridgeroom/semantic_bridge.py`
  - `tier1/engainos/bridgeroom/shared_session_bridge.py`
  - `tier1/engainos/bridgeroom/spatial_reasoner.py`
  - `tier1/engainos/bridgeroom/spatial_skin_system.py`
  - `tier1/engainos/bridgeroom/stageroom_scene_resolver.py`
  - `tier1/engainos/bridgeroom/trixel32d_built_drop_intake.py`
  - `tier1/engainos/bridgeroom/trixel32d_live_route.py`
  - `tier1/engainos/bridgeroom/trixel32d_request_assembler.py`
  - `tier1/engainos/bridgeroom/trixel32d_request_dispatch.py`
  - `tier1/engainos/bridgeroom/zon_bridge.py`
  - `tier1/engainos/bridgeroom/zon_to_entities.py`
  - `tier1/engainos/bridgeroom/zon_to_game.py`
- **Inbound Interface Files (26):**
  - `executors/trixel32d_built_drop_intake_proof_v1.py`
  - `executors/trixel32d_complete_edge_loop_proof_v1.py`
  - `executors/trixel32d_editor_handshake_proof_v1.py`
  - `executors/trixel32d_request_loop_proof_v1.py`
  - `tier1/engainos/launch_engine.py`
  - `tier1/engainos/server/presence_authority_server.py`
  - `tier1/engainos/tests/test_continuity_identity_boundary.py`
  - `tier1/engainos/tests/test_editor_edit_authority.py`
  - `tier1/engainos/tests/test_editor_edit_mandates.py`
  - `tier1/engainos/tests/test_hermes_provider_adapter_timeout.py`
  - `tier1/engainos/tests/test_mailbox_request_handler.py`
  - `tier1/engainos/tests/test_presence_authority_dispatch.py`
  - `tier1/engainos/tests/test_scene_loader_stageroom.py`
  - `tier1/engainos/tests/test_shared_session_continuity_proof.py`
  - `tier1/engainos/tests/test_trixel32d_built_drop_intake.py`
  - `tier1/engainos/tests/test_trixel32d_complete_edge_transport.py`
  - `tier1/engainos/tests/test_trixel32d_live_godot_integration.py`
  - `tier1/engainos/tests/test_trixel32d_live_route.py`
  - `tier1/engainos/tests/test_trixel32d_request_assembler.py`
  - `tier1/engainos/tests/test_trixel32d_request_dispatch.py`
  - `tier1/engainos/tests/test_trixel32d_semantic_integration.py`
  - `tier1/engainos/tools/live_claude_code_continuity_proof.py`
  - `tier1/engainos/tools/live_cross_provider_mailbox_portability_proof.py`
  - `tier1/engainos/tools/live_cross_provider_portability_proof.py`
  - `tier1/engainos/tools/live_hermes_continuity_proof.py`
  - `tier2/godotsim/test_stageroom_scene_delivery.py`
- **Outbound Interface Files (14):**
  - `tier1/engainos/authority/editor_edit_authority.py`
  - `tier1/engainos/authority/local_signed_transport.py`
  - `tier1/engainos/authority/trixel32d_application_grant.py`
  - `tier1/engainos/authority/trixel32d_live_application_issuer.py`
  - `tier1/engainos/authority/trixel32d_live_authority_state.py`
  - `tier1/engainos/core/continuity_context_builder.py`
  - `tier1/engainos/core/continuity_cursor_tracker.py`
  - `tier1/engainos/core/presence_registry.py`
  - `tier1/engainos/core/provider_session_binding.py`
  - `tier1/engainos/core/session_ledger.py`
  - `tier1/engainos/gates/gate_trixel32d_handshake.py`
  - `tier2/godotsim/kernels/combat3d_mr.py`
  - `tier2/godotsim/kernels/quest3d_mr.py`
  - `tier3/mettaext/scene_identity.py`

### Builders Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier2/godotsim/builders'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 7 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier2/godotsim/builders/godot_scene_piece_builder.py`
- **Inbound Interface Files (6):**
  - `tier2/godotsim/gates/gate_piece_recipe_pack_001_visible_proof.py`
  - `tier2/godotsim/gates/gate_piece_recipe_pack_002_door_proof.py`
  - `tier2/godotsim/gates/gate_player_body_visible_proof.py`
  - `tier2/godotsim/gates/gate_player_movement_proof.py`
  - `tier2/godotsim/gates/gate_player_movement_visible_observer_proof.py`
  - `tier2/godotsim/gates/gate_static_room_visible_proof.py`
- **Outbound Interface Files (1):**
  - `tier2/godotsim/kernels/piece3d_mr.py`

### Cartographer Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier2/cartographer'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tier2/cartographer/__init__.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Chapter_splitter Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/engainos/tools/chapter_splitter'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tier1/engainos/tools/chapter_splitter/chapter_to_stage_packets.py`
  - `tier1/engainos/tools/chapter_splitter/promote_stage_draft.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Chapterroom Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 8
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier3/mettaext/chapterroom'
  - Internal cohesion: 7 internal dependency edges
  - Cross-group coupling: 6 external dependency edges
- **Member Files:**
  - `tier3/mettaext/chapterroom/__init__.py`
  - `tier3/mettaext/chapterroom/chapterroom_bridge.py`
  - `tier3/mettaext/chapterroom/chapterroom_index_runner.py`
  - `tier3/mettaext/chapterroom/chapterroom_runner.py`
  - `tier3/mettaext/chapterroom/passA_chapter_intake.py`
  - `tier3/mettaext/chapterroom/passB5_environment_detector.py`
  - `tier3/mettaext/chapterroom/passB_scene_boundary_provider.py`
  - `tier3/mettaext/chapterroom/passC_scene_packet_writer.py`
- **Inbound Interface Files (6):**
  - `tier3/mettaext/tests/test_authored_scene_boundary_splitter.py`
  - `tier3/mettaext/tests/test_authored_scene_markers_fenced_yaml.py`
  - `tier3/mettaext/tests/test_identity_hierarchy.py`
  - `tier3/mettaext/tests/test_metadata_leakage.py`
  - `tier3/mettaext/tests/test_orchestration_characterization.py`
  - `tools/gameproof/run_gameproof_003.py`
- **Outbound Interface Files (0):**

### Ckg Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/trae/trae-agent-main/trae_agent/tools/ckg'
  - Internal cohesion: 1 internal dependency edges
  - Cross-group coupling: 3 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg/base.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg/ckg_database.py`
- **Inbound Interface Files (2):**
  - `out of root/trae/trae-agent-main/trae_agent/agent/base_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg_tool.py`
- **Outbound Interface Files (1):**
  - `out of root/trae/trae-agent-main/trae_agent/utils/constants.py`

### Classroom Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier2/topologist/classroom'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 2 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier2/topologist/classroom/run_topologist_classroom_probe.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (2):**
  - `tier2/topologist/artifactroom/topology_artifact.py`
  - `tier2/topologist/reckoningroom/topology_validator.py`

### Cli Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 7
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/gui/cli, out of root/trae/trae-agent-main/trae_agent/utils/cli'
  - Internal cohesion: 9 internal dependency edges
  - Cross-group coupling: 4 external dependency edges
- **Member Files:**
  - `out of root/gui/cli/pack_zon.py`
  - `out of root/gui/cli/unpack_zon.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/cli/__init__.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/cli/cli_console.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/cli/console_factory.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/cli/rich_console.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/cli/simple_console.py`
- **Inbound Interface Files (1):**
  - `out of root/trae/trae-agent-main/trae_agent/agent/agent.py`
- **Outbound Interface Files (3):**
  - `out of root/trae/trae-agent-main/trae_agent/agent/agent_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/lake_view.py`

### Codecs Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/paradox_machine/codecs'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tier1/paradox_machine/codecs/__init__.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Command_center Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'command_center'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `command_center/app.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Controlroom Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 7
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier2/engionality/controlroom'
  - Internal cohesion: 4 internal dependency edges
  - Cross-group coupling: 13 external dependency edges
- **Member Files:**
  - `tier2/engionality/controlroom/__init__.py`
  - `tier2/engionality/controlroom/bootstrap.py`
  - `tier2/engionality/controlroom/performance_harness.py`
  - `tier2/engionality/controlroom/runtime_loop.py`
  - `tier2/engionality/controlroom/task_system_merged.py`
  - `tier2/engionality/controlroom/task_types.py`
  - `tier2/engionality/controlroom/zon4d_kernel.py`
- **Inbound Interface Files (11):**
  - `out of root/tools/proofroom/engionality_showroom/probe_animation_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_audio_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_dialogue_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_performer_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_scene_track.py`
  - `out of root/tools/proofroom/engionality_showroom/showroom_fake_env.py`
  - `tier2/engionality/showroom/animation_engine.py`
  - `tier2/engionality/showroom/audio_engine.py`
  - `tier2/engionality/showroom/dialogue_engine.py`
  - `tier2/engionality/showroom/performer_engine.py`
  - `tier2/engionality/showroom/scene_track.py`
- **Outbound Interface Files (2):**
  - `tier2/engionality/showroom/domain_views.py`
  - `tier2/engionality/showroom/performer_engine.py`

### Core Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 17
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/core, tier1/engainos/core'
  - Internal cohesion: 3 internal dependency edges
  - Cross-group coupling: 35 external dependency edges
- **Member Files:**
  - `out of root/core/__init__.py`
  - `out of root/core/zw_core.py`
  - `tier1/engainos/core/__init__.py`
  - `tier1/engainos/core/combat3d_mr.py`
  - `tier1/engainos/core/continuity_context_builder.py`
  - `tier1/engainos/core/continuity_cursor_tracker.py`
  - `tier1/engainos/core/history_xeon.py`
  - `tier1/engainos/core/intent_shadow.py`
  - `tier1/engainos/core/no_godot_scene_proof.py`
  - `tier1/engainos/core/presence_registry.py`
  - `tier1/engainos/core/provider_session_binding.py`
  - `tier1/engainos/core/quest3d_mr.py`
  - `tier1/engainos/core/replay.py`
  - `tier1/engainos/core/session_claim_registry.py`
  - `tier1/engainos/core/session_journal.py`
  - `tier1/engainos/core/session_ledger.py`
  - `tier1/engainos/core/zw_core.py`
- **Inbound Interface Files (32):**
  - `out of root/gui/zw_gui.py`
  - `tier1/engainos/authority/editor_edit_authority.py`
  - `tier1/engainos/bridgeroom/claude_code_provider_adapter.py`
  - `tier1/engainos/bridgeroom/hermes_provider_adapter.py`
  - `tier1/engainos/bridgeroom/mailbox_request_handler.py`
  - `tier1/engainos/bridgeroom/shared_session_bridge.py`
  - `tier1/engainos/gates/gate_ap_default_rules_registered.py`
  - `tier1/engainos/gates/gate_ap_zw_engine_timeline_fence.py`
  - `tier1/engainos/server/presence_authority_server.py`
  - `tier1/engainos/tests/test_continuity_context_builder.py`
  - `tier1/engainos/tests/test_continuity_cursor_tracker.py`
  - `tier1/engainos/tests/test_continuity_identity_boundary.py`
  - `tier1/engainos/tests/test_editor_edit_authority.py`
  - `tier1/engainos/tests/test_editor_edit_mandates.py`
  - `tier1/engainos/tests/test_hermes_provider_adapter_timeout.py`
  - `tier1/engainos/tests/test_mailbox_request_handler.py`
  - `tier1/engainos/tests/test_presence_authority_dispatch.py`
  - `tier1/engainos/tests/test_presence_authority_server.py`
  - `tier1/engainos/tests/test_provider_session_binding.py`
  - `tier1/engainos/tests/test_session_claim_registry.py`
  - `tier1/engainos/tests/test_session_journal.py`
  - `tier1/engainos/tests/test_session_ledger.py`
  - `tier1/engainos/tests/test_session_ledger_persistence.py`
  - `tier1/engainos/tests/test_shared_session_continuity_proof.py`
  - `tier1/engainos/tools/live_claude_code_continuity_proof.py`
  - `tier1/engainos/tools/live_cross_provider_mailbox_portability_proof.py`
  - `tier1/engainos/tools/live_cross_provider_portability_proof.py`
  - `tier1/engainos/tools/live_hermes_continuity_proof.py`
  - `tier1/engainos/tools/live_journal_restart_proofs.py`
  - `tier1/engainos/tools/live_torn_tail_recovery_proof.py`
  - `tier2/godotsim/http_handlers.py`
  - `tier2/godotsim/runtime_gateway.py`
- **Outbound Interface Files (3):**
  - `out of root/gui/zw/zw_parser.py`
  - `tier2/godotsim/kernels/combat3d_mr.py`
  - `tier2/godotsim/kernels/quest3d_mr.py`

### Corpus Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'mettaextgen2/corpus'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `mettaextgen2/corpus/build_gen2_corpus.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Engain Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/engain'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `out of root/engain/__init__.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Engain_control Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 6
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'engain_control, out of root/archive/ENGIONALITY_switch_experiment_20260617/engain_control'
  - Internal cohesion: 2 internal dependency edges
  - Cross-group coupling: 41 external dependency edges
- **Member Files:**
  - `engain_control/__init__.py`
  - `engain_control/engain_master_control_center.py`
  - `engain_control/gate_print.py`
  - `engain_control/gate_result.py`
  - `out of root/archive/ENGIONALITY_switch_experiment_20260617/engain_control/control_report.py`
  - `out of root/archive/ENGIONALITY_switch_experiment_20260617/engain_control/permit_decision.py`
- **Inbound Interface Files (41):**
  - `out of root/archive/ENGIONALITY_switch_experiment_20260617/engionality_permit_resolver.py`
  - `out of root/facade/facade_control_center.py`
  - `out of root/facade/gates/gate_facade_rejection_proof.py`
  - `out of root/facade/gates/gate_legacy_wrapped_not_replaced.py`
  - `out of root/facade/gates/gate_migration_status_honest.py`
  - `out of root/facade/gates/gate_no_render_truth_mixed.py`
  - `out of root/facade/gates/gate_no_runtime_entrypoint_import.py`
  - `out of root/facade/gates/gate_no_side_effect_imports.py`
  - `out of root/facade/gates/gate_packet_identity.py`
  - `out of root/facade/gates/gate_packet_shape_boundary.py`
  - `out of root/facade/gates/gate_safe_import_contract.py`
  - `tier1/engainos/engainos_control_center.py`
  - `tier1/engainos/gates/gate_acceptance_rule.py`
  - `tier1/engainos/gates/gate_declared_truth_shape.py`
  - `tier1/engainos/gates/gate_governance_rejection_proof.py`
  - `tier1/engainos/gates/gate_no_asset_production.py`
  - `tier1/engainos/gates/gate_no_lane_theft_in_packet.py`
  - `tier1/engainos/gates/gate_no_presentation_authority.py`
  - `tier1/engainos/gates/gate_no_simulation_execution.py`
  - `tier1/engainos/gates/gate_packet_identity.py`
  - `tier1/engainos/gates/gate_validated_packets_shape.py`
  - `tier1/mrlore/gates/gate_claims_structure.py`
  - `tier1/mrlore/gates/gate_contradiction_stop_proof.py`
  - `tier1/mrlore/gates/gate_contradictions_valid_if_present.py`
  - `tier1/mrlore/gates/gate_enum_values_valid.py`
  - `tier1/mrlore/gates/gate_human_review_enforcement.py`
  - `tier1/mrlore/gates/gate_no_auto_resolve_attempt.py`
  - `tier1/mrlore/gates/gate_no_lane_theft_in_packet.py`
  - `tier1/mrlore/gates/gate_no_vault_path_dependency.py`
  - `tier1/mrlore/gates/gate_required_fields.py`
  - `tier1/mrlore/mrlore_control_center.py`
  - `tier2/engionality/engionality_control_center.py`
  - `tier2/engionality/gates/gate_affect_packet_relationships.py`
  - `tier2/engionality/gates/gate_affect_state_valid.py`
  - `tier2/engionality/gates/gate_hard_rejects.py`
  - `tier2/engionality/gates/gate_intensity_bounds.py`
  - `tier2/engionality/gates/gate_no_lane_theft_in_packet.py`
  - `tier2/engionality/gates/gate_no_legacy_imports.py`
  - `tier2/engionality/gates/gate_relationship_deltas_valid_if_present.py`
  - `tier2/engionality/gates/gate_required_fields.py`
  - `tier2/engionality/gates/gate_scene_mood_valid_if_present.py`
- **Outbound Interface Files (0):**

### Engainos Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 5
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/engainos'
  - Internal cohesion: 1 internal dependency edges
  - Cross-group coupling: 19 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier1/engainos/__init__.py`
  - `tier1/engainos/engainos_control_center.py`
  - `tier1/engainos/engainos_server.py`
  - `tier1/engainos/launch_engine.py`
  - `tier1/engainos/runtime_client.py`
- **Inbound Interface Files (1):**
  - `tier1/engainos/archive/retired_agents/trae_observer.py`
- **Outbound Interface Files (18):**
  - `engain_control/gate_print.py`
  - `tier1/engainos/aproom/ap_engine.py`
  - `tier1/engainos/aproom/ap_runtime.py`
  - `tier1/engainos/aproom/authority_gate.py`
  - `tier1/engainos/authority/trixel32d_live_authority_state.py`
  - `tier1/engainos/bridgeroom/editor_edit_route.py`
  - `tier1/engainos/bridgeroom/godot_adapter.py`
  - `tier1/engainos/bridgeroom/scene_server.py`
  - `tier1/engainos/bridgeroom/trixel32d_live_route.py`
  - `tier1/engainos/gates/gate_acceptance_rule.py`
  - `tier1/engainos/gates/gate_declared_truth_shape.py`
  - `tier1/engainos/gates/gate_governance_rejection_proof.py`
  - `tier1/engainos/gates/gate_no_asset_production.py`
  - `tier1/engainos/gates/gate_no_lane_theft_in_packet.py`
  - `tier1/engainos/gates/gate_no_presentation_authority.py`
  - `tier1/engainos/gates/gate_no_simulation_execution.py`
  - `tier1/engainos/gates/gate_packet_identity.py`
  - `tier1/engainos/gates/gate_validated_packets_shape.py`

### Engionality Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion, refined_by: coordinator_outbound_concentration
- **Evidence:**
  - Files share directory structure: 'tier2/engionality'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 7 external dependency edges
  - Coordinator cohesion: explicitly named control center emits 7/7 outbound edges (100.0%); internal dependency edges are not required
- **Member Files:**
  - `tier2/engionality/__init__.py`
  - `tier2/engionality/engionality_control_center.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (7):**
  - `engain_control/gate_print.py`
  - `tier2/engionality/gates/gate_affect_state_valid.py`
  - `tier2/engionality/gates/gate_intensity_bounds.py`
  - `tier2/engionality/gates/gate_no_lane_theft_in_packet.py`
  - `tier2/engionality/gates/gate_relationship_deltas_valid_if_present.py`
  - `tier2/engionality/gates/gate_required_fields.py`
  - `tier2/engionality/gates/gate_scene_mood_valid_if_present.py`

### Engionality_showroom Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 9
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/tools/proofroom/engionality_showroom'
  - Internal cohesion: 6 internal dependency edges
  - Cross-group coupling: 7 external dependency edges
- **Member Files:**
  - `out of root/tools/proofroom/engionality_showroom/__init__.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_animation_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_audio_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_dialogue_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_domain_views.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_performer_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_scene_track.py`
  - `out of root/tools/proofroom/engionality_showroom/run_showroom_probe_suite.py`
  - `out of root/tools/proofroom/engionality_showroom/showroom_fake_env.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (7):**
  - `tier2/engionality/controlroom/task_types.py`
  - `tier2/engionality/showroom/animation_engine.py`
  - `tier2/engionality/showroom/audio_engine.py`
  - `tier2/engionality/showroom/dialogue_engine.py`
  - `tier2/engionality/showroom/domain_views.py`
  - `tier2/engionality/showroom/performer_engine.py`
  - `tier2/engionality/showroom/scene_track.py`

### Engionality_switch_experiment_20260617 Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/archive/ENGIONALITY_switch_experiment_20260617'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 1 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `out of root/archive/ENGIONALITY_switch_experiment_20260617/engionality_permit_resolver.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (1):**
  - `engain_control/__init__.py`

### Evaluation Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 3
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/trae/trae-agent-main/evaluation'
  - Internal cohesion: 1 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `out of root/trae/trae-agent-main/evaluation/__init__.py`
  - `out of root/trae/trae-agent-main/evaluation/run_evaluation.py`
  - `out of root/trae/trae-agent-main/evaluation/utils.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Executors Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 7
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'executors'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 7 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `executors/boot_scene_load_executor_v1.py`
  - `executors/player_input_listener_executor_v1.py`
  - `executors/trixel32d_apply_authorization_export_v1.py`
  - `executors/trixel32d_built_drop_intake_proof_v1.py`
  - `executors/trixel32d_complete_edge_loop_proof_v1.py`
  - `executors/trixel32d_editor_handshake_proof_v1.py`
  - `executors/trixel32d_request_loop_proof_v1.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (7):**
  - `tier1/engainos/bridgeroom/trixel32d_built_drop_intake.py`
  - `tier1/engainos/bridgeroom/trixel32d_request_dispatch.py`
  - `tier1/engainos/gates/gate_trixel32d_handshake.py`
  - `tier1/engainos/gates/gate_trixel32d_surface_apply.py`
  - `tier1/engainos/tests/test_trixel32d_built_drop_intake.py`
  - `tier1/engainos/tests/test_trixel32d_complete_edge_transport.py`
  - `tier1/engainos/tests/test_trixel32d_surface_apply.py`

### Extraction Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/paradox_machine/extraction'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 2 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier1/paradox_machine/extraction/__init__.py`
  - `tier1/paradox_machine/extraction/naive_temporal_extractor.py`
- **Inbound Interface Files (1):**
  - `tier1/paradox_machine/proofs/proof_007_temporal_mvp.py`
- **Outbound Interface Files (1):**
  - `tier1/paradox_machine/schemas/temporal_artifact.py`

### Facade Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion, refined_by: coordinator_outbound_concentration
- **Evidence:**
  - Files share directory structure: 'out of root/facade'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 10 external dependency edges
  - Coordinator cohesion: explicitly named control center emits 10/10 outbound edges (100.0%); internal dependency edges are not required
- **Member Files:**
  - `out of root/facade/__init__.py`
  - `out of root/facade/facade_control_center.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (10):**
  - `engain_control/gate_print.py`
  - `out of root/facade/gates/gate_facade_rejection_proof.py`
  - `out of root/facade/gates/gate_legacy_wrapped_not_replaced.py`
  - `out of root/facade/gates/gate_migration_status_honest.py`
  - `out of root/facade/gates/gate_no_render_truth_mixed.py`
  - `out of root/facade/gates/gate_no_runtime_entrypoint_import.py`
  - `out of root/facade/gates/gate_no_side_effect_imports.py`
  - `out of root/facade/gates/gate_packet_identity.py`
  - `out of root/facade/gates/gate_packet_shape_boundary.py`
  - `out of root/facade/gates/gate_safe_import_contract.py`

### Files Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/legacy2beused/blender/Imports/files'
  - Internal cohesion: 1 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `out of root/legacy2beused/blender/Imports/files/engain_bge_bridge.py`
  - `out of root/legacy2beused/blender/Imports/files/engain_controller.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Gameproof Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 8
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tools/gameproof'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 9 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tools/gameproof/run_gameproof_001.py`
  - `tools/gameproof/run_gameproof_002.py`
  - `tools/gameproof/run_gameproof_003.py`
  - `tools/gameproof/run_gameproof_004.py`
  - `tools/gameproof/run_gameproof_005.py`
  - `tools/gameproof/run_gameproof_006.py`
  - `tools/gameproof/run_gameproof_007.py`
  - `tools/gameproof/run_gameproof_008.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (9):**
  - `tier1/mrlore/gates/gate_narrative_concurrence.py`
  - `tier1/mrlore/mrlore_narrative_concurrence_checker.py`
  - `tier2/cartographer/gates/gate_propose_metric_layout.py`
  - `tier2/cartographer/layoutroom/topology_metric_layout_solver.py`
  - `tier2/cartographer/reckoningroom/metric_layout_validator.py`
  - `tier2/topologist/gates/gate_accept_proposed_topology_artifact.py`
  - `tier3/mettaext/chapterroom/chapterroom_bridge.py`
  - `tier3/mettaext/passroom/pass1_spatial.py`
  - `tier3/mettaext/passroom/passroom_bridge.py`

### Gates Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 96
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'gates, out of root/facade/gates, tier1/engainos/gates, tier1/mrlore/gates, tier1/paradox_machine/gates, tier2/cartographer/gates, tier2/engionality/gates, tier2/godotsim/gates, tier2/topologist/gates'
  - Internal cohesion: 19 internal dependency edges
  - Cross-group coupling: 35 external dependency edges
- **Member Files:**
  - `gates/gate_boot_scene_authorization_request_v1.py`
  - `gates/gate_boot_scene_load_executor_request_v1.py`
  - `gates/gate_boot_shell_presentation_ready_v1.py`
  - `gates/gate_engainos_bootstrap_preflight_v1.py`
  - `gates/gate_engainos_system_health_preflight_v1.py`
  - `gates/gate_player_input_authorization_request_v1.py`
  - `gates/gate_player_input_listener_executor_request_v1.py`
  - `out of root/facade/gates/__init__.py`
  - `out of root/facade/gates/gate_facade_rejection_proof.py`
  - `out of root/facade/gates/gate_legacy_wrapped_not_replaced.py`
  - `out of root/facade/gates/gate_migration_status_honest.py`
  - `out of root/facade/gates/gate_no_render_truth_mixed.py`
  - `out of root/facade/gates/gate_no_runtime_entrypoint_import.py`
  - `out of root/facade/gates/gate_no_side_effect_imports.py`
  - `out of root/facade/gates/gate_packet_identity.py`
  - `out of root/facade/gates/gate_packet_shape_boundary.py`
  - `out of root/facade/gates/gate_safe_import_contract.py`
  - `tier1/engainos/gates/__init__.py`
  - `tier1/engainos/gates/gate_acceptance_rule.py`
  - `tier1/engainos/gates/gate_ap_core_behavior_parity.py`
  - `tier1/engainos/gates/gate_ap_core_migration_authority.py`
  - `tier1/engainos/gates/gate_ap_core_rule_activation.py`
  - `tier1/engainos/gates/gate_ap_core_signature_probe.py`
  - `tier1/engainos/gates/gate_ap_default_rules_registered.py`
  - `tier1/engainos/gates/gate_ap_engine_historical_probe.py`
  - `tier1/engainos/gates/gate_ap_engine_historical_source_map.py`
  - `tier1/engainos/gates/gate_ap_engine_migration_authority.py`
  - `tier1/engainos/gates/gate_ap_runtime_behavior_probe.py`
  - `tier1/engainos/gates/gate_ap_runtime_blocker_lane.py`
  - `tier1/engainos/gates/gate_ap_runtime_relay_behavior.py`
  - `tier1/engainos/gates/gate_ap_runtime_relay_readiness.py`
  - `tier1/engainos/gates/gate_ap_runtime_relay_real_integration.py`
  - `tier1/engainos/gates/gate_ap_runtime_repair_readiness.py`
  - `tier1/engainos/gates/gate_ap_zw_engine_canonical_claim.py`
  - `tier1/engainos/gates/gate_ap_zw_engine_migration.py`
  - `tier1/engainos/gates/gate_ap_zw_engine_timeline_fence.py`
  - `tier1/engainos/gates/gate_controlled_runtime_salvage_lane.py`
  - `tier1/engainos/gates/gate_declared_truth_shape.py`
  - `tier1/engainos/gates/gate_gamestate_draft_review_contract.py`
  - `tier1/engainos/gates/gate_gamestate_draft_review_ready.py`
  - `tier1/engainos/gates/gate_governance_contract_board.py`
  - `tier1/engainos/gates/gate_governance_rejection_proof.py`
  - `tier1/engainos/gates/gate_no_asset_production.py`
  - `tier1/engainos/gates/gate_no_lane_theft_in_packet.py`
  - `tier1/engainos/gates/gate_no_presentation_authority.py`
  - `tier1/engainos/gates/gate_no_simulation_execution.py`
  - `tier1/engainos/gates/gate_packet_identity.py`
  - `tier1/engainos/gates/gate_safe_server_wrapper_behavior_lane.py`
  - `tier1/engainos/gates/gate_safe_server_wrapper_blueprint_lane.py`
  - `tier1/engainos/gates/gate_safe_server_wrapper_implementation_lane.py`
  - `tier1/engainos/gates/gate_server_entrypoint_repair_lane.py`
  - `tier1/engainos/gates/gate_server_runtime_preflight_lane.py`
  - `tier1/engainos/gates/gate_trixel32d_handshake.py`
  - `tier1/engainos/gates/gate_trixel32d_surface_apply.py`
  - `tier1/engainos/gates/gate_validated_packets_shape.py`
  - `tier1/engainos/gates/gate_vault_boot_side_effect_fence_lane.py`
  - `tier1/engainos/gates/run_active_gates.py`
  - `tier1/mrlore/gates/__init__.py`
  - `tier1/mrlore/gates/gate_claims_structure.py`
  - `tier1/mrlore/gates/gate_contradiction_stop_proof.py`
  - `tier1/mrlore/gates/gate_contradictions_valid_if_present.py`
  - `tier1/mrlore/gates/gate_enum_values_valid.py`
  - `tier1/mrlore/gates/gate_human_review_enforcement.py`
  - `tier1/mrlore/gates/gate_narrative_concurrence.py`
  - `tier1/mrlore/gates/gate_no_auto_resolve_attempt.py`
  - `tier1/mrlore/gates/gate_no_lane_theft_in_packet.py`
  - `tier1/mrlore/gates/gate_no_vault_path_dependency.py`
  - `tier1/mrlore/gates/gate_required_fields.py`
  - `tier1/paradox_machine/gates/__init__.py`
  - `tier1/paradox_machine/gates/temporal_gate.py`
  - `tier2/cartographer/gates/__init__.py`
  - `tier2/cartographer/gates/gate_propose_metric_layout.py`
  - `tier2/engionality/gates/gate_affect_packet_relationships.py`
  - `tier2/engionality/gates/gate_affect_state_valid.py`
  - `tier2/engionality/gates/gate_hard_rejects.py`
  - `tier2/engionality/gates/gate_intensity_bounds.py`
  - `tier2/engionality/gates/gate_no_lane_theft_in_packet.py`
  - `tier2/engionality/gates/gate_no_legacy_imports.py`
  - `tier2/engionality/gates/gate_relationship_deltas_valid_if_present.py`
  - `tier2/engionality/gates/gate_required_fields.py`
  - `tier2/engionality/gates/gate_scene_mood_valid_if_present.py`
  - `tier2/godotsim/gates/gate_floor_headless_parse_proof.py`
  - `tier2/godotsim/gates/gate_ollama_diff_patcher_tests.py`
  - `tier2/godotsim/gates/gate_piece3d_baseline.py`
  - `tier2/godotsim/gates/gate_piece_recipe_pack_001.py`
  - `tier2/godotsim/gates/gate_piece_recipe_pack_001_visible_proof.py`
  - `tier2/godotsim/gates/gate_piece_recipe_pack_002_door_proof.py`
  - `tier2/godotsim/gates/gate_player_body_visible_proof.py`
  - `tier2/godotsim/gates/gate_player_movement_proof.py`
  - `tier2/godotsim/gates/gate_player_movement_visible_observer_proof.py`
  - `tier2/godotsim/gates/gate_static_room_visible_proof.py`
  - `tier2/godotsim/gates/gate_trigger_zone_light_off_proof.py`
  - `tier2/godotsim/gates/gate_trigger_zone_multi_trigger_light_route_proof.py`
  - `tier2/godotsim/gates/gate_visible_floor_render_proof.py`
  - `tier2/topologist/gates/__init__.py`
  - `tier2/topologist/gates/gate_accept_proposed_topology_artifact.py`
- **Inbound Interface Files (27):**
  - `executors/trixel32d_apply_authorization_export_v1.py`
  - `executors/trixel32d_built_drop_intake_proof_v1.py`
  - `executors/trixel32d_complete_edge_loop_proof_v1.py`
  - `executors/trixel32d_editor_handshake_proof_v1.py`
  - `executors/trixel32d_request_loop_proof_v1.py`
  - `out of root/facade/facade_control_center.py`
  - `tier1/engainos/authority/trixel32d_live_application_issuer.py`
  - `tier1/engainos/authority/trixel32d_live_authority_state.py`
  - `tier1/engainos/bridgeroom/trixel32d_built_drop_intake.py`
  - `tier1/engainos/bridgeroom/trixel32d_request_assembler.py`
  - `tier1/engainos/bridgeroom/trixel32d_request_dispatch.py`
  - `tier1/engainos/engainos_control_center.py`
  - `tier1/engainos/tests/test_gamestate_authority.py`
  - `tier1/engainos/tests/test_trixel32d_apply_authorization_export.py`
  - `tier1/engainos/tests/test_trixel32d_built_drop_intake.py`
  - `tier1/engainos/tests/test_trixel32d_complete_edge_transport.py`
  - `tier1/engainos/tests/test_trixel32d_handshake.py`
  - `tier1/engainos/tests/test_trixel32d_live_application_issuer.py`
  - `tier1/engainos/tests/test_trixel32d_surface_apply.py`
  - `tier1/engainos/tests/test_trixel32d_ticket_a_dual_slab.py`
  - `tier1/mrlore/mrlore_control_center.py`
  - `tier1/paradox_machine/proofs/proof_007_temporal_mvp.py`
  - `tier1/paradox_machine/proofs/proof_007b_temporal_rejection.py`
  - `tier2/engionality/engionality_control_center.py`
  - `tools/gameproof/run_gameproof_006.py`
  - `tools/gameproof/run_gameproof_007.py`
  - `tools/gameproof/run_gameproof_008.py`
- **Outbound Interface Files (8):**
  - `engain_control/gate_result.py`
  - `tier1/engainos/core/__init__.py`
  - `tier1/engainos/relays/ap_runtime_relay.py`
  - `tier1/paradox_machine/reasoning/temporal_validator.py`
  - `tier1/paradox_machine/schemas/temporal_artifact.py`
  - `tier2/godotsim/builders/godot_scene_piece_builder.py`
  - `tier2/godotsim/kernels/piece3d_mr.py`
  - `tools/ollama_diff_patcher.py`

### Godotsim Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 23
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier2/godotsim'
  - Internal cohesion: 27 internal dependency edges
  - Cross-group coupling: 33 external dependency edges
- **Member Files:**
  - `tier2/godotsim/__init__.py`
  - `tier2/godotsim/blender_mcp_bridge.py`
  - `tier2/godotsim/bridge_integration.py`
  - `tier2/godotsim/combat3d_mr.py`
  - `tier2/godotsim/command_dispatcher.py`
  - `tier2/godotsim/embodiment_contract_builder.py`
  - `tier2/godotsim/engain_hooks.py`
  - `tier2/godotsim/environment_manager.py`
  - `tier2/godotsim/http_handlers.py`
  - `tier2/godotsim/presentation_observation.py`
  - `tier2/godotsim/protocol_envelope.py`
  - `tier2/godotsim/runtime_core.py`
  - `tier2/godotsim/runtime_gateway.py`
  - `tier2/godotsim/scan_old_vault_paths.py`
  - `tier2/godotsim/scene_extractor.py`
  - `tier2/godotsim/scene_manager.py`
  - `tier2/godotsim/semantic_bridge.py`
  - `tier2/godotsim/sim_runtime.py`
  - `tier2/godotsim/slice_builders.py`
  - `tier2/godotsim/slice_types.py`
  - `tier2/godotsim/spatial3d.py`
  - `tier2/godotsim/spatial_skin_system.py`
  - `tier2/godotsim/vault_manager.py`
- **Inbound Interface Files (17):**
  - `out of root/engain/kernels/navigation.py`
  - `out of root/engain/kernels/perception.py`
  - `out of root/engain/kernels/spatial.py`
  - `out of root/engain/semantic/extraction.py`
  - `tier1/engainos/tests/test_trixel32d_semantic_integration.py`
  - `tier2/godotsim/adapters/navigation_adapter.py`
  - `tier2/godotsim/adapters/spatial3d_adapter.py`
  - `tier2/godotsim/test_bridge_entities_manifestation.py`
  - `tier2/godotsim/test_combat_commit.py`
  - `tier2/godotsim/test_gateway_combat_rules.py`
  - `tier2/godotsim/test_presentation_observation.py`
  - `tier2/godotsim/test_scene_load_handshake.py`
  - `tier2/godotsim/test_scene_provenance.py`
  - `tier2/godotsim/test_slice_builders.py`
  - `tier2/godotsim/test_snapshot_ownership.py`
  - `tier2/godotsim/test_snapshot_peek.py`
  - `tier2/godotsim/test_stageroom_scene_delivery.py`
- **Outbound Interface Files (16):**
  - `tier1/engainos/aproom/ap_complex_rules.py`
  - `tier1/engainos/aproom/authority_gate.py`
  - `tier1/engainos/aproom/canon.py`
  - `tier1/engainos/aproom/reality_mode.py`
  - `tier1/engainos/authority/local_signed_transport.py`
  - `tier1/engainos/core/intent_shadow.py`
  - `tier2/godotsim/adapters/behavior_adapter.py`
  - `tier2/godotsim/adapters/combat3d_adapter.py`
  - `tier2/godotsim/adapters/dialogue3d_integration.py`
  - `tier2/godotsim/adapters/inventory3d_integration.py`
  - `tier2/godotsim/adapters/perception_adapter.py`
  - `tier2/godotsim/adapters/spatial3d_adapter.py`
  - `tier2/godotsim/kernels/behavior3d_mr.py`
  - `tier2/godotsim/kernels/perception_mr.py`
  - `tier2/godotsim/kernels/spatial3d_mr.py`
  - `tier3/mettaext/scene_identity.py`

### Gui Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 5
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/gui'
  - Internal cohesion: 4 internal dependency edges
  - Cross-group coupling: 7 external dependency edges
- **Member Files:**
  - `out of root/gui/official_zw_spec_rules.py`
  - `out of root/gui/official_zw_validator.py`
  - `out of root/gui/old_zw_gui_enhanced.py`
  - `out of root/gui/older_zw_gui_enhanced.py`
  - `out of root/gui/zw_gui.py`
- **Inbound Interface Files (4):**
  - `out of root/gui/archive_gui/official_zw_spec_rules.py`
  - `out of root/gui/tests/test_gui_local_zonb_roundtrip.py`
  - `out of root/gui/tests/test_gui_ux.py`
  - `out of root/gui/tests/test_tab_switch.py`
- **Outbound Interface Files (3):**
  - `out of root/gui/zon/zon_binary_pack.py`
  - `out of root/gui/zw/zw_parser.py`
  - `tier1/engainos/core/__init__.py`

### Interface Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 12
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'interface'
  - Internal cohesion: 10 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `interface/000_status.py`
  - `interface/010_show_protected_files.py`
  - `interface/020_show_ledger.py`
  - `interface/030_create_task_packet.py`
  - `interface/040_show_next_command.py`
  - `interface/050_record_command_output.py`
  - `interface/060_run_py_compile.py`
  - `interface/070_run_headless_gate.py`
  - `interface/080_stamp_result.py`
  - `interface/090_recover_file_from_git.py`
  - `interface/999_console.py`
  - `interface/interface_common.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Kernels Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 14
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/engain/kernels, tier2/godotsim/kernels'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 25 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `out of root/engain/kernels/__init__.py`
  - `out of root/engain/kernels/navigation.py`
  - `out of root/engain/kernels/perception.py`
  - `out of root/engain/kernels/spatial.py`
  - `tier2/godotsim/kernels/__init__.py`
  - `tier2/godotsim/kernels/behavior3d_mr.py`
  - `tier2/godotsim/kernels/combat3d_mr.py`
  - `tier2/godotsim/kernels/dialogue3d_mr.py`
  - `tier2/godotsim/kernels/inventory3d_mr.py`
  - `tier2/godotsim/kernels/navigation_mr.py`
  - `tier2/godotsim/kernels/perception_mr.py`
  - `tier2/godotsim/kernels/piece3d_mr.py`
  - `tier2/godotsim/kernels/quest3d_mr.py`
  - `tier2/godotsim/kernels/spatial3d_mr.py`
- **Inbound Interface Files (24):**
  - `tier1/engainos/bridgeroom/quest3d_integration.py`
  - `tier1/engainos/bridgeroom/zon_bridge.py`
  - `tier1/engainos/core/combat3d_mr.py`
  - `tier1/engainos/core/quest3d_mr.py`
  - `tier1/engainos/core/replay.py`
  - `tier2/godotsim/adapters/behavior_adapter.py`
  - `tier2/godotsim/adapters/combat3d_adapter.py`
  - `tier2/godotsim/adapters/combat3d_integration.py`
  - `tier2/godotsim/adapters/dialogue3d_integration.py`
  - `tier2/godotsim/adapters/inventory3d_integration.py`
  - `tier2/godotsim/adapters/perception_adapter.py`
  - `tier2/godotsim/adapters/spatial3d_adapter.py`
  - `tier2/godotsim/builders/godot_scene_piece_builder.py`
  - `tier2/godotsim/gates/gate_floor_headless_parse_proof.py`
  - `tier2/godotsim/gates/gate_piece3d_baseline.py`
  - `tier2/godotsim/gates/gate_piece_recipe_pack_001.py`
  - `tier2/godotsim/gates/gate_piece_recipe_pack_001_visible_proof.py`
  - `tier2/godotsim/gates/gate_piece_recipe_pack_002_door_proof.py`
  - `tier2/godotsim/gates/gate_player_body_visible_proof.py`
  - `tier2/godotsim/gates/gate_player_movement_proof.py`
  - `tier2/godotsim/gates/gate_player_movement_visible_observer_proof.py`
  - `tier2/godotsim/gates/gate_static_room_visible_proof.py`
  - `tier2/godotsim/gates/gate_visible_floor_render_proof.py`
  - `tier2/godotsim/runtime_core.py`
- **Outbound Interface Files (1):**
  - `tier2/godotsim/__init__.py`

### Layoutroom Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier2/cartographer/layoutroom'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 2 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier2/cartographer/layoutroom/__init__.py`
  - `tier2/cartographer/layoutroom/topology_metric_layout_solver.py`
- **Inbound Interface Files (1):**
  - `tools/gameproof/run_gameproof_007.py`
- **Outbound Interface Files (1):**
  - `tier2/cartographer/artifactroom/metric_layout_artifact.py`

### Legacy_payloads Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'scratch/tier_relocation/trixel/legacy_payloads'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `scratch/tier_relocation/trixel/legacy_payloads/harvest_legacy_trixel_payloads.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Lib Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 5
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier3/mettaextgen2/lib'
  - Internal cohesion: 2 internal dependency edges
  - Cross-group coupling: 14 external dependency edges
- **Member Files:**
  - `tier3/mettaextgen2/lib/__init__.py`
  - `tier3/mettaextgen2/lib/annotations.py`
  - `tier3/mettaextgen2/lib/artifact_schema.py`
  - `tier3/mettaextgen2/lib/lane_line.py`
  - `tier3/mettaextgen2/lib/source.py`
- **Inbound Interface Files (14):**
  - `tier3/mettaextgen2/corpus_runner.py`
  - `tier3/mettaextgen2/modules/artifact_assembler.py`
  - `tier3/mettaextgen2/modules/dialogue_extractor.py`
  - `tier3/mettaextgen2/modules/entity_extractor.py`
  - `tier3/mettaextgen2/modules/linguistic_annotator.py`
  - `tier3/mettaextgen2/modules/metadata_reader.py`
  - `tier3/mettaextgen2/modules/presence_detector.py`
  - `tier3/mettaextgen2/modules/reconciler.py`
  - `tier3/mettaextgen2/modules/scene_segmenter.py`
  - `tier3/mettaextgen2/modules/source_loader.py`
  - `tier3/mettaextgen2/orchestrator.py`
  - `tier3/mettaextgen2/tests/test_gen2_grammar.py`
  - `tier3/mettaextgen2/tests/test_gen2_scene_048_5.py`
  - `tier3/mettaextgen2/tests/test_gen2_units.py`
- **Outbound Interface Files (0):**

### Llm_clients Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 12
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion, refined_by: toolbox_external_consumers
- **Evidence:**
  - Files share directory structure: 'out of root/trae/trae-agent-main/trae_agent/utils/llm_clients'
  - Internal cohesion: 28 internal dependency edges
  - Cross-group coupling: 15 external dependency edges
  - Toolbox cohesion: utility-dominated group (12/12 eligible members) serves 12 distinct external consumers; internal dependency edges are not required
- **Member Files:**
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/anthropic_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/azure_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/base_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/doubao_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/google_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/ollama_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_compatible_base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openrouter_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/retry_utils.py`
- **Inbound Interface Files (12):**
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/selector_agent.py`
  - `out of root/trae/trae-agent-main/tests/agent/test_trae_agent.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_config.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_google_client.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_ollama_client_utils.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_openrouter_client_utils.py`
  - `out of root/trae/trae-agent-main/trae_agent/__init__.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/agent_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/base_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/trae_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/lake_view.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py`
- **Outbound Interface Files (3):**
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py`

### Mechanimation Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 4
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'mechanimation'
  - Internal cohesion: 5 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `mechanimation/biomechanical_constraints_fixed.py`
  - `mechanimation/pose_editor.py`
  - `mechanimation/pose_studio.py`
  - `mechanimation/primeanim_v4a.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Mettaext Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 15
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier3/mettaext'
  - Internal cohesion: 4 internal dependency edges
  - Cross-group coupling: 19 external dependency edges
- **Member Files:**
  - `tier3/mettaext/__init__.py`
  - `tier3/mettaext/build_scene_index.py`
  - `tier3/mettaext/engain_ingest.py`
  - `tier3/mettaext/master_pipeline.py`
  - `tier3/mettaext/narrative_to_game.py`
  - `tier3/mettaext/pipeline_runner.py`
  - `tier3/mettaext/run1time.py`
  - `tier3/mettaext/scene_identity.py`
  - `tier3/mettaext/segmenter.py`
  - `tier3/mettaext/semantic_environment_extractor.py`
  - `tier3/mettaext/stageroom_manifest.py`
  - `tier3/mettaext/world_rules_loader.py`
  - `tier3/mettaext/zw_compiler.py`
  - `tier3/mettaext/zw_world_rules_compiler.py`
  - `tier3/mettaext/zwify_python.py`
- **Inbound Interface Files (19):**
  - `out of root/engain/semantic/extraction.py`
  - `out of root/tools/scene_identity_audit.py`
  - `tier1/engainos/bridgeroom/scene_loader.py`
  - `tier2/godotsim/http_handlers.py`
  - `tier2/godotsim/scene_manager.py`
  - `tier2/godotsim/sim_runtime.py`
  - `tier3/mettaext/passroom/pass2_entity_filter.py`
  - `tier3/mettaext/passroom/pass4_zon_bridge.py`
  - `tier3/mettaext/passroom/pass5_game_bridge.py`
  - `tier3/mettaext/tests/test_authored_scene_anchors.py`
  - `tier3/mettaext/tests/test_authored_scene_boundary_splitter.py`
  - `tier3/mettaext/tests/test_entity_evidence_lifecycle.py`
  - `tier3/mettaext/tests/test_identity_hierarchy.py`
  - `tier3/mettaext/tests/test_manifest_scoping.py`
  - `tier3/mettaext/tests/test_metadata_leakage.py`
  - `tier3/mettaext/tests/test_orchestration_characterization.py`
  - `tier3/mettaext/tests/test_pass3_pass4_entity_handoff.py`
  - `tier3/mettaext/tests/test_scene_content_observations.py`
  - `tier3/mettaext/tests/test_scene_local_manifestation.py`
- **Outbound Interface Files (0):**

### Mettaextgen2 Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 4
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier3/mettaextgen2'
  - Internal cohesion: 2 internal dependency edges
  - Cross-group coupling: 14 external dependency edges
- **Member Files:**
  - `tier3/mettaextgen2/__init__.py`
  - `tier3/mettaextgen2/compare_legacy.py`
  - `tier3/mettaextgen2/corpus_runner.py`
  - `tier3/mettaextgen2/orchestrator.py`
- **Inbound Interface Files (3):**
  - `tier3/mettaextgen2/tests/test_gen2_grammar.py`
  - `tier3/mettaextgen2/tests/test_gen2_scene_048_5.py`
  - `tier3/mettaextgen2/tests/test_gen2_units.py`
- **Outbound Interface Files (11):**
  - `tier3/mettaextgen2/lib/annotations.py`
  - `tier3/mettaextgen2/lib/lane_line.py`
  - `tier3/mettaextgen2/modules/artifact_assembler.py`
  - `tier3/mettaextgen2/modules/dialogue_extractor.py`
  - `tier3/mettaextgen2/modules/entity_extractor.py`
  - `tier3/mettaextgen2/modules/linguistic_annotator.py`
  - `tier3/mettaextgen2/modules/metadata_reader.py`
  - `tier3/mettaextgen2/modules/presence_detector.py`
  - `tier3/mettaextgen2/modules/reconciler.py`
  - `tier3/mettaextgen2/modules/scene_segmenter.py`
  - `tier3/mettaextgen2/modules/source_loader.py`

### Modules Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 10
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier3/mettaextgen2/modules'
  - Internal cohesion: 2 internal dependency edges
  - Cross-group coupling: 7 external dependency edges
- **Member Files:**
  - `tier3/mettaextgen2/modules/__init__.py`
  - `tier3/mettaextgen2/modules/artifact_assembler.py`
  - `tier3/mettaextgen2/modules/dialogue_extractor.py`
  - `tier3/mettaextgen2/modules/entity_extractor.py`
  - `tier3/mettaextgen2/modules/linguistic_annotator.py`
  - `tier3/mettaextgen2/modules/metadata_reader.py`
  - `tier3/mettaextgen2/modules/presence_detector.py`
  - `tier3/mettaextgen2/modules/reconciler.py`
  - `tier3/mettaextgen2/modules/scene_segmenter.py`
  - `tier3/mettaextgen2/modules/source_loader.py`
- **Inbound Interface Files (4):**
  - `tier3/mettaextgen2/corpus_runner.py`
  - `tier3/mettaextgen2/orchestrator.py`
  - `tier3/mettaextgen2/tests/test_gen2_grammar.py`
  - `tier3/mettaextgen2/tests/test_gen2_units.py`
- **Outbound Interface Files (3):**
  - `tier3/mettaextgen2/lib/annotations.py`
  - `tier3/mettaextgen2/lib/artifact_schema.py`
  - `tier3/mettaextgen2/lib/source.py`

### Mrlore Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 33
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion, refined_by: coordinator_outbound_concentration
- **Evidence:**
  - Files share directory structure: 'tier1/mrlore'
  - Internal cohesion: 20 internal dependency edges
  - Cross-group coupling: 39 external dependency edges
  - Coordinator cohesion: explicitly named control center emits 9/9 outbound edges (100.0%); internal dependency edges are not required
- **Member Files:**
  - `tier1/mrlore/__init__.py`
  - `tier1/mrlore/mrlore_accepted_lore_packet_schema.py`
  - `tier1/mrlore/mrlore_claim_extraction_runner.py`
  - `tier1/mrlore/mrlore_coming_calendar_registry_gate.py`
  - `tier1/mrlore/mrlore_contradiction_candidate_audit_summary.py`
  - `tier1/mrlore/mrlore_contradiction_candidate_grouper.py`
  - `tier1/mrlore/mrlore_control_center.py`
  - `tier1/mrlore/mrlore_cosmic_year_context_enrichment.py`
  - `tier1/mrlore/mrlore_entity_candidate_quality_gate.py`
  - `tier1/mrlore/mrlore_high_claim_scene_review_manifest.py`
  - `tier1/mrlore/mrlore_major_event_internal_receipt_map.py`
  - `tier1/mrlore/mrlore_manual_review_decision_example_writer.py`
  - `tier1/mrlore/mrlore_manual_review_decision_schema.py`
  - `tier1/mrlore/mrlore_narrative_concurrence_checker.py`
  - `tier1/mrlore/mrlore_p3_sequential_entity_second_pass_quality_audit.py`
  - `tier1/mrlore/mrlore_predicate_collision_policy_registry_gate.py`
  - `tier1/mrlore/mrlore_preserve_entity_allowlist_registry_gate.py`
  - `tier1/mrlore/mrlore_proposed_claim_audit_summary.py`
  - `tier1/mrlore/mrlore_proposed_claim_shape_gate.py`
  - `tier1/mrlore/mrlore_quality_aware_queue_summary.py`
  - `tier1/mrlore/mrlore_quality_aware_review_queue_builder.py`
  - `tier1/mrlore/mrlore_review_queue_builder.py`
  - `tier1/mrlore/mrlore_review_queue_clean_view.py`
  - `tier1/mrlore/mrlore_review_queue_noise_audit.py`
  - `tier1/mrlore/mrlore_review_rail_health_runner.py`
  - `tier1/mrlore/mrlore_revision_breathing_map.py`
  - `tier1/mrlore/mrlore_revision_breathing_map_guidance_gate.py`
  - `tier1/mrlore/mrlore_scene_intake_runner.py`
  - `tier1/mrlore/mrlore_temporal_aware_queue_summary.py`
  - `tier1/mrlore/mrlore_temporal_aware_review_by_chapter_view.py`
  - `tier1/mrlore/mrlore_temporal_aware_review_queue_builder.py`
  - `tier1/mrlore/mrlore_temporal_claim_context_enrichment.py`
  - `tier1/mrlore/mrlore_temporal_collision_classification.py`
- **Inbound Interface Files (30):**
  - `tier1/mrlore/tests/test_accepted_lore_packet_schema.py`
  - `tier1/mrlore/tests/test_claim_extraction_runner.py`
  - `tier1/mrlore/tests/test_coming_calendar_registry_gate.py`
  - `tier1/mrlore/tests/test_contradiction_candidate_audit_summary.py`
  - `tier1/mrlore/tests/test_contradiction_candidate_grouper.py`
  - `tier1/mrlore/tests/test_cosmic_year_context_enrichment.py`
  - `tier1/mrlore/tests/test_entity_candidate_quality_gate.py`
  - `tier1/mrlore/tests/test_high_claim_scene_review_manifest.py`
  - `tier1/mrlore/tests/test_major_event_internal_receipt_map.py`
  - `tier1/mrlore/tests/test_manual_review_decision_example_writer.py`
  - `tier1/mrlore/tests/test_manual_review_decision_schema.py`
  - `tier1/mrlore/tests/test_p3_sequential_entity_second_pass_quality_audit.py`
  - `tier1/mrlore/tests/test_predicate_collision_policy_registry_gate.py`
  - `tier1/mrlore/tests/test_preserve_entity_allowlist_registry_gate.py`
  - `tier1/mrlore/tests/test_proposed_claim_audit_summary.py`
  - `tier1/mrlore/tests/test_proposed_claim_shape_gate.py`
  - `tier1/mrlore/tests/test_quality_aware_queue_summary.py`
  - `tier1/mrlore/tests/test_quality_aware_review_queue_builder.py`
  - `tier1/mrlore/tests/test_review_queue_builder.py`
  - `tier1/mrlore/tests/test_review_queue_clean_view.py`
  - `tier1/mrlore/tests/test_review_queue_noise_audit.py`
  - `tier1/mrlore/tests/test_review_rail_health_runner.py`
  - `tier1/mrlore/tests/test_revision_breathing_map.py`
  - `tier1/mrlore/tests/test_revision_breathing_map_guidance_gate.py`
  - `tier1/mrlore/tests/test_temporal_aware_queue_summary.py`
  - `tier1/mrlore/tests/test_temporal_aware_review_by_chapter_view.py`
  - `tier1/mrlore/tests/test_temporal_aware_review_queue_builder.py`
  - `tier1/mrlore/tests/test_temporal_claim_context_enrichment.py`
  - `tier1/mrlore/tests/test_temporal_collision_classification.py`
  - `tools/gameproof/run_gameproof_008.py`
- **Outbound Interface Files (9):**
  - `engain_control/gate_print.py`
  - `tier1/mrlore/gates/gate_claims_structure.py`
  - `tier1/mrlore/gates/gate_contradiction_stop_proof.py`
  - `tier1/mrlore/gates/gate_contradictions_valid_if_present.py`
  - `tier1/mrlore/gates/gate_enum_values_valid.py`
  - `tier1/mrlore/gates/gate_no_auto_resolve_attempt.py`
  - `tier1/mrlore/gates/gate_no_lane_theft_in_packet.py`
  - `tier1/mrlore/gates/gate_no_vault_path_dependency.py`
  - `tier1/mrlore/gates/gate_required_fields.py`

### Okarchitect Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 5
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/okarchitect'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `out of root/okarchitect/okarchitect.py`
  - `out of root/okarchitect/okarchitect_v2.py`
  - `out of root/okarchitect/okarchitect_v2_fixed.py`
  - `out of root/okarchitect/okarchitect_v2_multiline_fix.py`
  - `out of root/okarchitect/okarchitect_v2_robust_input.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Old_tools Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 36
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/mrlore/archive/old_tools'
  - Internal cohesion: 2 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tier1/mrlore/archive/old_tools/artifact_extractor.py`
  - `tier1/mrlore/archive/old_tools/authority_score_calculator.py`
  - `tier1/mrlore/archive/old_tools/build_codex_candidates.py`
  - `tier1/mrlore/archive/old_tools/build_registry.py`
  - `tier1/mrlore/archive/old_tools/chapter_ledger_extractor.py`
  - `tier1/mrlore/archive/old_tools/compile_entity_states.py`
  - `tier1/mrlore/archive/old_tools/continuity_audit.py`
  - `tier1/mrlore/archive/old_tools/draft_rel_evidence_review.py`
  - `tier1/mrlore/archive/old_tools/extract_candidates.py`
  - `tier1/mrlore/archive/old_tools/extract_member_of.py`
  - `tier1/mrlore/archive/old_tools/identity_review_queue.py`
  - `tier1/mrlore/archive/old_tools/identity_reviewer.py`
  - `tier1/mrlore/archive/old_tools/identity_signal_math.py`
  - `tier1/mrlore/archive/old_tools/ingest_source_stub.py`
  - `tier1/mrlore/archive/old_tools/lint_codex_candidates.py`
  - `tier1/mrlore/archive/old_tools/lint_entity_contract.py`
  - `tier1/mrlore/archive/old_tools/lint_relationship_schema.py`
  - `tier1/mrlore/archive/old_tools/lint_scene_contract.py`
  - `tier1/mrlore/archive/old_tools/lint_wiki.py`
  - `tier1/mrlore/archive/old_tools/mrlore_query.py`
  - `tier1/mrlore/archive/old_tools/mrlore_rebuild_findings.py`
  - `tier1/mrlore/archive/old_tools/mrlore_run_changed.py`
  - `tier1/mrlore/archive/old_tools/mrlore_session.py`
  - `tier1/mrlore/archive/old_tools/ollama_ingest_cockpit.py`
  - `tier1/mrlore/archive/old_tools/pass2_math.py`
  - `tier1/mrlore/archive/old_tools/populate_registry.py`
  - `tier1/mrlore/archive/old_tools/promote_candidate.py`
  - `tier1/mrlore/archive/old_tools/promotion_eligibility_gate.py`
  - `tier1/mrlore/archive/old_tools/propose_corrections.py`
  - `tier1/mrlore/archive/old_tools/propose_rel_source_stubs.py`
  - `tier1/mrlore/archive/old_tools/propose_rel_summaries.py`
  - `tier1/mrlore/archive/old_tools/provisional_identity_router.py`
  - `tier1/mrlore/archive/old_tools/registry_builder.py`
  - `tier1/mrlore/archive/old_tools/stb_lint.py`
  - `tier1/mrlore/archive/old_tools/stb_scanner.py`
  - `tier1/mrlore/archive/old_tools/write_changed_manifest.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Paradoxroom Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/paradox_machine/paradoxroom'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tier1/paradox_machine/paradoxroom/__init__.py`
  - `tier1/paradox_machine/paradoxroom/potential_temporal_state_set.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Passb_fix Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tools/passB_fix'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tools/passB_fix/passB_day_boundary_runner.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Passroom Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 10
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier3/mettaext/passroom'
  - Internal cohesion: 3 internal dependency edges
  - Cross-group coupling: 16 external dependency edges
- **Member Files:**
  - `tier3/mettaext/passroom/__init__.py`
  - `tier3/mettaext/passroom/pass1_explicit.py`
  - `tier3/mettaext/passroom/pass1_spatial.py`
  - `tier3/mettaext/passroom/pass2_enhanced.py`
  - `tier3/mettaext/passroom/pass2_entity_filter.py`
  - `tier3/mettaext/passroom/pass2_event_builder.py`
  - `tier3/mettaext/passroom/pass3_merge.py`
  - `tier3/mettaext/passroom/pass4_zon_bridge.py`
  - `tier3/mettaext/passroom/pass5_game_bridge.py`
  - `tier3/mettaext/passroom/passroom_bridge.py`
- **Inbound Interface Files (14):**
  - `tier3/mettaext/tests/test_authored_scene_anchors.py`
  - `tier3/mettaext/tests/test_authored_scene_boundary_splitter.py`
  - `tier3/mettaext/tests/test_entity_evidence_lifecycle.py`
  - `tier3/mettaext/tests/test_entity_filter.py`
  - `tier3/mettaext/tests/test_identity_hierarchy.py`
  - `tier3/mettaext/tests/test_metadata_leakage.py`
  - `tier3/mettaext/tests/test_pass3_pass4_entity_handoff.py`
  - `tier3/mettaext/tests/test_pass4_explicit_empty_entities.py`
  - `tier3/mettaext/tests/test_pattern1_physicality_attribution.py`
  - `tier3/mettaext/tests/test_pattern4_participant_seeding.py`
  - `tier3/mettaext/tests/test_scene_content_observations.py`
  - `tier3/mettaext/tests/test_scene_local_manifestation.py`
  - `tools/gameproof/run_gameproof_004.py`
  - `tools/gameproof/run_gameproof_005.py`
- **Outbound Interface Files (2):**
  - `tier3/mettaext/semantic_environment_extractor.py`
  - `tier3/mettaext/world_rules_loader.py`

### Patch_selection Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/trae/trae-agent-main/evaluation/patch_selection'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 2 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/analysis.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/selector.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (2):**
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/selector_evaluation.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py`

### Phase_4 Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/mrlore/evidence/proofs/phase_4'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tier1/mrlore/evidence/proofs/phase_4/coco_flow.py`
  - `tier1/mrlore/evidence/proofs/phase_4/collect_delta.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Prompt Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/trae/trae-agent-main/trae_agent/prompt'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 1 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `out of root/trae/trae-agent-main/trae_agent/prompt/__init__.py`
  - `out of root/trae/trae-agent-main/trae_agent/prompt/agent_prompt.py`
- **Inbound Interface Files (1):**
  - `out of root/trae/trae-agent-main/trae_agent/agent/trae_agent.py`
- **Outbound Interface Files (0):**

### Proofs Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 7
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/paradox_machine/proofs'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 5 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier1/paradox_machine/proofs/__init__.py`
  - `tier1/paradox_machine/proofs/export_gate_triad_result_zw.py`
  - `tier1/paradox_machine/proofs/proof_007_temporal_mvp.py`
  - `tier1/paradox_machine/proofs/proof_007b_temporal_rejection.py`
  - `tier1/paradox_machine/proofs/proof_008_spatiotemporal_gate_stub.py`
  - `tier1/paradox_machine/proofs/read_paradox_machine_gate_triad_result.py`
  - `tier1/paradox_machine/proofs/run_paradox_machine_gate_triad.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (5):**
  - `tier1/paradox_machine/extraction/naive_temporal_extractor.py`
  - `tier1/paradox_machine/gates/temporal_gate.py`
  - `tier1/paradox_machine/reasoning/temporal_validator.py`
  - `tier1/paradox_machine/schemas/temporal_artifact.py`
  - `tier1/paradox_machine/zwcodecs/json_to_zw.py`

### Reasoning Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 4
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/paradox_machine/reasoning'
  - Internal cohesion: 1 internal dependency edges
  - Cross-group coupling: 5 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier1/paradox_machine/reasoning/__init__.py`
  - `tier1/paradox_machine/reasoning/allen_relations.py`
  - `tier1/paradox_machine/reasoning/stn.py`
  - `tier1/paradox_machine/reasoning/temporal_validator.py`
- **Inbound Interface Files (4):**
  - `scratch/test_temporal_contradiction.py`
  - `tier1/paradox_machine/gates/temporal_gate.py`
  - `tier1/paradox_machine/proofs/proof_007_temporal_mvp.py`
  - `tier1/paradox_machine/proofs/proof_007b_temporal_rejection.py`
- **Outbound Interface Files (1):**
  - `tier1/paradox_machine/schemas/temporal_artifact.py`

### Reckoningroom Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 4
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier2/cartographer/reckoningroom, tier2/topologist/reckoningroom'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 3 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier2/cartographer/reckoningroom/__init__.py`
  - `tier2/cartographer/reckoningroom/metric_layout_validator.py`
  - `tier2/topologist/reckoningroom/__init__.py`
  - `tier2/topologist/reckoningroom/topology_validator.py`
- **Inbound Interface Files (2):**
  - `tier2/topologist/classroom/run_topologist_classroom_probe.py`
  - `tools/gameproof/run_gameproof_007.py`
- **Outbound Interface Files (1):**
  - `tier2/topologist/artifactroom/topology_artifact.py`

### Relays Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/engainos/relays'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 2 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier1/engainos/relays/__init__.py`
  - `tier1/engainos/relays/ap_runtime_relay.py`
- **Inbound Interface Files (2):**
  - `tier1/engainos/gates/gate_ap_runtime_relay_behavior.py`
  - `tier1/engainos/gates/gate_ap_runtime_relay_real_integration.py`
- **Outbound Interface Files (0):**

### Render Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 3
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/engain/render'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 1 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `out of root/engain/render/__init__.py`
  - `out of root/engain/render/packet_io.py`
  - `out of root/engain/render/transforms.py`
- **Inbound Interface Files (1):**
  - `out of root/engain/world/placement_emitter.py`
- **Outbound Interface Files (0):**

### Retired Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tools/retired'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tools/retired/ollama_patcher.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Retired_agents Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/engainos/archive/retired_agents'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 1 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier1/engainos/archive/retired_agents/agent_gateway.py`
  - `tier1/engainos/archive/retired_agents/trae_observer.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (1):**
  - `tier1/engainos/__init__.py`

### Retired_cli_bridge Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'scratch/gameproof_003/retired_cli_bridge'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `scratch/gameproof_003/retired_cli_bridge/run_gameproof_003_cli.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Root Components
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 3
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: '.'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `engainos_boot_kernel.py`
  - `start_button.py`
  - `tmp_qwen35_proof.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Runtime Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/engain/runtime'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `out of root/engain/runtime/__init__.py`
  - `out of root/engain/runtime/sim.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Schemas Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 4
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/paradox_machine/schemas'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 5 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier1/paradox_machine/schemas/__init__.py`
  - `tier1/paradox_machine/schemas/paradox_state.py`
  - `tier1/paradox_machine/schemas/temporal_artifact.py`
  - `tier1/paradox_machine/schemas/temporal_truth_packet.py`
- **Inbound Interface Files (5):**
  - `scratch/test_temporal_contradiction.py`
  - `tier1/paradox_machine/extraction/naive_temporal_extractor.py`
  - `tier1/paradox_machine/gates/temporal_gate.py`
  - `tier1/paradox_machine/proofs/proof_007b_temporal_rejection.py`
  - `tier1/paradox_machine/reasoning/temporal_validator.py`
- **Outbound Interface Files (0):**

### Scratch Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'scratch'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `scratch/verify_libra_gates.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Semantic Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/engain/semantic'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 2 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `out of root/engain/semantic/__init__.py`
  - `out of root/engain/semantic/extraction.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (2):**
  - `tier2/godotsim/scene_extractor.py`
  - `tier3/mettaext/semantic_environment_extractor.py`

### Server Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 3
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/engainos/server'
  - Internal cohesion: 1 internal dependency edges
  - Cross-group coupling: 10 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier1/engainos/server/__init__.py`
  - `tier1/engainos/server/presence_authority_server.py`
  - `tier1/engainos/server/safe_runtime_server_entrypoint.py`
- **Inbound Interface Files (2):**
  - `tier1/engainos/tests/test_presence_authority_dispatch.py`
  - `tier1/engainos/tests/test_presence_authority_server.py`
- **Outbound Interface Files (8):**
  - `tier1/engainos/bridgeroom/claude_code_provider_adapter.py`
  - `tier1/engainos/bridgeroom/hermes_provider_adapter.py`
  - `tier1/engainos/bridgeroom/shared_session_bridge.py`
  - `tier1/engainos/core/continuity_cursor_tracker.py`
  - `tier1/engainos/core/presence_registry.py`
  - `tier1/engainos/core/provider_session_binding.py`
  - `tier1/engainos/core/session_claim_registry.py`
  - `tier1/engainos/core/session_ledger.py`

### Showroom Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 7
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier2/engionality/showroom'
  - Internal cohesion: 7 internal dependency edges
  - Cross-group coupling: 10 external dependency edges
- **Member Files:**
  - `tier2/engionality/showroom/__init__.py`
  - `tier2/engionality/showroom/animation_engine.py`
  - `tier2/engionality/showroom/audio_engine.py`
  - `tier2/engionality/showroom/dialogue_engine.py`
  - `tier2/engionality/showroom/domain_views.py`
  - `tier2/engionality/showroom/performer_engine.py`
  - `tier2/engionality/showroom/scene_track.py`
- **Inbound Interface Files (9):**
  - `out of root/tools/proofroom/engionality_showroom/probe_animation_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_audio_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_dialogue_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_domain_views.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_performer_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/probe_scene_track.py`
  - `tier2/engionality/controlroom/bootstrap.py`
  - `tier2/engionality/controlroom/performance_harness.py`
  - `tier2/engionality/controlroom/runtime_loop.py`
- **Outbound Interface Files (1):**
  - `tier2/engionality/controlroom/task_types.py`

### Testing Suite
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 115
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: test_role_hint, refined_by: role_consolidation
- **Evidence:**
  - Consolidated based on test role hints across directories
  - Internal cohesion: 8 internal dependency edges
  - Cross-group coupling: 130 external dependency edges
- **Member Files:**
  - `out of root/gui/tests/__init__.py`
  - `out of root/gui/tests/test_gui_local_zonb_roundtrip.py`
  - `out of root/gui/tests/test_gui_ux.py`
  - `out of root/gui/tests/test_tab_switch.py`
  - `out of root/legacy2beused/blender/blender-open-mcp-main/tests/test_addon.py`
  - `out of root/legacy2beused/blender/blender-open-mcp-main/tests/test_server.py`
  - `out of root/okarchitect/test_terminal_input.py`
  - `out of root/trae/trae-agent-main/tests/agent/test_trae_agent.py`
  - `out of root/trae/trae-agent-main/tests/test_cli.py`
  - `out of root/trae/trae-agent-main/tests/tools/test_bash_tool.py`
  - `out of root/trae/trae-agent-main/tests/tools/test_edit_tool.py`
  - `out of root/trae/trae-agent-main/tests/tools/test_json_edit_tool.py`
  - `out of root/trae/trae-agent-main/tests/tools/test_mcp_tool.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_config.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_google_client.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_mcp_client.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_ollama_client_utils.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_openrouter_client_utils.py`
  - `scratch/test_temporal_contradiction.py`
  - `tests/test_safe_stack_stop.py`
  - `tier1/engainos/tests/test_continuity_context_builder.py`
  - `tier1/engainos/tests/test_continuity_cursor_tracker.py`
  - `tier1/engainos/tests/test_continuity_identity_boundary.py`
  - `tier1/engainos/tests/test_editor_edit_authority.py`
  - `tier1/engainos/tests/test_editor_edit_mandates.py`
  - `tier1/engainos/tests/test_gamestate_authority.py`
  - `tier1/engainos/tests/test_hermes_provider_adapter_timeout.py`
  - `tier1/engainos/tests/test_local_signed_transport.py`
  - `tier1/engainos/tests/test_mailbox_request_handler.py`
  - `tier1/engainos/tests/test_presence_authority_dispatch.py`
  - `tier1/engainos/tests/test_presence_authority_server.py`
  - `tier1/engainos/tests/test_provider_session_binding.py`
  - `tier1/engainos/tests/test_scene_loader_stageroom.py`
  - `tier1/engainos/tests/test_session_claim_registry.py`
  - `tier1/engainos/tests/test_session_journal.py`
  - `tier1/engainos/tests/test_session_ledger.py`
  - `tier1/engainos/tests/test_session_ledger_persistence.py`
  - `tier1/engainos/tests/test_shared_session_continuity_live_hermes_proof.py`
  - `tier1/engainos/tests/test_shared_session_continuity_proof.py`
  - `tier1/engainos/tests/test_trixel32d_apply_authorization_export.py`
  - `tier1/engainos/tests/test_trixel32d_built_drop_intake.py`
  - `tier1/engainos/tests/test_trixel32d_complete_edge_transport.py`
  - `tier1/engainos/tests/test_trixel32d_handshake.py`
  - `tier1/engainos/tests/test_trixel32d_live_application_issuer.py`
  - `tier1/engainos/tests/test_trixel32d_live_godot_integration.py`
  - `tier1/engainos/tests/test_trixel32d_live_route.py`
  - `tier1/engainos/tests/test_trixel32d_request_assembler.py`
  - `tier1/engainos/tests/test_trixel32d_request_dispatch.py`
  - `tier1/engainos/tests/test_trixel32d_semantic_integration.py`
  - `tier1/engainos/tests/test_trixel32d_surface_apply.py`
  - `tier1/engainos/tests/test_trixel32d_ticket_a_dual_slab.py`
  - `tier1/mrlore/tests/test_accepted_lore_packet_schema.py`
  - `tier1/mrlore/tests/test_claim_extraction_runner.py`
  - `tier1/mrlore/tests/test_coming_calendar_registry_gate.py`
  - `tier1/mrlore/tests/test_contradiction_candidate_audit_summary.py`
  - `tier1/mrlore/tests/test_contradiction_candidate_grouper.py`
  - `tier1/mrlore/tests/test_cosmic_year_context_enrichment.py`
  - `tier1/mrlore/tests/test_entity_candidate_quality_gate.py`
  - `tier1/mrlore/tests/test_high_claim_scene_review_manifest.py`
  - `tier1/mrlore/tests/test_major_event_internal_receipt_map.py`
  - `tier1/mrlore/tests/test_manual_review_decision_example_writer.py`
  - `tier1/mrlore/tests/test_manual_review_decision_schema.py`
  - `tier1/mrlore/tests/test_p3_sequential_entity_second_pass_quality_audit.py`
  - `tier1/mrlore/tests/test_predicate_collision_policy_registry_gate.py`
  - `tier1/mrlore/tests/test_preserve_entity_allowlist_registry_gate.py`
  - `tier1/mrlore/tests/test_proposed_claim_audit_summary.py`
  - `tier1/mrlore/tests/test_proposed_claim_shape_gate.py`
  - `tier1/mrlore/tests/test_quality_aware_queue_summary.py`
  - `tier1/mrlore/tests/test_quality_aware_review_queue_builder.py`
  - `tier1/mrlore/tests/test_review_queue_builder.py`
  - `tier1/mrlore/tests/test_review_queue_clean_view.py`
  - `tier1/mrlore/tests/test_review_queue_noise_audit.py`
  - `tier1/mrlore/tests/test_review_rail_health_runner.py`
  - `tier1/mrlore/tests/test_revision_breathing_map.py`
  - `tier1/mrlore/tests/test_revision_breathing_map_guidance_gate.py`
  - `tier1/mrlore/tests/test_temporal_aware_queue_summary.py`
  - `tier1/mrlore/tests/test_temporal_aware_review_by_chapter_view.py`
  - `tier1/mrlore/tests/test_temporal_aware_review_queue_builder.py`
  - `tier1/mrlore/tests/test_temporal_claim_context_enrichment.py`
  - `tier1/mrlore/tests/test_temporal_collision_classification.py`
  - `tier1/paradox_machine/tests/__init__.py`
  - `tier1/paradox_machine/tests/test_temporal_artifact.py`
  - `tier1/paradox_machine/tests/test_temporal_gate.py`
  - `tier1/paradox_machine/tests/test_temporal_validator.py`
  - `tier2/godotsim/test_bridge_entities_manifestation.py`
  - `tier2/godotsim/test_combat3d_adapter.py`
  - `tier2/godotsim/test_combat_commit.py`
  - `tier2/godotsim/test_gateway_combat_rules.py`
  - `tier2/godotsim/test_presentation_observation.py`
  - `tier2/godotsim/test_scene_load_handshake.py`
  - `tier2/godotsim/test_scene_provenance.py`
  - `tier2/godotsim/test_slice_builders.py`
  - `tier2/godotsim/test_snapshot_ownership.py`
  - `tier2/godotsim/test_snapshot_peek.py`
  - `tier2/godotsim/test_stageroom_scene_delivery.py`
  - `tier3/mettaext/tests/__init__.py`
  - `tier3/mettaext/tests/test_authored_scene_anchors.py`
  - `tier3/mettaext/tests/test_authored_scene_boundary_splitter.py`
  - `tier3/mettaext/tests/test_authored_scene_markers_fenced_yaml.py`
  - `tier3/mettaext/tests/test_entity_evidence_lifecycle.py`
  - `tier3/mettaext/tests/test_entity_filter.py`
  - `tier3/mettaext/tests/test_identity_hierarchy.py`
  - `tier3/mettaext/tests/test_manifest_scoping.py`
  - `tier3/mettaext/tests/test_metadata_leakage.py`
  - `tier3/mettaext/tests/test_orchestration_characterization.py`
  - `tier3/mettaext/tests/test_pass3_pass4_entity_handoff.py`
  - `tier3/mettaext/tests/test_pass4_explicit_empty_entities.py`
  - `tier3/mettaext/tests/test_pattern1_physicality_attribution.py`
  - `tier3/mettaext/tests/test_pattern4_participant_seeding.py`
  - `tier3/mettaext/tests/test_scene_content_observations.py`
  - `tier3/mettaext/tests/test_scene_local_manifestation.py`
  - `tier3/mettaextgen2/tests/__init__.py`
  - `tier3/mettaextgen2/tests/test_gen2_grammar.py`
  - `tier3/mettaextgen2/tests/test_gen2_scene_048_5.py`
  - `tier3/mettaextgen2/tests/test_gen2_units.py`
- **Inbound Interface Files (4):**
  - `executors/trixel32d_built_drop_intake_proof_v1.py`
  - `executors/trixel32d_complete_edge_loop_proof_v1.py`
  - `executors/trixel32d_editor_handshake_proof_v1.py`
  - `executors/trixel32d_request_loop_proof_v1.py`
- **Outbound Interface Files (126):**
  - `out of root/gui/older_zw_gui_enhanced.py`
  - `out of root/gui/zon/zon_binary_pack.py`
  - `out of root/gui/zw/zw_parser.py`
  - `out of root/gui/zw_gui.py`
  - `out of root/legacy2beused/blender/blender-open-mcp-main/addon.py`
  - `out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/server.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/agent_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/trae_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/cli.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/bash_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/edit_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/json_edit_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/mcp_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/legacy_config.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/anthropic_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/google_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/ollama_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openrouter_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/mcp_client.py`
  - `tier1/engainos/aproom/ap_complex_rules.py`
  - `tier1/engainos/aproom/reality_mode.py`
  - `tier1/engainos/authority/editor_edit_authority.py`
  - `tier1/engainos/authority/local_signed_transport.py`
  - `tier1/engainos/authority/trixel32d_application_grant.py`
  - `tier1/engainos/authority/trixel32d_live_application_issuer.py`
  - `tier1/engainos/authority/trixel32d_live_authority_state.py`
  - `tier1/engainos/bridgeroom/editor_edit_route.py`
  - `tier1/engainos/bridgeroom/hermes_provider_adapter.py`
  - `tier1/engainos/bridgeroom/mailbox_request_handler.py`
  - `tier1/engainos/bridgeroom/scene_loader.py`
  - `tier1/engainos/bridgeroom/scene_server.py`
  - `tier1/engainos/bridgeroom/shared_session_bridge.py`
  - `tier1/engainos/bridgeroom/stageroom_scene_resolver.py`
  - `tier1/engainos/bridgeroom/trixel32d_built_drop_intake.py`
  - `tier1/engainos/bridgeroom/trixel32d_live_route.py`
  - `tier1/engainos/bridgeroom/trixel32d_request_assembler.py`
  - `tier1/engainos/bridgeroom/trixel32d_request_dispatch.py`
  - `tier1/engainos/core/continuity_context_builder.py`
  - `tier1/engainos/core/continuity_cursor_tracker.py`
  - `tier1/engainos/core/intent_shadow.py`
  - `tier1/engainos/core/presence_registry.py`
  - `tier1/engainos/core/provider_session_binding.py`
  - `tier1/engainos/core/session_claim_registry.py`
  - `tier1/engainos/core/session_journal.py`
  - `tier1/engainos/core/session_ledger.py`
  - `tier1/engainos/gates/gate_gamestate_draft_review_ready.py`
  - `tier1/engainos/gates/gate_trixel32d_handshake.py`
  - `tier1/engainos/gates/gate_trixel32d_surface_apply.py`
  - `tier1/engainos/server/presence_authority_server.py`
  - `tier1/mrlore/mrlore_accepted_lore_packet_schema.py`
  - `tier1/mrlore/mrlore_claim_extraction_runner.py`
  - `tier1/mrlore/mrlore_coming_calendar_registry_gate.py`
  - `tier1/mrlore/mrlore_contradiction_candidate_audit_summary.py`
  - `tier1/mrlore/mrlore_contradiction_candidate_grouper.py`
  - `tier1/mrlore/mrlore_cosmic_year_context_enrichment.py`
  - `tier1/mrlore/mrlore_entity_candidate_quality_gate.py`
  - `tier1/mrlore/mrlore_high_claim_scene_review_manifest.py`
  - `tier1/mrlore/mrlore_major_event_internal_receipt_map.py`
  - `tier1/mrlore/mrlore_manual_review_decision_example_writer.py`
  - `tier1/mrlore/mrlore_manual_review_decision_schema.py`
  - `tier1/mrlore/mrlore_p3_sequential_entity_second_pass_quality_audit.py`
  - `tier1/mrlore/mrlore_predicate_collision_policy_registry_gate.py`
  - `tier1/mrlore/mrlore_preserve_entity_allowlist_registry_gate.py`
  - `tier1/mrlore/mrlore_proposed_claim_audit_summary.py`
  - `tier1/mrlore/mrlore_proposed_claim_shape_gate.py`
  - `tier1/mrlore/mrlore_quality_aware_queue_summary.py`
  - `tier1/mrlore/mrlore_quality_aware_review_queue_builder.py`
  - `tier1/mrlore/mrlore_review_queue_builder.py`
  - `tier1/mrlore/mrlore_review_queue_clean_view.py`
  - `tier1/mrlore/mrlore_review_queue_noise_audit.py`
  - `tier1/mrlore/mrlore_review_rail_health_runner.py`
  - `tier1/mrlore/mrlore_revision_breathing_map.py`
  - `tier1/mrlore/mrlore_revision_breathing_map_guidance_gate.py`
  - `tier1/mrlore/mrlore_temporal_aware_queue_summary.py`
  - `tier1/mrlore/mrlore_temporal_aware_review_by_chapter_view.py`
  - `tier1/mrlore/mrlore_temporal_aware_review_queue_builder.py`
  - `tier1/mrlore/mrlore_temporal_claim_context_enrichment.py`
  - `tier1/mrlore/mrlore_temporal_collision_classification.py`
  - `tier1/paradox_machine/reasoning/temporal_validator.py`
  - `tier1/paradox_machine/schemas/temporal_artifact.py`
  - `tier2/godotsim/adapters/combat3d_adapter.py`
  - `tier2/godotsim/bridge_integration.py`
  - `tier2/godotsim/command_dispatcher.py`
  - `tier2/godotsim/http_handlers.py`
  - `tier2/godotsim/presentation_observation.py`
  - `tier2/godotsim/runtime_core.py`
  - `tier2/godotsim/runtime_gateway.py`
  - `tier2/godotsim/scene_manager.py`
  - `tier2/godotsim/sim_runtime.py`
  - `tier2/godotsim/slice_builders.py`
  - `tier2/godotsim/slice_types.py`
  - `tier2/worldfield/grid_facts_emitter.py`
  - `tier2/worldfield/trixel_world_adapter.py`
  - `tier3/mettaext/chapterroom/chapterroom_index_runner.py`
  - `tier3/mettaext/chapterroom/passA_chapter_intake.py`
  - `tier3/mettaext/chapterroom/passB_scene_boundary_provider.py`
  - `tier3/mettaext/chapterroom/passC_scene_packet_writer.py`
  - `tier3/mettaext/engain_ingest.py`
  - `tier3/mettaext/master_pipeline.py`
  - `tier3/mettaext/narrative_to_game.py`
  - `tier3/mettaext/passroom/pass1_explicit.py`
  - `tier3/mettaext/passroom/pass2_enhanced.py`
  - `tier3/mettaext/passroom/pass2_entity_filter.py`
  - `tier3/mettaext/passroom/pass3_merge.py`
  - `tier3/mettaext/passroom/pass4_zon_bridge.py`
  - `tier3/mettaext/passroom/pass5_game_bridge.py`
  - `tier3/mettaext/pipeline_runner.py`
  - `tier3/mettaext/stageroom_manifest.py`
  - `tier3/mettaext/world_rules_loader.py`
  - `tier3/mettaextgen2/compare_legacy.py`
  - `tier3/mettaextgen2/lib/annotations.py`
  - `tier3/mettaextgen2/lib/artifact_schema.py`
  - `tier3/mettaextgen2/lib/lane_line.py`
  - `tier3/mettaextgen2/lib/source.py`
  - `tier3/mettaextgen2/modules/artifact_assembler.py`
  - `tier3/mettaextgen2/modules/entity_extractor.py`
  - `tier3/mettaextgen2/modules/linguistic_annotator.py`
  - `tier3/mettaextgen2/modules/metadata_reader.py`
  - `tier3/mettaextgen2/modules/presence_detector.py`
  - `tier3/mettaextgen2/modules/reconciler.py`
  - `tier3/mettaextgen2/modules/scene_segmenter.py`
  - `tier3/mettaextgen2/orchestrator.py`

### Tier2 Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier2'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tier2/__init__.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Tier3 Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier3'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tier3/__init__.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Tools Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 49
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/tools, out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools, out of root/trae/trae-agent-main/trae_agent/tools, tier1/engainos/tools, tier1/mrlore/tools, tools'
  - Internal cohesion: 19 internal dependency edges
  - Cross-group coupling: 34 external dependency edges
- **Member Files:**
  - `out of root/tools/audit_godot_spawns.py`
  - `out of root/tools/check_ap_engine_singleton.py`
  - `out of root/tools/export_blend_to_godot_glb.py`
  - `out of root/tools/patch_bridge_integration_upbge_coords_v1.py`
  - `out of root/tools/patch_sim_runtime_autorelink_v1.py`
  - `out of root/tools/patch_sim_runtime_autorelink_v2.py`
  - `out of root/tools/patch_sim_runtime_autorelink_v3.py`
  - `out of root/tools/patch_sim_runtime_autorelink_v3b.py`
  - `out of root/tools/patch_sim_runtime_bridge_entities.py`
  - `out of root/tools/patch_sim_runtime_bridge_entities_v1.py`
  - `out of root/tools/patch_upbge_bridge_use_position_v1.py`
  - `out of root/tools/patch_zonjrender_transforms_guard_v1.py`
  - `out of root/tools/rebuild_scene_cache.py`
  - `out of root/tools/scene_identity_audit.py`
  - `out of root/tools/upbge_list_logic_scripts.py`
  - `out of root/tools/upbge_print_text_paths.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/base.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/bash.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/edit.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/execute_bash.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/execute_str_replace_editor.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/run.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/__init__.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/bash_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/docker_tool_executor.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/edit_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/edit_tool_cli.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/json_edit_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/json_edit_tool_cli.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/mcp_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/run.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/sequential_thinking_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/task_done_tool.py`
  - `tier1/engainos/tools/chapter_discovery.py`
  - `tier1/engainos/tools/live_avatar_continuity_integration_proof.py`
  - `tier1/engainos/tools/live_claude_code_continuity_proof.py`
  - `tier1/engainos/tools/live_cross_provider_mailbox_portability_proof.py`
  - `tier1/engainos/tools/live_cross_provider_portability_proof.py`
  - `tier1/engainos/tools/live_dispatch_mutex_contention_proof.py`
  - `tier1/engainos/tools/live_hermes_continuity_proof.py`
  - `tier1/engainos/tools/live_journal_restart_proofs.py`
  - `tier1/engainos/tools/live_torn_tail_recovery_proof.py`
  - `tier1/engainos/tools/vault_discovery.py`
  - `tier1/mrlore/tools/__init__.py`
  - `tier1/mrlore/tools/mrlore_full_output_dump.py`
  - `tools/ollama_diff_patcher.py`
  - `tools/stop_stack_safe.py`
- **Inbound Interface Files (22):**
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/selector_agent.py`
  - `out of root/trae/trae-agent-main/tests/tools/test_bash_tool.py`
  - `out of root/trae/trae-agent-main/tests/tools/test_edit_tool.py`
  - `out of root/trae/trae-agent-main/tests/tools/test_json_edit_tool.py`
  - `out of root/trae/trae-agent-main/tests/tools/test_mcp_tool.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_google_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/__init__.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/agent_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/base_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/trae_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/cli.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/anthropic_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/base_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/google_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/ollama_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_compatible_base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/mcp_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py`
  - `tier2/godotsim/gates/gate_ollama_diff_patcher_tests.py`
- **Outbound Interface Files (12):**
  - `out of root/trae/trae-agent-main/trae_agent/agent/docker_manager.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg/ckg_database.py`
  - `tier1/engainos/bridgeroom/claude_code_provider_adapter.py`
  - `tier1/engainos/bridgeroom/hermes_provider_adapter.py`
  - `tier1/engainos/bridgeroom/mailbox_request_handler.py`
  - `tier1/engainos/bridgeroom/shared_session_bridge.py`
  - `tier1/engainos/core/continuity_cursor_tracker.py`
  - `tier1/engainos/core/presence_registry.py`
  - `tier1/engainos/core/provider_session_binding.py`
  - `tier1/engainos/core/session_journal.py`
  - `tier1/engainos/core/session_ledger.py`
  - `tier3/mettaext/scene_identity.py`

### Topologist Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier2/topologist'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tier2/topologist/__init__.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Trae_agent Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/trae/trae-agent-main/trae_agent'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 7 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `out of root/trae/trae-agent-main/trae_agent/__init__.py`
  - `out of root/trae/trae-agent-main/trae_agent/cli.py`
- **Inbound Interface Files (1):**
  - `out of root/trae/trae-agent-main/tests/test_cli.py`
- **Outbound Interface Files (6):**
  - `out of root/trae/trae-agent-main/trae_agent/agent/base_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/trae_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/__init__.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_client.py`

### Trae_selector Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 5
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector'
  - Internal cohesion: 4 internal dependency edges
  - Cross-group coupling: 7 external dependency edges
- **Member Files:**
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/__init__.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/sandbox.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/selector_agent.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/selector_evaluation.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/utils.py`
- **Inbound Interface Files (1):**
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/selector.py`
- **Outbound Interface Files (6):**
  - `out of root/trae/trae-agent-main/trae_agent/agent/trae_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py`

### Unsorted Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 1
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/engainos/core/unsorted'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tier1/engainos/core/unsorted/__init__.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Utilities Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 6
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion, refined_by: toolbox_external_consumers
- **Evidence:**
  - Files share directory structure: 'out of root/trae/trae-agent-main/trae_agent/utils'
  - Internal cohesion: 3 internal dependency edges
  - Cross-group coupling: 33 external dependency edges
  - Toolbox cohesion: utility-dominated group (4/6 eligible members) serves 28 distinct external consumers; internal dependency edges are not required
- **Member Files:**
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/constants.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/lake_view.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/legacy_config.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/mcp_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py`
- **Inbound Interface Files (28):**
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/selector.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/selector_agent.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/selector_evaluation.py`
  - `out of root/trae/trae-agent-main/tests/agent/test_trae_agent.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_config.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_google_client.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_mcp_client.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_ollama_client_utils.py`
  - `out of root/trae/trae-agent-main/tests/utils/test_openrouter_client_utils.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/base_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/trae_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/cli.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg/ckg_database.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/cli/cli_console.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/cli/console_factory.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/cli/rich_console.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/cli/simple_console.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/anthropic_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/azure_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/base_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/doubao_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/google_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/ollama_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_compatible_base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openrouter_client.py`
- **Outbound Interface Files (5):**
  - `out of root/trae/trae-agent-main/trae_agent/agent/agent_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/mcp_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_client.py`

### Validators Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 3
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/engainos/validators'
  - Internal cohesion: 1 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tier1/engainos/validators/__init__.py`
  - `tier1/engainos/validators/runtime_stage_identity.py`
  - `tier1/engainos/validators/runtime_stage_manifest.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### Vaultroom Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier3/mettaext/vaultroom'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 0 external dependency edges
- **Member Files:**
  - `tier3/mettaext/vaultroom/__init__.py`
  - `tier3/mettaext/vaultroom/vault_source_index.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (0):**

### World Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 7
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/engain/world'
  - Internal cohesion: 3 internal dependency edges
  - Cross-group coupling: 1 external dependency edges
- **Member Files:**
  - `out of root/engain/world/__init__.py`
  - `out of root/engain/world/chunks.py`
  - `out of root/engain/world/coordinates.py`
  - `out of root/engain/world/field.py`
  - `out of root/engain/world/placement_emitter.py`
  - `out of root/engain/world/topology_stub.py`
  - `out of root/engain/world/world_field_adapter.py`
- **Inbound Interface Files (0):**
- **Outbound Interface Files (1):**
  - `out of root/engain/render/transforms.py`

### Worldfield Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 5
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier2/worldfield'
  - Internal cohesion: 3 internal dependency edges
  - Cross-group coupling: 1 external dependency edges
- **Member Files:**
  - `tier2/worldfield/__init__.py`
  - `tier2/worldfield/grid_facts_emitter.py`
  - `tier2/worldfield/terrain_thresholds.py`
  - `tier2/worldfield/trixel_world_adapter.py`
  - `tier2/worldfield/world_field_nucleus.py`
- **Inbound Interface Files (1):**
  - `tier1/engainos/tests/test_trixel32d_request_assembler.py`
- **Outbound Interface Files (0):**

### Zon Subsystem
- **Confidence:** High
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** No
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/gui/zon'
  - Internal cohesion: 1 internal dependency edges
  - Cross-group coupling: 2 external dependency edges
- **Member Files:**
  - `out of root/gui/zon/__init__.py`
  - `out of root/gui/zon/zon_binary_pack.py`
- **Inbound Interface Files (2):**
  - `out of root/gui/old_zw_gui_enhanced.py`
  - `out of root/gui/tests/test_gui_local_zonb_roundtrip.py`
- **Outbound Interface Files (0):**

### Zw Subsystem
- **Confidence:** Medium
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'out of root/gui/zw'
  - Internal cohesion: 1 internal dependency edges
  - Cross-group coupling: 4 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `out of root/gui/zw/__init__.py`
  - `out of root/gui/zw/zw_parser.py`
- **Inbound Interface Files (4):**
  - `out of root/core/zw_core.py`
  - `out of root/gui/older_zw_gui_enhanced.py`
  - `out of root/gui/tests/test_gui_local_zonb_roundtrip.py`
  - `out of root/gui/zw_gui.py`
- **Outbound Interface Files (0):**

### Zwcodecs Subsystem
- **Confidence:** Low
- **Claim Type:** inferred
- **Member Count:** 2
- **Structurally Ambiguous:** Yes
- **Grouping Basis:** seed: directory_structure, refined_by: dependency_cohesion
- **Evidence:**
  - Files share directory structure: 'tier1/paradox_machine/zwcodecs'
  - Internal cohesion: 0 internal dependency edges
  - Cross-group coupling: 1 external dependency edges
  - Weak internal cohesion relative to strong cross-group coupling; marked as structurally ambiguous
- **Member Files:**
  - `tier1/paradox_machine/zwcodecs/__init__.py`
  - `tier1/paradox_machine/zwcodecs/json_to_zw.py`
- **Inbound Interface Files (1):**
  - `tier1/paradox_machine/proofs/export_gate_triad_result_zw.py`
- **Outbound Interface Files (0):**

## 3. Top Ranked Next Files to Inspect (Top 10)
1. `out of root/okarchitect/okarchitect_engine.py` (Score: **100**)
   - **Reasons:** parse_error
   - **Evidence:**
     - parse_error: SyntaxError: invalid character '–' (U+2013) (okarchitect_engine.py, line 2)

2. `out of root/trae/trae-agent-main/trae_agent/tools/ckg/ckg_database.py` (Score: **94**)
   - **Reasons:** structurally_ambiguous_subsystem, high_inbound_coupling, stubbed_implementation, high_outbound_coupling
   - **Evidence:**
     - member_of: candidate_subsystem_groups.Ckg Subsystem
     - inbound_count: 2
     - status: stubbed
     - outbound_count: 2

3. `tier1/paradox_machine/reasoning/stn.py` (Score: **80**)
   - **Reasons:** structurally_ambiguous_subsystem, stubbed_implementation
   - **Evidence:**
     - member_of: candidate_subsystem_groups.Reasoning Subsystem
     - status: stubbed

4. `tier1/paradox_machine/schemas/paradox_state.py` (Score: **80**)
   - **Reasons:** structurally_ambiguous_subsystem, stubbed_implementation
   - **Evidence:**
     - member_of: candidate_subsystem_groups.Schemas Subsystem
     - status: stubbed

5. `tier1/paradox_machine/schemas/temporal_truth_packet.py` (Score: **80**)
   - **Reasons:** structurally_ambiguous_subsystem, stubbed_implementation
   - **Evidence:**
     - member_of: candidate_subsystem_groups.Schemas Subsystem
     - status: stubbed

6. `tier2/godotsim/builders/godot_scene_piece_builder.py` (Score: **77**)
   - **Reasons:** structurally_ambiguous_subsystem, high_inbound_coupling, high_outbound_coupling
   - **Evidence:**
     - member_of: candidate_subsystem_groups.Builders Subsystem
     - inbound_count: 6
     - outbound_count: 1

7. `out of root/gui/zw/zw_parser.py` (Score: **75**)
   - **Reasons:** structurally_ambiguous_subsystem, high_inbound_coupling
   - **Evidence:**
     - member_of: candidate_subsystem_groups.Zw Subsystem
     - inbound_count: 5

8. `tier1/paradox_machine/schemas/temporal_artifact.py` (Score: **75**)
   - **Reasons:** structurally_ambiguous_subsystem, high_inbound_coupling
   - **Evidence:**
     - member_of: candidate_subsystem_groups.Schemas Subsystem
     - inbound_count: 5

9. `tier2/godotsim/kernels/combat3d_mr.py` (Score: **75**)
   - **Reasons:** structurally_ambiguous_subsystem, high_inbound_coupling
   - **Evidence:**
     - member_of: candidate_subsystem_groups.Kernels Subsystem
     - inbound_count: 5

10. `tier2/godotsim/kernels/piece3d_mr.py` (Score: **75**)
   - **Reasons:** structurally_ambiguous_subsystem, high_inbound_coupling
   - **Evidence:**
     - member_of: candidate_subsystem_groups.Kernels Subsystem
     - inbound_count: 11

## 4. Path and Dependency Routes
These paths describe **static dependency routes** determined by import statements. The file order reflects the **dependency traversal order** (DFS) from the entrypoint, which is not a proven runtime execution call order. Suggested inspection order is **advisory only**.

### Static Route from entrypoint: `command_center/app.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `command_center/app.py`

### Static Route from entrypoint: `engain_control/engain_master_control_center.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `engain_control/engain_master_control_center.py`

### Static Route from entrypoint: `engainos_boot_kernel.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `engainos_boot_kernel.py`

### Static Route from entrypoint: `executors/boot_scene_load_executor_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `executors/boot_scene_load_executor_v1.py`

### Static Route from entrypoint: `executors/player_input_listener_executor_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `executors/player_input_listener_executor_v1.py`

### Static Route from entrypoint: `executors/trixel32d_apply_authorization_export_v1.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/gates/gate_trixel32d_surface_apply.py`
- **Dependency Traversal Flow:**
  - `executors/trixel32d_apply_authorization_export_v1.py`
  - `tier1/engainos/gates/gate_trixel32d_handshake.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/gates/gate_trixel32d_surface_apply.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Gates Subsystem)

### Static Route from entrypoint: `executors/trixel32d_built_drop_intake_proof_v1.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/tests/test_trixel32d_surface_apply.py`
- **Dependency Traversal Flow:**
  - `executors/trixel32d_built_drop_intake_proof_v1.py`
  - `tier1/engainos/bridgeroom/trixel32d_built_drop_intake.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/gates/gate_trixel32d_handshake.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/gates/gate_trixel32d_surface_apply.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/tests/test_trixel32d_built_drop_intake.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Testing Suite)
  - `tier1/engainos/tests/test_trixel32d_surface_apply.py`

### Static Route from entrypoint: `executors/trixel32d_complete_edge_loop_proof_v1.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/tests/test_trixel32d_surface_apply.py`
- **Dependency Traversal Flow:**
  - `executors/trixel32d_complete_edge_loop_proof_v1.py`
  - `tier1/engainos/bridgeroom/trixel32d_built_drop_intake.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/gates/gate_trixel32d_handshake.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/bridgeroom/trixel32d_request_dispatch.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/gates/gate_trixel32d_surface_apply.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/tests/test_trixel32d_complete_edge_transport.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Testing Suite)
  - `tier1/engainos/tests/test_trixel32d_built_drop_intake.py`
  - `tier1/engainos/tests/test_trixel32d_surface_apply.py`

### Static Route from entrypoint: `executors/trixel32d_editor_handshake_proof_v1.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/tests/test_trixel32d_surface_apply.py`
- **Dependency Traversal Flow:**
  - `executors/trixel32d_editor_handshake_proof_v1.py`
  - `tier1/engainos/bridgeroom/trixel32d_built_drop_intake.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/gates/gate_trixel32d_handshake.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/bridgeroom/trixel32d_request_dispatch.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/gates/gate_trixel32d_surface_apply.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/tests/test_trixel32d_built_drop_intake.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Testing Suite)
  - `tier1/engainos/tests/test_trixel32d_surface_apply.py`

### Static Route from entrypoint: `executors/trixel32d_request_loop_proof_v1.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/tests/test_trixel32d_surface_apply.py`
- **Dependency Traversal Flow:**
  - `executors/trixel32d_request_loop_proof_v1.py`
  - `tier1/engainos/bridgeroom/trixel32d_built_drop_intake.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/gates/gate_trixel32d_handshake.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/bridgeroom/trixel32d_request_dispatch.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/gates/gate_trixel32d_surface_apply.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/tests/test_trixel32d_built_drop_intake.py` ➔ **Inferred Boundary Crossing:** (Executors Subsystem ➔ Testing Suite)
  - `tier1/engainos/tests/test_trixel32d_surface_apply.py`

### Static Route from entrypoint: `gates/gate_boot_scene_authorization_request_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `gates/gate_boot_scene_authorization_request_v1.py`

### Static Route from entrypoint: `gates/gate_boot_scene_load_executor_request_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `gates/gate_boot_scene_load_executor_request_v1.py`

### Static Route from entrypoint: `gates/gate_boot_shell_presentation_ready_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `gates/gate_boot_shell_presentation_ready_v1.py`

### Static Route from entrypoint: `gates/gate_engainos_bootstrap_preflight_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `gates/gate_engainos_bootstrap_preflight_v1.py`

### Static Route from entrypoint: `gates/gate_engainos_system_health_preflight_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `gates/gate_engainos_system_health_preflight_v1.py`

### Static Route from entrypoint: `gates/gate_player_input_authorization_request_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `gates/gate_player_input_authorization_request_v1.py`

### Static Route from entrypoint: `gates/gate_player_input_listener_executor_request_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `gates/gate_player_input_listener_executor_request_v1.py`

### Static Route from entrypoint: `interface/000_status.py`
- **Advisory Next File to Inspect in Route:** `interface/interface_common.py`
- **Dependency Traversal Flow:**
  - `interface/000_status.py`
  - `interface/interface_common.py`

### Static Route from entrypoint: `interface/010_show_protected_files.py`
- **Advisory Next File to Inspect in Route:** `interface/interface_common.py`
- **Dependency Traversal Flow:**
  - `interface/010_show_protected_files.py`
  - `interface/interface_common.py`

### Static Route from entrypoint: `interface/020_show_ledger.py`
- **Advisory Next File to Inspect in Route:** `interface/interface_common.py`
- **Dependency Traversal Flow:**
  - `interface/020_show_ledger.py`
  - `interface/interface_common.py`

### Static Route from entrypoint: `interface/030_create_task_packet.py`
- **Advisory Next File to Inspect in Route:** `interface/interface_common.py`
- **Dependency Traversal Flow:**
  - `interface/030_create_task_packet.py`
  - `interface/interface_common.py`

### Static Route from entrypoint: `interface/040_show_next_command.py`
- **Advisory Next File to Inspect in Route:** `interface/interface_common.py`
- **Dependency Traversal Flow:**
  - `interface/040_show_next_command.py`
  - `interface/interface_common.py`

### Static Route from entrypoint: `interface/050_record_command_output.py`
- **Advisory Next File to Inspect in Route:** `interface/interface_common.py`
- **Dependency Traversal Flow:**
  - `interface/050_record_command_output.py`
  - `interface/interface_common.py`

### Static Route from entrypoint: `interface/060_run_py_compile.py`
- **Advisory Next File to Inspect in Route:** `interface/interface_common.py`
- **Dependency Traversal Flow:**
  - `interface/060_run_py_compile.py`
  - `interface/interface_common.py`

### Static Route from entrypoint: `interface/070_run_headless_gate.py`
- **Advisory Next File to Inspect in Route:** `interface/interface_common.py`
- **Dependency Traversal Flow:**
  - `interface/070_run_headless_gate.py`
  - `interface/interface_common.py`

### Static Route from entrypoint: `interface/080_stamp_result.py`
- **Advisory Next File to Inspect in Route:** `interface/interface_common.py`
- **Dependency Traversal Flow:**
  - `interface/080_stamp_result.py`
  - `interface/interface_common.py`

### Static Route from entrypoint: `interface/090_recover_file_from_git.py`
- **Advisory Next File to Inspect in Route:** `interface/interface_common.py`
- **Dependency Traversal Flow:**
  - `interface/090_recover_file_from_git.py`
  - `interface/interface_common.py`

### Static Route from entrypoint: `interface/999_console.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `interface/999_console.py`

### Static Route from entrypoint: `mechanimation/pose_editor.py`
- **Advisory Next File to Inspect in Route:** `mechanimation/biomechanical_constraints_fixed.py`
- **Dependency Traversal Flow:**
  - `mechanimation/pose_editor.py`
  - `mechanimation/biomechanical_constraints_fixed.py`
  - `mechanimation/primeanim_v4a.py`

### Static Route from entrypoint: `mechanimation/pose_studio.py`
- **Advisory Next File to Inspect in Route:** `mechanimation/biomechanical_constraints_fixed.py`
- **Dependency Traversal Flow:**
  - `mechanimation/pose_studio.py`
  - `mechanimation/biomechanical_constraints_fixed.py`
  - `mechanimation/primeanim_v4a.py`

### Static Route from entrypoint: `mechanimation/primeanim_v4a.py`
- **Advisory Next File to Inspect in Route:** `mechanimation/biomechanical_constraints_fixed.py`
- **Dependency Traversal Flow:**
  - `mechanimation/primeanim_v4a.py`
  - `mechanimation/biomechanical_constraints_fixed.py`

### Static Route from entrypoint: `mettaextgen2/corpus/build_gen2_corpus.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `mettaextgen2/corpus/build_gen2_corpus.py`

### Static Route from entrypoint: `out of root/facade/facade_control_center.py`
- **Advisory Next File to Inspect in Route:** `engain_control/gate_result.py`
- **Dependency Traversal Flow:**
  - `out of root/facade/facade_control_center.py`
  - `engain_control/gate_print.py` ➔ **Inferred Boundary Crossing:** (Facade Subsystem ➔ Engain_control Subsystem)
  - `engain_control/gate_result.py`
  - `out of root/facade/gates/gate_facade_rejection_proof.py` ➔ **Inferred Boundary Crossing:** (Facade Subsystem ➔ Gates Subsystem)
  - `out of root/facade/gates/gate_legacy_wrapped_not_replaced.py`
  - `out of root/facade/gates/gate_migration_status_honest.py`
  - `out of root/facade/gates/gate_no_render_truth_mixed.py`
  - `out of root/facade/gates/gate_no_runtime_entrypoint_import.py`
  - `out of root/facade/gates/gate_no_side_effect_imports.py`
  - `out of root/facade/gates/gate_packet_identity.py` ➔ **Inferred Boundary Crossing:** (Facade Subsystem ➔ Gates Subsystem)
  - `out of root/facade/gates/gate_packet_shape_boundary.py` ➔ **Inferred Boundary Crossing:** (Facade Subsystem ➔ Gates Subsystem)
  - `out of root/facade/gates/gate_safe_import_contract.py` ➔ **Inferred Boundary Crossing:** (Facade Subsystem ➔ Gates Subsystem)

### Static Route from entrypoint: `out of root/gui/archive_gui/official_zw_spec_rules.py`
- **Advisory Next File to Inspect in Route:** `out of root/gui/official_zw_validator.py`
- **Dependency Traversal Flow:**
  - `out of root/gui/archive_gui/official_zw_spec_rules.py` [UNRESOLVED IMPORT]
  - `out of root/gui/official_zw_validator.py` [UNRESOLVED IMPORT] ➔ **Inferred Boundary Crossing:** (Archive_gui Subsystem ➔ Gui Subsystem)

### Static Route from entrypoint: `out of root/gui/archive_gui/official_zw_validator.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/gui/archive_gui/official_zw_validator.py` [UNRESOLVED IMPORT]

### Static Route from entrypoint: `out of root/gui/archive_gui/zw.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/gui/archive_gui/zw.py` [UNRESOLVED IMPORT]

### Static Route from entrypoint: `out of root/gui/cli/pack_zon.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/gui/cli/pack_zon.py`

### Static Route from entrypoint: `out of root/gui/cli/unpack_zon.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/gui/cli/unpack_zon.py`

### Static Route from entrypoint: `out of root/gui/official_zw_spec_rules.py`
- **Advisory Next File to Inspect in Route:** `out of root/gui/official_zw_validator.py`
- **Dependency Traversal Flow:**
  - `out of root/gui/official_zw_spec_rules.py` [UNRESOLVED IMPORT]
  - `out of root/gui/official_zw_validator.py` [UNRESOLVED IMPORT]

### Static Route from entrypoint: `out of root/gui/official_zw_validator.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/gui/official_zw_validator.py` [UNRESOLVED IMPORT]

### Static Route from entrypoint: `out of root/gui/old_zw_gui_enhanced.py`
- **Advisory Next File to Inspect in Route:** `out of root/gui/official_zw_validator.py`
- **Dependency Traversal Flow:**
  - `out of root/gui/old_zw_gui_enhanced.py` [UNRESOLVED IMPORT]
  - `out of root/gui/official_zw_validator.py` [UNRESOLVED IMPORT]
  - `out of root/gui/zon/zon_binary_pack.py` ➔ **Inferred Boundary Crossing:** (Gui Subsystem ➔ Zon Subsystem)

### Static Route from entrypoint: `out of root/gui/older_zw_gui_enhanced.py`
- **Advisory Next File to Inspect in Route:** `out of root/gui/zw/zw_parser.py`
- **Dependency Traversal Flow:**
  - `out of root/gui/older_zw_gui_enhanced.py`
  - `out of root/gui/official_zw_validator.py` [UNRESOLVED IMPORT]
  - `out of root/gui/zw/zw_parser.py` ➔ **Inferred Boundary Crossing:** (Gui Subsystem ➔ Zw Subsystem)

### Static Route from entrypoint: `out of root/gui/tests/test_gui_local_zonb_roundtrip.py`
- **Advisory Next File to Inspect in Route:** `out of root/gui/zw/zw_parser.py`
- **Dependency Traversal Flow:**
  - `out of root/gui/tests/test_gui_local_zonb_roundtrip.py`
  - `out of root/gui/older_zw_gui_enhanced.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Gui Subsystem)
  - `out of root/gui/official_zw_validator.py` [UNRESOLVED IMPORT]
  - `out of root/gui/zw/zw_parser.py` ➔ **Inferred Boundary Crossing:** (Gui Subsystem ➔ Zw Subsystem)
  - `out of root/gui/zon/zon_binary_pack.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Zon Subsystem)

### Static Route from entrypoint: `out of root/gui/tests/test_gui_ux.py`
- **Advisory Next File to Inspect in Route:** `out of root/gui/zw/zw_parser.py`
- **Dependency Traversal Flow:**
  - `out of root/gui/tests/test_gui_ux.py`
  - `out of root/gui/zw_gui.py` [UNRESOLVED IMPORT] ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Gui Subsystem)
  - `out of root/gui/official_zw_validator.py` [UNRESOLVED IMPORT]
  - `out of root/gui/zw/zw_parser.py` ➔ **Inferred Boundary Crossing:** (Gui Subsystem ➔ Zw Subsystem)
  - `tier1/engainos/core/__init__.py` ➔ **Inferred Boundary Crossing:** (Gui Subsystem ➔ Core Subsystem)

### Static Route from entrypoint: `out of root/gui/tests/test_tab_switch.py`
- **Advisory Next File to Inspect in Route:** `out of root/gui/zw/zw_parser.py`
- **Dependency Traversal Flow:**
  - `out of root/gui/tests/test_tab_switch.py`
  - `out of root/gui/zw_gui.py` [UNRESOLVED IMPORT] ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Gui Subsystem)
  - `out of root/gui/official_zw_validator.py` [UNRESOLVED IMPORT]
  - `out of root/gui/zw/zw_parser.py` ➔ **Inferred Boundary Crossing:** (Gui Subsystem ➔ Zw Subsystem)
  - `tier1/engainos/core/__init__.py` ➔ **Inferred Boundary Crossing:** (Gui Subsystem ➔ Core Subsystem)

### Static Route from entrypoint: `out of root/gui/zw/zw_parser.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/gui/zw/zw_parser.py`

### Static Route from entrypoint: `out of root/gui/zw_gui.py`
- **Advisory Next File to Inspect in Route:** `out of root/gui/zw/zw_parser.py`
- **Dependency Traversal Flow:**
  - `out of root/gui/zw_gui.py` [UNRESOLVED IMPORT]
  - `out of root/gui/official_zw_validator.py` [UNRESOLVED IMPORT]
  - `out of root/gui/zw/zw_parser.py` ➔ **Inferred Boundary Crossing:** (Gui Subsystem ➔ Zw Subsystem)
  - `tier1/engainos/core/__init__.py` ➔ **Inferred Boundary Crossing:** (Gui Subsystem ➔ Core Subsystem)

### Static Route from entrypoint: `out of root/legacy2beused/blender/blender-open-mcp-main/addon.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/legacy2beused/blender/blender-open-mcp-main/addon.py`

### Static Route from entrypoint: `out of root/legacy2beused/blender/blender-open-mcp-main/main.py`
- **Advisory Next File to Inspect in Route:** `out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/server.py`
- **Dependency Traversal Flow:**
  - `out of root/legacy2beused/blender/blender-open-mcp-main/main.py`
  - `out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/server.py` ➔ **Inferred Boundary Crossing:** (Blender-open-mcp-main Subsystem ➔ Blender_open_mcp Subsystem)

### Static Route from entrypoint: `out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/mcp_server.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/mcp_server.py`

### Static Route from entrypoint: `out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/server.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/server.py`

### Static Route from entrypoint: `out of root/legacy2beused/blender/blender-open-mcp-main/tests/test_addon.py`
- **Advisory Next File to Inspect in Route:** `out of root/legacy2beused/blender/blender-open-mcp-main/addon.py`
- **Dependency Traversal Flow:**
  - `out of root/legacy2beused/blender/blender-open-mcp-main/tests/test_addon.py`
  - `out of root/legacy2beused/blender/blender-open-mcp-main/addon.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Blender-open-mcp-main Subsystem)

### Static Route from entrypoint: `out of root/legacy2beused/blender/blender-open-mcp-main/tests/test_server.py`
- **Advisory Next File to Inspect in Route:** `out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/server.py`
- **Dependency Traversal Flow:**
  - `out of root/legacy2beused/blender/blender-open-mcp-main/tests/test_server.py`
  - `out of root/legacy2beused/blender/blender-open-mcp-main/src/blender_open_mcp/server.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Blender_open_mcp Subsystem)

### Static Route from entrypoint: `out of root/legacy2beused/blender_scripts/engain_blender_ops.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/legacy2beused/blender_scripts/engain_blender_ops.py`

### Static Route from entrypoint: `out of root/okarchitect/okarchitect.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/okarchitect/okarchitect.py`

### Static Route from entrypoint: `out of root/okarchitect/okarchitect_v2.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/okarchitect/okarchitect_v2.py`

### Static Route from entrypoint: `out of root/okarchitect/okarchitect_v2_fixed.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/okarchitect/okarchitect_v2_fixed.py`

### Static Route from entrypoint: `out of root/okarchitect/okarchitect_v2_multiline_fix.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/okarchitect/okarchitect_v2_multiline_fix.py`

### Static Route from entrypoint: `out of root/okarchitect/okarchitect_v2_robust_input.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/okarchitect/okarchitect_v2_robust_input.py`

### Static Route from entrypoint: `out of root/star_needle_toolbag_patch/blender_scripts/blender_entrypoint.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/star_needle_toolbag_patch/blender_scripts/blender_entrypoint.py`

### Static Route from entrypoint: `out of root/star_needle_toolbag_patch/blender_scripts/blender_mcp_server.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/star_needle_toolbag_patch/blender_scripts/blender_mcp_server.py`

### Static Route from entrypoint: `out of root/star_needle_toolbag_patch/blender_scripts/engain_git_mcp.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/star_needle_toolbag_patch/blender_scripts/engain_git_mcp.py`

### Static Route from entrypoint: `out of root/tools/audit_godot_spawns.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/tools/audit_godot_spawns.py`

### Static Route from entrypoint: `out of root/tools/patch_bridge_integration_upbge_coords_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/tools/patch_bridge_integration_upbge_coords_v1.py`

### Static Route from entrypoint: `out of root/tools/patch_sim_runtime_autorelink_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/tools/patch_sim_runtime_autorelink_v1.py`

### Static Route from entrypoint: `out of root/tools/patch_sim_runtime_autorelink_v2.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/tools/patch_sim_runtime_autorelink_v2.py`

### Static Route from entrypoint: `out of root/tools/patch_sim_runtime_autorelink_v3.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/tools/patch_sim_runtime_autorelink_v3.py`

### Static Route from entrypoint: `out of root/tools/patch_sim_runtime_autorelink_v3b.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/tools/patch_sim_runtime_autorelink_v3b.py`

### Static Route from entrypoint: `out of root/tools/patch_sim_runtime_bridge_entities.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/tools/patch_sim_runtime_bridge_entities.py`

### Static Route from entrypoint: `out of root/tools/patch_sim_runtime_bridge_entities_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/tools/patch_sim_runtime_bridge_entities_v1.py`

### Static Route from entrypoint: `out of root/tools/patch_upbge_bridge_use_position_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/tools/patch_upbge_bridge_use_position_v1.py`

### Static Route from entrypoint: `out of root/tools/patch_zonjrender_transforms_guard_v1.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/tools/patch_zonjrender_transforms_guard_v1.py`

### Static Route from entrypoint: `out of root/tools/proofroom/engionality_showroom/probe_animation_engine.py`
- **Advisory Next File to Inspect in Route:** `out of root/tools/proofroom/engionality_showroom/showroom_fake_env.py`
- **Dependency Traversal Flow:**
  - `out of root/tools/proofroom/engionality_showroom/probe_animation_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/showroom_fake_env.py`
  - `tier2/engionality/controlroom/task_types.py` ➔ **Inferred Boundary Crossing:** (Engionality_showroom Subsystem ➔ Controlroom Subsystem)
  - `tier2/engionality/showroom/animation_engine.py` ➔ **Inferred Boundary Crossing:** (Engionality_showroom Subsystem ➔ Showroom Subsystem)
  - `tier2/engionality/showroom/scene_track.py`

### Static Route from entrypoint: `out of root/tools/proofroom/engionality_showroom/probe_audio_engine.py`
- **Advisory Next File to Inspect in Route:** `out of root/tools/proofroom/engionality_showroom/showroom_fake_env.py`
- **Dependency Traversal Flow:**
  - `out of root/tools/proofroom/engionality_showroom/probe_audio_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/showroom_fake_env.py`
  - `tier2/engionality/controlroom/task_types.py` ➔ **Inferred Boundary Crossing:** (Engionality_showroom Subsystem ➔ Controlroom Subsystem)
  - `tier2/engionality/showroom/audio_engine.py` ➔ **Inferred Boundary Crossing:** (Engionality_showroom Subsystem ➔ Showroom Subsystem)
  - `tier2/engionality/showroom/scene_track.py`

### Static Route from entrypoint: `out of root/tools/proofroom/engionality_showroom/probe_dialogue_engine.py`
- **Advisory Next File to Inspect in Route:** `out of root/tools/proofroom/engionality_showroom/showroom_fake_env.py`
- **Dependency Traversal Flow:**
  - `out of root/tools/proofroom/engionality_showroom/probe_dialogue_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/showroom_fake_env.py`
  - `tier2/engionality/controlroom/task_types.py` ➔ **Inferred Boundary Crossing:** (Engionality_showroom Subsystem ➔ Controlroom Subsystem)
  - `tier2/engionality/showroom/dialogue_engine.py` ➔ **Inferred Boundary Crossing:** (Engionality_showroom Subsystem ➔ Showroom Subsystem)
  - `tier2/engionality/showroom/scene_track.py`

### Static Route from entrypoint: `out of root/tools/proofroom/engionality_showroom/probe_domain_views.py`
- **Advisory Next File to Inspect in Route:** `out of root/tools/proofroom/engionality_showroom/showroom_fake_env.py`
- **Dependency Traversal Flow:**
  - `out of root/tools/proofroom/engionality_showroom/probe_domain_views.py`
  - `out of root/tools/proofroom/engionality_showroom/showroom_fake_env.py`
  - `tier2/engionality/controlroom/task_types.py` ➔ **Inferred Boundary Crossing:** (Engionality_showroom Subsystem ➔ Controlroom Subsystem)
  - `tier2/engionality/showroom/domain_views.py` ➔ **Inferred Boundary Crossing:** (Engionality_showroom Subsystem ➔ Showroom Subsystem)

### Static Route from entrypoint: `out of root/tools/proofroom/engionality_showroom/probe_performer_engine.py`
- **Advisory Next File to Inspect in Route:** `tier2/engionality/showroom/performer_engine.py`
- **Dependency Traversal Flow:**
  - `out of root/tools/proofroom/engionality_showroom/probe_performer_engine.py`
  - `out of root/tools/proofroom/engionality_showroom/showroom_fake_env.py`
  - `tier2/engionality/controlroom/task_types.py` ➔ **Inferred Boundary Crossing:** (Engionality_showroom Subsystem ➔ Controlroom Subsystem)
  - `tier2/engionality/showroom/performer_engine.py` ➔ **Inferred Boundary Crossing:** (Engionality_showroom Subsystem ➔ Showroom Subsystem)
  - `tier2/engionality/showroom/animation_engine.py`
  - `tier2/engionality/showroom/scene_track.py`
  - `tier2/engionality/showroom/audio_engine.py`
  - `tier2/engionality/showroom/dialogue_engine.py`

### Static Route from entrypoint: `out of root/tools/proofroom/engionality_showroom/probe_scene_track.py`
- **Advisory Next File to Inspect in Route:** `out of root/tools/proofroom/engionality_showroom/showroom_fake_env.py`
- **Dependency Traversal Flow:**
  - `out of root/tools/proofroom/engionality_showroom/probe_scene_track.py`
  - `out of root/tools/proofroom/engionality_showroom/showroom_fake_env.py`
  - `tier2/engionality/controlroom/task_types.py` ➔ **Inferred Boundary Crossing:** (Engionality_showroom Subsystem ➔ Controlroom Subsystem)
  - `tier2/engionality/showroom/scene_track.py` ➔ **Inferred Boundary Crossing:** (Engionality_showroom Subsystem ➔ Showroom Subsystem)

### Static Route from entrypoint: `out of root/tools/proofroom/engionality_showroom/run_showroom_probe_suite.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/tools/proofroom/engionality_showroom/run_showroom_probe_suite.py`

### Static Route from entrypoint: `out of root/tools/rebuild_scene_cache.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/tools/rebuild_scene_cache.py`

### Static Route from entrypoint: `out of root/tools/scene_identity_audit.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/scene_identity.py`
- **Dependency Traversal Flow:**
  - `out of root/tools/scene_identity_audit.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Mettaext Subsystem)

### Static Route from entrypoint: `out of root/tools/upbge_list_logic_scripts.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/tools/upbge_list_logic_scripts.py`

### Static Route from entrypoint: `out of root/trae/trae-agent-main/evaluation/patch_selection/analysis.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/analysis.py`

### Static Route from entrypoint: `out of root/trae/trae-agent-main/evaluation/patch_selection/selector.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/trae_agent/tools/ckg/ckg_database.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/selector.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/selector_evaluation.py` ➔ **Inferred Boundary Crossing:** (Patch_selection Subsystem ➔ Trae_selector Subsystem)
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/sandbox.py`
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/selector_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/trae_agent.py` ➔ **Inferred Boundary Crossing:** (Trae_selector Subsystem ➔ Agent Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/agent/agent_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/agent/base_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/docker_manager.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg/ckg_database.py` [STUB] ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Ckg Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg/base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/constants.py` ➔ **Inferred Boundary Crossing:** (Ckg Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/docker_tool_executor.py` [STUB] ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/legacy_config.py` [STUB]
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_client.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/anthropic_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/base_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py` [STUB] ➔ **Inferred Boundary Crossing:** (Llm_clients Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/retry_utils.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/azure_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_compatible_base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/doubao_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/google_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/ollama_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openrouter_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/prompt/agent_prompt.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Prompt Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/mcp_client.py` [STUB] ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/mcp_tool.py` ➔ **Inferred Boundary Crossing:** (Utilities Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/utils.py`

### Static Route from entrypoint: `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/execute_bash.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/bash.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/execute_bash.py` [UNRESOLVED IMPORT]
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/bash.py` [UNRESOLVED IMPORT]

### Static Route from entrypoint: `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/execute_str_replace_editor.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/edit.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/execute_str_replace_editor.py` [UNRESOLVED IMPORT]
  - `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/edit.py` [UNRESOLVED IMPORT]

### Static Route from entrypoint: `out of root/trae/trae-agent-main/evaluation/run_evaluation.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/evaluation/utils.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/evaluation/run_evaluation.py`
  - `out of root/trae/trae-agent-main/evaluation/utils.py`

### Static Route from entrypoint: `out of root/trae/trae-agent-main/tests/agent/test_trae_agent.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/trae_agent/tools/ckg/ckg_database.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/tests/agent/test_trae_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/agent_basics.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Agent Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/agent/trae_agent.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Agent Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/agent/base_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/docker_manager.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg/ckg_database.py` [STUB] ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Ckg Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg/base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/constants.py` ➔ **Inferred Boundary Crossing:** (Ckg Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/docker_tool_executor.py` [STUB] ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/legacy_config.py` [STUB]
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_client.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/anthropic_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/base_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py` [STUB] ➔ **Inferred Boundary Crossing:** (Llm_clients Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/retry_utils.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/azure_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_compatible_base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/doubao_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/google_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/ollama_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openrouter_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/prompt/agent_prompt.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Prompt Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/mcp_client.py` [STUB] ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/mcp_tool.py` ➔ **Inferred Boundary Crossing:** (Utilities Subsystem ➔ Tools Subsystem)

### Static Route from entrypoint: `out of root/trae/trae-agent-main/tests/test_cli.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/trae_agent/tools/ckg/ckg_database.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/tests/test_cli.py`
  - `out of root/trae/trae-agent-main/trae_agent/cli.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Trae_agent Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/agent/trae_agent.py` ➔ **Inferred Boundary Crossing:** (Trae_agent Subsystem ➔ Agent Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/agent/agent_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/agent/base_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/docker_manager.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg/ckg_database.py` [STUB] ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Ckg Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg/base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/constants.py` ➔ **Inferred Boundary Crossing:** (Ckg Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/docker_tool_executor.py` [STUB] ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/legacy_config.py` [STUB]
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_client.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/anthropic_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/base_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py` [STUB] ➔ **Inferred Boundary Crossing:** (Llm_clients Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/retry_utils.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/azure_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_compatible_base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/doubao_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/google_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/ollama_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openrouter_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/prompt/agent_prompt.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Prompt Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/mcp_client.py` [STUB] ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/mcp_tool.py` ➔ **Inferred Boundary Crossing:** (Utilities Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/__init__.py` ➔ **Inferred Boundary Crossing:** (Trae_agent Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/bash_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/run.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/edit_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/json_edit_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/sequential_thinking_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/task_done_tool.py`

### Static Route from entrypoint: `out of root/trae/trae-agent-main/tests/tools/test_bash_tool.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/trae_agent/tools/base.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/tests/tools/test_bash_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/bash_tool.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Tools Subsystem)

### Static Route from entrypoint: `out of root/trae/trae-agent-main/tests/tools/test_edit_tool.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/trae_agent/tools/base.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/tests/tools/test_edit_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/edit_tool.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/run.py`

### Static Route from entrypoint: `out of root/trae/trae-agent-main/tests/tools/test_json_edit_tool.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/trae_agent/tools/base.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/tests/tools/test_json_edit_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/json_edit_tool.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Tools Subsystem)

### Static Route from entrypoint: `out of root/trae/trae-agent-main/tests/tools/test_mcp_tool.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/trae_agent/tools/base.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/tests/tools/test_mcp_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/mcp_tool.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Tools Subsystem)

### Static Route from entrypoint: `out of root/trae/trae-agent-main/tests/utils/test_config.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/tests/utils/test_config.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/legacy_config.py` [STUB]
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/anthropic_client.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py` ➔ **Inferred Boundary Crossing:** (Llm_clients Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/base_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py` [STUB] ➔ **Inferred Boundary Crossing:** (Llm_clients Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/retry_utils.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_client.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Llm_clients Subsystem)

### Static Route from entrypoint: `out of root/trae/trae-agent-main/tests/utils/test_google_client.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/tests/utils/test_google_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/legacy_config.py` [STUB]
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/google_client.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/base_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py` [STUB] ➔ **Inferred Boundary Crossing:** (Llm_clients Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/retry_utils.py`

### Static Route from entrypoint: `out of root/trae/trae-agent-main/tests/utils/test_mcp_client.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/trae_agent/utils/legacy_config.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/tests/utils/test_mcp_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/mcp_client.py` [STUB] ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/mcp_tool.py` ➔ **Inferred Boundary Crossing:** (Utilities Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/legacy_config.py` [STUB]

### Static Route from entrypoint: `out of root/trae/trae-agent-main/tests/utils/test_ollama_client_utils.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/tests/utils/test_ollama_client_utils.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/legacy_config.py` [STUB]
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py` ➔ **Inferred Boundary Crossing:** (Llm_clients Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/ollama_client.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/base_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py` [STUB] ➔ **Inferred Boundary Crossing:** (Llm_clients Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/retry_utils.py`

### Static Route from entrypoint: `out of root/trae/trae-agent-main/tests/utils/test_openrouter_client_utils.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/tests/utils/test_openrouter_client_utils.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/legacy_config.py` [STUB]
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py` ➔ **Inferred Boundary Crossing:** (Llm_clients Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openrouter_client.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_compatible_base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/base_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py` [STUB] ➔ **Inferred Boundary Crossing:** (Llm_clients Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/retry_utils.py`

### Static Route from entrypoint: `out of root/trae/trae-agent-main/trae_agent/cli.py`
- **Advisory Next File to Inspect in Route:** `out of root/trae/trae-agent-main/trae_agent/tools/ckg/ckg_database.py`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/trae_agent/cli.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/trae_agent.py` ➔ **Inferred Boundary Crossing:** (Trae_agent Subsystem ➔ Agent Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/agent/agent_basics.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/base.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_basics.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/agent/base_agent.py`
  - `out of root/trae/trae-agent-main/trae_agent/agent/docker_manager.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg/ckg_database.py` [STUB] ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Ckg Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg/base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/constants.py` ➔ **Inferred Boundary Crossing:** (Ckg Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/docker_tool_executor.py` [STUB] ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/config.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/legacy_config.py` [STUB]
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/llm_client.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Llm_clients Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/anthropic_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/base_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/trajectory_recorder.py` [STUB] ➔ **Inferred Boundary Crossing:** (Llm_clients Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/retry_utils.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/azure_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_compatible_base.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/doubao_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/google_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/ollama_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openai_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/utils/llm_clients/openrouter_client.py`
  - `out of root/trae/trae-agent-main/trae_agent/prompt/agent_prompt.py` ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Prompt Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/utils/mcp_client.py` [STUB] ➔ **Inferred Boundary Crossing:** (Agent Subsystem ➔ Utilities Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/mcp_tool.py` ➔ **Inferred Boundary Crossing:** (Utilities Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/__init__.py` ➔ **Inferred Boundary Crossing:** (Trae_agent Subsystem ➔ Tools Subsystem)
  - `out of root/trae/trae-agent-main/trae_agent/tools/bash_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/ckg_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/run.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/edit_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/json_edit_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/sequential_thinking_tool.py`
  - `out of root/trae/trae-agent-main/trae_agent/tools/task_done_tool.py`

### Static Route from entrypoint: `out of root/trae/trae-agent-main/trae_agent/tools/edit_tool_cli.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/trae_agent/tools/edit_tool_cli.py` [STUB]

### Static Route from entrypoint: `out of root/trae/trae-agent-main/trae_agent/tools/json_edit_tool_cli.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `out of root/trae/trae-agent-main/trae_agent/tools/json_edit_tool_cli.py` [STUB]

### Static Route from entrypoint: `scratch/gameproof_003/retired_cli_bridge/run_gameproof_003_cli.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `scratch/gameproof_003/retired_cli_bridge/run_gameproof_003_cli.py`

### Static Route from entrypoint: `scratch/tier_relocation/trixel/legacy_payloads/harvest_legacy_trixel_payloads.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `scratch/tier_relocation/trixel/legacy_payloads/harvest_legacy_trixel_payloads.py`

### Static Route from entrypoint: `start_button.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `start_button.py`

### Static Route from entrypoint: `tests/test_safe_stack_stop.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tests/test_safe_stack_stop.py`

### Static Route from entrypoint: `tier1/engainos/adapters/zonj_to_gamestate.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/adapters/zonj_to_gamestate.py`

### Static Route from entrypoint: `tier1/engainos/aproom/ap_engine.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/aproom/ap_engine.py`

### Static Route from entrypoint: `tier1/engainos/aproom/ap_quest_rules.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/aproom/ap_quest_rules.py`

### Static Route from entrypoint: `tier1/engainos/aproom/ap_rule_loader.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/aproom/ap_rule_loader.py`

### Static Route from entrypoint: `tier1/engainos/aproom/ap_runtime.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/aproom/ap_zw_engine.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/aproom/ap_runtime.py`
  - `tier1/engainos/aproom/ap_zw_engine.py`

### Static Route from entrypoint: `tier1/engainos/aproom/ap_world_rules.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/aproom/engine_summary.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/aproom/ap_world_rules.py`
  - `tier1/engainos/aproom/engine_summary.py`

### Static Route from entrypoint: `tier1/engainos/aproom/ap_zw_engine.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/aproom/ap_zw_engine.py`

### Static Route from entrypoint: `tier1/engainos/aproom/engine_summary.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/aproom/engine_summary.py`

### Static Route from entrypoint: `tier1/engainos/aproom/protocol_envelope.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/aproom/protocol_envelope.py`

### Static Route from entrypoint: `tier1/engainos/bridgeroom/editor_edit_route.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/authority/local_signed_transport.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/bridgeroom/editor_edit_route.py`
  - `tier1/engainos/authority/editor_edit_authority.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/core/intent_shadow.py` ➔ **Inferred Boundary Crossing:** (Authority Subsystem ➔ Core Subsystem)
  - `tier1/engainos/authority/local_signed_transport.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/bridgeroom/stageroom_scene_resolver.py`

### Static Route from entrypoint: `tier1/engainos/bridgeroom/godot_adapter.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/bridgeroom/spatial_skin_system.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/bridgeroom/godot_adapter.py`
  - `tier1/engainos/bridgeroom/spatial_skin_system.py`
  - `tier1/engainos/bridgeroom/zon_to_entities.py`
  - `tier1/engainos/bridgeroom/mesh_manifest.py`

### Static Route from entrypoint: `tier1/engainos/bridgeroom/quest3d_integration.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/quest3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/bridgeroom/quest3d_integration.py`
  - `tier2/godotsim/kernels/quest3d_mr.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier1/engainos/bridgeroom/scene_loader.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/scene_identity.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/bridgeroom/scene_loader.py`
  - `tier1/engainos/bridgeroom/spatial_reasoner.py`
  - `tier1/engainos/bridgeroom/spatial_skin_system.py`
  - `tier1/engainos/bridgeroom/stageroom_scene_resolver.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier1/engainos/bridgeroom/scene_server.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/bridgeroom/trixel32d_live_route.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/bridgeroom/scene_server.py`
  - `tier1/engainos/authority/local_signed_transport.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/bridgeroom/scene_loader.py`
  - `tier1/engainos/bridgeroom/spatial_reasoner.py`
  - `tier1/engainos/bridgeroom/spatial_skin_system.py`
  - `tier1/engainos/bridgeroom/stageroom_scene_resolver.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Mettaext Subsystem)
  - `tier1/engainos/bridgeroom/trixel32d_live_route.py`
  - `tier1/engainos/authority/trixel32d_application_grant.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/authority/trixel32d_live_authority_state.py`
  - `tier1/engainos/gates/gate_trixel32d_handshake.py` ➔ **Inferred Boundary Crossing:** (Authority Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/gates/gate_trixel32d_surface_apply.py` ➔ **Inferred Boundary Crossing:** (Authority Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/authority/trixel32d_live_application_issuer.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/bridgeroom/trixel32d_built_drop_intake.py`
  - `tier1/engainos/bridgeroom/trixel32d_request_assembler.py`
  - `tier1/engainos/bridgeroom/trixel32d_request_dispatch.py`

### Static Route from entrypoint: `tier1/engainos/bridgeroom/zon_to_game.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/bridgeroom/zon_to_game.py`

### Static Route from entrypoint: `tier1/engainos/core/no_godot_scene_proof.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/core/no_godot_scene_proof.py`

### Static Route from entrypoint: `tier1/engainos/engainos_control_center.py`
- **Advisory Next File to Inspect in Route:** `engain_control/gate_result.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/engainos_control_center.py`
  - `engain_control/gate_print.py` ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Engain_control Subsystem)
  - `engain_control/gate_result.py`
  - `tier1/engainos/gates/gate_acceptance_rule.py` ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/gates/gate_declared_truth_shape.py` ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/gates/gate_governance_rejection_proof.py` ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/gates/gate_no_asset_production.py`
  - `tier1/engainos/gates/gate_no_presentation_authority.py`
  - `tier1/engainos/gates/gate_no_simulation_execution.py`
  - `tier1/engainos/gates/gate_no_lane_theft_in_packet.py` ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/gates/gate_packet_identity.py` ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/gates/gate_validated_packets_shape.py` ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Gates Subsystem)

### Static Route from entrypoint: `tier1/engainos/engainos_server.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/runtime_client.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/engainos_server.py`
  - `tier1/engainos/aproom/authority_gate.py` [STUB] ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_rule_evaluator.py`
  - `tier1/engainos/aproom/ap_rule_loader.py`
  - `tier1/engainos/runtime_client.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_core_behavior_parity.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_core_behavior_parity.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_core_migration_authority.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_core_migration_authority.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_core_rule_activation.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_core_rule_activation.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_core_signature_probe.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_core_signature_probe.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_default_rules_registered.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/core/__init__.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_default_rules_registered.py`
  - `tier1/engainos/core/__init__.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Core Subsystem)

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_engine_historical_probe.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_engine_historical_probe.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_engine_historical_source_map.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_engine_historical_source_map.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_engine_migration_authority.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_engine_migration_authority.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_runtime_behavior_probe.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_runtime_behavior_probe.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_runtime_blocker_lane.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_runtime_blocker_lane.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_runtime_relay_behavior.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/relays/ap_runtime_relay.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_runtime_relay_behavior.py`
  - `tier1/engainos/relays/ap_runtime_relay.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Relays Subsystem)

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_runtime_relay_readiness.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_runtime_relay_readiness.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_runtime_relay_real_integration.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/relays/ap_runtime_relay.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_runtime_relay_real_integration.py`
  - `tier1/engainos/relays/ap_runtime_relay.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Relays Subsystem)

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_runtime_repair_readiness.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_runtime_repair_readiness.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_zw_engine_canonical_claim.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_zw_engine_canonical_claim.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_zw_engine_migration.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_zw_engine_migration.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_ap_zw_engine_timeline_fence.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/core/__init__.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_ap_zw_engine_timeline_fence.py`
  - `tier1/engainos/core/__init__.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Core Subsystem)

### Static Route from entrypoint: `tier1/engainos/gates/gate_controlled_runtime_salvage_lane.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_controlled_runtime_salvage_lane.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_gamestate_draft_review_contract.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_gamestate_draft_review_contract.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_gamestate_draft_review_ready.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_gamestate_draft_review_ready.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_governance_contract_board.py`
- **Advisory Next File to Inspect in Route:** `engain_control/gate_result.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_governance_contract_board.py`
  - `tier1/engainos/gates/gate_acceptance_rule.py`
  - `engain_control/gate_result.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Engain_control Subsystem)
  - `tier1/engainos/gates/gate_declared_truth_shape.py`
  - `tier1/engainos/gates/gate_no_asset_production.py`
  - `tier1/engainos/gates/gate_no_lane_theft_in_packet.py`
  - `tier1/engainos/gates/gate_no_presentation_authority.py`
  - `tier1/engainos/gates/gate_no_simulation_execution.py`
  - `tier1/engainos/gates/gate_packet_identity.py`
  - `tier1/engainos/gates/gate_validated_packets_shape.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_safe_server_wrapper_behavior_lane.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_safe_server_wrapper_behavior_lane.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_safe_server_wrapper_blueprint_lane.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_safe_server_wrapper_blueprint_lane.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_safe_server_wrapper_implementation_lane.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_safe_server_wrapper_implementation_lane.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_server_entrypoint_repair_lane.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_server_entrypoint_repair_lane.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_server_runtime_preflight_lane.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_server_runtime_preflight_lane.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_trixel32d_handshake.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_trixel32d_handshake.py`

### Static Route from entrypoint: `tier1/engainos/gates/gate_vault_boot_side_effect_fence_lane.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/gate_vault_boot_side_effect_fence_lane.py`

### Static Route from entrypoint: `tier1/engainos/gates/run_active_gates.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/gates/run_active_gates.py`

### Static Route from entrypoint: `tier1/engainos/launch_engine.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/bridgeroom/trixel32d_live_route.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/launch_engine.py`
  - `tier1/engainos/aproom/ap_engine.py` ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_runtime.py` ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_zw_engine.py`
  - `tier1/engainos/authority/trixel32d_live_authority_state.py` ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/gates/gate_trixel32d_handshake.py` ➔ **Inferred Boundary Crossing:** (Authority Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/gates/gate_trixel32d_surface_apply.py` ➔ **Inferred Boundary Crossing:** (Authority Subsystem ➔ Gates Subsystem)
  - `tier1/engainos/bridgeroom/editor_edit_route.py` ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/authority/editor_edit_authority.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/core/intent_shadow.py` ➔ **Inferred Boundary Crossing:** (Authority Subsystem ➔ Core Subsystem)
  - `tier1/engainos/authority/local_signed_transport.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/bridgeroom/stageroom_scene_resolver.py`
  - `tier1/engainos/bridgeroom/godot_adapter.py` ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/bridgeroom/spatial_skin_system.py`
  - `tier1/engainos/bridgeroom/zon_to_entities.py`
  - `tier1/engainos/bridgeroom/mesh_manifest.py`
  - `tier1/engainos/bridgeroom/scene_server.py` ➔ **Inferred Boundary Crossing:** (Engainos Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/bridgeroom/scene_loader.py`
  - `tier1/engainos/bridgeroom/spatial_reasoner.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Mettaext Subsystem)
  - `tier1/engainos/bridgeroom/trixel32d_live_route.py`
  - `tier1/engainos/authority/trixel32d_application_grant.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/authority/trixel32d_live_application_issuer.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/bridgeroom/trixel32d_built_drop_intake.py`
  - `tier1/engainos/bridgeroom/trixel32d_request_assembler.py`
  - `tier1/engainos/bridgeroom/trixel32d_request_dispatch.py`

### Static Route from entrypoint: `tier1/engainos/server/presence_authority_server.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/bridgeroom/shared_session_bridge.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/server/presence_authority_server.py`
  - `tier1/engainos/bridgeroom/claude_code_provider_adapter.py` ➔ **Inferred Boundary Crossing:** (Server Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/core/provider_session_binding.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/presence_registry.py`
  - `tier1/engainos/core/session_ledger.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/session_journal.py`
  - `tier1/engainos/bridgeroom/hermes_provider_adapter.py` ➔ **Inferred Boundary Crossing:** (Server Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/bridgeroom/shared_session_bridge.py` ➔ **Inferred Boundary Crossing:** (Server Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/core/continuity_context_builder.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/continuity_cursor_tracker.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/session_claim_registry.py` ➔ **Inferred Boundary Crossing:** (Server Subsystem ➔ Core Subsystem)

### Static Route from entrypoint: `tier1/engainos/tests/test_scene_loader_stageroom.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/scene_identity.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tests/test_scene_loader_stageroom.py`
  - `tier1/engainos/bridgeroom/scene_loader.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Bridgeroom Subsystem)
  - `tier1/engainos/bridgeroom/spatial_reasoner.py`
  - `tier1/engainos/bridgeroom/spatial_skin_system.py`
  - `tier1/engainos/bridgeroom/stageroom_scene_resolver.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier1/engainos/tests/test_trixel32d_request_assembler.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/gates/gate_trixel32d_handshake.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tests/test_trixel32d_request_assembler.py`
  - `tier1/engainos/bridgeroom/trixel32d_request_assembler.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Bridgeroom Subsystem)
  - `tier1/engainos/gates/gate_trixel32d_handshake.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Gates Subsystem)
  - `tier2/worldfield/grid_facts_emitter.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Worldfield Subsystem)
  - `tier2/worldfield/trixel_world_adapter.py`
  - `tier2/worldfield/terrain_thresholds.py`
  - `tier2/worldfield/world_field_nucleus.py`

### Static Route from entrypoint: `tier1/engainos/tools/chapter_discovery.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tools/chapter_discovery.py`

### Static Route from entrypoint: `tier1/engainos/tools/chapter_splitter/chapter_to_stage_packets.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tools/chapter_splitter/chapter_to_stage_packets.py`

### Static Route from entrypoint: `tier1/engainos/tools/chapter_splitter/promote_stage_draft.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tools/chapter_splitter/promote_stage_draft.py`

### Static Route from entrypoint: `tier1/engainos/tools/live_avatar_continuity_integration_proof.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tools/live_avatar_continuity_integration_proof.py`

### Static Route from entrypoint: `tier1/engainos/tools/live_claude_code_continuity_proof.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/bridgeroom/shared_session_bridge.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tools/live_claude_code_continuity_proof.py`
  - `tier1/engainos/bridgeroom/claude_code_provider_adapter.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/core/provider_session_binding.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/presence_registry.py`
  - `tier1/engainos/core/session_ledger.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/session_journal.py`
  - `tier1/engainos/bridgeroom/shared_session_bridge.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/core/continuity_context_builder.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/continuity_cursor_tracker.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)

### Static Route from entrypoint: `tier1/engainos/tools/live_cross_provider_mailbox_portability_proof.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/bridgeroom/shared_session_bridge.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tools/live_cross_provider_mailbox_portability_proof.py`
  - `tier1/engainos/bridgeroom/claude_code_provider_adapter.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/core/provider_session_binding.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/presence_registry.py`
  - `tier1/engainos/core/session_ledger.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/session_journal.py`
  - `tier1/engainos/bridgeroom/hermes_provider_adapter.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/bridgeroom/mailbox_request_handler.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/bridgeroom/shared_session_bridge.py`
  - `tier1/engainos/core/continuity_context_builder.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/continuity_cursor_tracker.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)

### Static Route from entrypoint: `tier1/engainos/tools/live_cross_provider_portability_proof.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/bridgeroom/shared_session_bridge.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tools/live_cross_provider_portability_proof.py`
  - `tier1/engainos/bridgeroom/claude_code_provider_adapter.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/core/provider_session_binding.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/presence_registry.py`
  - `tier1/engainos/core/session_ledger.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/session_journal.py`
  - `tier1/engainos/bridgeroom/hermes_provider_adapter.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/bridgeroom/shared_session_bridge.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/core/continuity_context_builder.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/continuity_cursor_tracker.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)

### Static Route from entrypoint: `tier1/engainos/tools/live_dispatch_mutex_contention_proof.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tools/live_dispatch_mutex_contention_proof.py`

### Static Route from entrypoint: `tier1/engainos/tools/live_hermes_continuity_proof.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/bridgeroom/shared_session_bridge.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tools/live_hermes_continuity_proof.py`
  - `tier1/engainos/bridgeroom/hermes_provider_adapter.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/core/provider_session_binding.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/presence_registry.py`
  - `tier1/engainos/core/session_ledger.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/session_journal.py`
  - `tier1/engainos/bridgeroom/shared_session_bridge.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Bridgeroom Subsystem)
  - `tier1/engainos/core/continuity_context_builder.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/continuity_cursor_tracker.py` ➔ **Inferred Boundary Crossing:** (Bridgeroom Subsystem ➔ Core Subsystem)

### Static Route from entrypoint: `tier1/engainos/tools/live_journal_restart_proofs.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/core/session_ledger.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tools/live_journal_restart_proofs.py`
  - `tier1/engainos/core/continuity_cursor_tracker.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/session_ledger.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/session_journal.py`

### Static Route from entrypoint: `tier1/engainos/tools/live_torn_tail_recovery_proof.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/core/session_ledger.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tools/live_torn_tail_recovery_proof.py`
  - `tier1/engainos/core/continuity_cursor_tracker.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/session_journal.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Core Subsystem)
  - `tier1/engainos/core/session_ledger.py` ➔ **Inferred Boundary Crossing:** (Tools Subsystem ➔ Core Subsystem)

### Static Route from entrypoint: `tier1/engainos/tools/vault_discovery.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/tools/vault_discovery.py`

### Static Route from entrypoint: `tier1/engainos/validators/runtime_stage_identity.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/engainos/validators/runtime_stage_identity.py`

### Static Route from entrypoint: `tier1/engainos/validators/runtime_stage_manifest.py`
- **Advisory Next File to Inspect in Route:** `tier1/engainos/validators/runtime_stage_identity.py`
- **Dependency Traversal Flow:**
  - `tier1/engainos/validators/runtime_stage_manifest.py`
  - `tier1/engainos/validators/runtime_stage_identity.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/artifact_extractor.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/artifact_extractor.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/authority_score_calculator.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/authority_score_calculator.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/build_codex_candidates.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/build_codex_candidates.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/build_registry.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/build_registry.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/chapter_ledger_extractor.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/chapter_ledger_extractor.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/compile_entity_states.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/compile_entity_states.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/continuity_audit.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/continuity_audit.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/draft_rel_evidence_review.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/draft_rel_evidence_review.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/extract_candidates.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/extract_candidates.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/extract_member_of.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/extract_member_of.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/identity_review_queue.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/identity_review_queue.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/identity_reviewer.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/identity_reviewer.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/identity_signal_math.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/identity_signal_math.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/ingest_source_stub.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/ingest_source_stub.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/lint_codex_candidates.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/lint_codex_candidates.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/lint_entity_contract.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/lint_entity_contract.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/lint_relationship_schema.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/lint_relationship_schema.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/lint_scene_contract.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/lint_scene_contract.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/lint_wiki.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/lint_wiki.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/mrlore_query.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/mrlore_query.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/mrlore_rebuild_findings.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/mrlore_rebuild_findings.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/mrlore_run_changed.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/mrlore_run_changed.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/mrlore_session.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/mrlore_session.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/ollama_ingest_cockpit.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/ollama_ingest_cockpit.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/pass2_math.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/pass2_math.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/populate_registry.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/populate_registry.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/promote_candidate.py`
- **Advisory Next File to Inspect in Route:** `tier1/mrlore/archive/old_tools/authority_score_calculator.py`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/promote_candidate.py`
  - `tier1/mrlore/archive/old_tools/authority_score_calculator.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/promotion_eligibility_gate.py`
- **Advisory Next File to Inspect in Route:** `tier1/mrlore/archive/old_tools/authority_score_calculator.py`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/promotion_eligibility_gate.py`
  - `tier1/mrlore/archive/old_tools/authority_score_calculator.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/propose_corrections.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/propose_corrections.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/propose_rel_source_stubs.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/propose_rel_source_stubs.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/propose_rel_summaries.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/propose_rel_summaries.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/provisional_identity_router.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/provisional_identity_router.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/registry_builder.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/registry_builder.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/stb_lint.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/stb_lint.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/stb_scanner.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/stb_scanner.py`

### Static Route from entrypoint: `tier1/mrlore/archive/old_tools/write_changed_manifest.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/archive/old_tools/write_changed_manifest.py`

### Static Route from entrypoint: `tier1/mrlore/evidence/proofs/phase_4/collect_delta.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/evidence/proofs/phase_4/collect_delta.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_accepted_lore_packet_schema.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_accepted_lore_packet_schema.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_claim_extraction_runner.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_claim_extraction_runner.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_coming_calendar_registry_gate.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_coming_calendar_registry_gate.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_contradiction_candidate_audit_summary.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_contradiction_candidate_audit_summary.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_contradiction_candidate_grouper.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_contradiction_candidate_grouper.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_control_center.py`
- **Advisory Next File to Inspect in Route:** `engain_control/gate_result.py`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_control_center.py`
  - `engain_control/gate_print.py` ➔ **Inferred Boundary Crossing:** (Mrlore Subsystem ➔ Engain_control Subsystem)
  - `engain_control/gate_result.py`
  - `tier1/mrlore/gates/gate_claims_structure.py` ➔ **Inferred Boundary Crossing:** (Mrlore Subsystem ➔ Gates Subsystem)
  - `tier1/mrlore/gates/gate_contradiction_stop_proof.py` ➔ **Inferred Boundary Crossing:** (Mrlore Subsystem ➔ Gates Subsystem)
  - `tier1/mrlore/gates/gate_contradictions_valid_if_present.py`
  - `tier1/mrlore/gates/gate_enum_values_valid.py` ➔ **Inferred Boundary Crossing:** (Mrlore Subsystem ➔ Gates Subsystem)
  - `tier1/mrlore/gates/gate_no_auto_resolve_attempt.py` ➔ **Inferred Boundary Crossing:** (Mrlore Subsystem ➔ Gates Subsystem)
  - `tier1/mrlore/gates/gate_no_lane_theft_in_packet.py` ➔ **Inferred Boundary Crossing:** (Mrlore Subsystem ➔ Gates Subsystem)
  - `tier1/mrlore/gates/gate_no_vault_path_dependency.py` ➔ **Inferred Boundary Crossing:** (Mrlore Subsystem ➔ Gates Subsystem)
  - `tier1/mrlore/gates/gate_required_fields.py` ➔ **Inferred Boundary Crossing:** (Mrlore Subsystem ➔ Gates Subsystem)

### Static Route from entrypoint: `tier1/mrlore/mrlore_cosmic_year_context_enrichment.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_cosmic_year_context_enrichment.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_entity_candidate_quality_gate.py`
- **Advisory Next File to Inspect in Route:** `tier1/mrlore/mrlore_preserve_entity_allowlist_registry_gate.py`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_entity_candidate_quality_gate.py`
  - `tier1/mrlore/mrlore_preserve_entity_allowlist_registry_gate.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_high_claim_scene_review_manifest.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_high_claim_scene_review_manifest.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_major_event_internal_receipt_map.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_major_event_internal_receipt_map.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_manual_review_decision_example_writer.py`
- **Advisory Next File to Inspect in Route:** `tier1/mrlore/mrlore_manual_review_decision_schema.py`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_manual_review_decision_example_writer.py`
  - `tier1/mrlore/mrlore_manual_review_decision_schema.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_manual_review_decision_schema.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_manual_review_decision_schema.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_p3_sequential_entity_second_pass_quality_audit.py`
- **Advisory Next File to Inspect in Route:** `tier1/mrlore/mrlore_preserve_entity_allowlist_registry_gate.py`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_p3_sequential_entity_second_pass_quality_audit.py`
  - `tier1/mrlore/mrlore_preserve_entity_allowlist_registry_gate.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_predicate_collision_policy_registry_gate.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_predicate_collision_policy_registry_gate.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_preserve_entity_allowlist_registry_gate.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_preserve_entity_allowlist_registry_gate.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_proposed_claim_audit_summary.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_proposed_claim_audit_summary.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_proposed_claim_shape_gate.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_proposed_claim_shape_gate.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_quality_aware_queue_summary.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_quality_aware_queue_summary.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_quality_aware_review_queue_builder.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_quality_aware_review_queue_builder.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_review_queue_builder.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_review_queue_builder.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_review_queue_clean_view.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_review_queue_clean_view.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_review_queue_noise_audit.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_review_queue_noise_audit.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_review_rail_health_runner.py`
- **Advisory Next File to Inspect in Route:** `tier1/mrlore/mrlore_preserve_entity_allowlist_registry_gate.py`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_review_rail_health_runner.py`
  - `tier1/mrlore/mrlore_claim_extraction_runner.py`
  - `tier1/mrlore/mrlore_contradiction_candidate_audit_summary.py`
  - `tier1/mrlore/mrlore_contradiction_candidate_grouper.py`
  - `tier1/mrlore/mrlore_entity_candidate_quality_gate.py`
  - `tier1/mrlore/mrlore_preserve_entity_allowlist_registry_gate.py`
  - `tier1/mrlore/mrlore_high_claim_scene_review_manifest.py`
  - `tier1/mrlore/mrlore_manual_review_decision_example_writer.py`
  - `tier1/mrlore/mrlore_manual_review_decision_schema.py`
  - `tier1/mrlore/mrlore_proposed_claim_audit_summary.py`
  - `tier1/mrlore/mrlore_proposed_claim_shape_gate.py`
  - `tier1/mrlore/mrlore_quality_aware_queue_summary.py`
  - `tier1/mrlore/mrlore_quality_aware_review_queue_builder.py`
  - `tier1/mrlore/mrlore_review_queue_builder.py`
  - `tier1/mrlore/mrlore_review_queue_clean_view.py`
  - `tier1/mrlore/mrlore_review_queue_noise_audit.py`
  - `tier1/mrlore/mrlore_revision_breathing_map.py`
  - `tier1/mrlore/mrlore_revision_breathing_map_guidance_gate.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_revision_breathing_map.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_revision_breathing_map.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_revision_breathing_map_guidance_gate.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_revision_breathing_map_guidance_gate.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_scene_intake_runner.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_scene_intake_runner.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_temporal_aware_queue_summary.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_temporal_aware_queue_summary.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_temporal_aware_review_by_chapter_view.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_temporal_aware_review_by_chapter_view.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_temporal_aware_review_queue_builder.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_temporal_aware_review_queue_builder.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_temporal_claim_context_enrichment.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_temporal_claim_context_enrichment.py`

### Static Route from entrypoint: `tier1/mrlore/mrlore_temporal_collision_classification.py`
- **Advisory Next File to Inspect in Route:** `tier1/mrlore/mrlore_predicate_collision_policy_registry_gate.py`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/mrlore_temporal_collision_classification.py`
  - `tier1/mrlore/mrlore_predicate_collision_policy_registry_gate.py`

### Static Route from entrypoint: `tier1/mrlore/tools/mrlore_full_output_dump.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/mrlore/tools/mrlore_full_output_dump.py`

### Static Route from entrypoint: `tier1/paradox_machine/proofs/export_gate_triad_result_zw.py`
- **Advisory Next File to Inspect in Route:** `tier1/paradox_machine/zwcodecs/json_to_zw.py`
- **Dependency Traversal Flow:**
  - `tier1/paradox_machine/proofs/export_gate_triad_result_zw.py`
  - `tier1/paradox_machine/zwcodecs/json_to_zw.py` ➔ **Inferred Boundary Crossing:** (Proofs Subsystem ➔ Zwcodecs Subsystem)

### Static Route from entrypoint: `tier1/paradox_machine/proofs/proof_007_temporal_mvp.py`
- **Advisory Next File to Inspect in Route:** `tier1/paradox_machine/schemas/temporal_artifact.py`
- **Dependency Traversal Flow:**
  - `tier1/paradox_machine/proofs/proof_007_temporal_mvp.py`
  - `tier1/paradox_machine/extraction/naive_temporal_extractor.py` ➔ **Inferred Boundary Crossing:** (Proofs Subsystem ➔ Extraction Subsystem)
  - `tier1/paradox_machine/schemas/temporal_artifact.py` ➔ **Inferred Boundary Crossing:** (Extraction Subsystem ➔ Schemas Subsystem)
  - `tier1/paradox_machine/gates/temporal_gate.py` ➔ **Inferred Boundary Crossing:** (Proofs Subsystem ➔ Gates Subsystem)
  - `tier1/paradox_machine/reasoning/temporal_validator.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Reasoning Subsystem)
  - `tier1/paradox_machine/reasoning/allen_relations.py`

### Static Route from entrypoint: `tier1/paradox_machine/proofs/proof_007b_temporal_rejection.py`
- **Advisory Next File to Inspect in Route:** `tier1/paradox_machine/schemas/temporal_artifact.py`
- **Dependency Traversal Flow:**
  - `tier1/paradox_machine/proofs/proof_007b_temporal_rejection.py`
  - `tier1/paradox_machine/gates/temporal_gate.py` ➔ **Inferred Boundary Crossing:** (Proofs Subsystem ➔ Gates Subsystem)
  - `tier1/paradox_machine/reasoning/temporal_validator.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Reasoning Subsystem)
  - `tier1/paradox_machine/reasoning/allen_relations.py`
  - `tier1/paradox_machine/schemas/temporal_artifact.py` ➔ **Inferred Boundary Crossing:** (Reasoning Subsystem ➔ Schemas Subsystem)

### Static Route from entrypoint: `tier1/paradox_machine/proofs/proof_008_spatiotemporal_gate_stub.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/paradox_machine/proofs/proof_008_spatiotemporal_gate_stub.py`

### Static Route from entrypoint: `tier1/paradox_machine/proofs/read_paradox_machine_gate_triad_result.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/paradox_machine/proofs/read_paradox_machine_gate_triad_result.py`

### Static Route from entrypoint: `tier1/paradox_machine/proofs/run_paradox_machine_gate_triad.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier1/paradox_machine/proofs/run_paradox_machine_gate_triad.py`

### Static Route from entrypoint: `tier2/engionality/controlroom/bootstrap.py`
- **Advisory Next File to Inspect in Route:** `tier2/engionality/showroom/performer_engine.py`
- **Dependency Traversal Flow:**
  - `tier2/engionality/controlroom/bootstrap.py`
  - `tier2/engionality/controlroom/runtime_loop.py`
  - `tier2/engionality/controlroom/task_types.py`
  - `tier2/engionality/showroom/domain_views.py` ➔ **Inferred Boundary Crossing:** (Controlroom Subsystem ➔ Showroom Subsystem)
  - `tier2/engionality/showroom/performer_engine.py` ➔ **Inferred Boundary Crossing:** (Controlroom Subsystem ➔ Showroom Subsystem)
  - `tier2/engionality/showroom/animation_engine.py`
  - `tier2/engionality/showroom/scene_track.py`
  - `tier2/engionality/showroom/audio_engine.py`
  - `tier2/engionality/showroom/dialogue_engine.py`
  - `tier2/engionality/controlroom/zon4d_kernel.py`

### Static Route from entrypoint: `tier2/engionality/controlroom/performance_harness.py`
- **Advisory Next File to Inspect in Route:** `tier2/engionality/showroom/performer_engine.py`
- **Dependency Traversal Flow:**
  - `tier2/engionality/controlroom/performance_harness.py`
  - `tier2/engionality/showroom/performer_engine.py` ➔ **Inferred Boundary Crossing:** (Controlroom Subsystem ➔ Showroom Subsystem)
  - `tier2/engionality/controlroom/task_types.py` ➔ **Inferred Boundary Crossing:** (Showroom Subsystem ➔ Controlroom Subsystem)
  - `tier2/engionality/showroom/animation_engine.py`
  - `tier2/engionality/showroom/scene_track.py`
  - `tier2/engionality/showroom/audio_engine.py`
  - `tier2/engionality/showroom/dialogue_engine.py`

### Static Route from entrypoint: `tier2/engionality/controlroom/zon4d_kernel.py`
- **Advisory Next File to Inspect in Route:** `tier2/engionality/showroom/performer_engine.py`
- **Dependency Traversal Flow:**
  - `tier2/engionality/controlroom/zon4d_kernel.py`
  - `tier2/engionality/controlroom/runtime_loop.py`
  - `tier2/engionality/controlroom/task_types.py`
  - `tier2/engionality/showroom/domain_views.py` ➔ **Inferred Boundary Crossing:** (Controlroom Subsystem ➔ Showroom Subsystem)
  - `tier2/engionality/showroom/performer_engine.py` ➔ **Inferred Boundary Crossing:** (Controlroom Subsystem ➔ Showroom Subsystem)
  - `tier2/engionality/showroom/animation_engine.py`
  - `tier2/engionality/showroom/scene_track.py`
  - `tier2/engionality/showroom/audio_engine.py`
  - `tier2/engionality/showroom/dialogue_engine.py`

### Static Route from entrypoint: `tier2/engionality/engionality_control_center.py`
- **Advisory Next File to Inspect in Route:** `engain_control/gate_result.py`
- **Dependency Traversal Flow:**
  - `tier2/engionality/engionality_control_center.py`
  - `engain_control/gate_print.py` ➔ **Inferred Boundary Crossing:** (Engionality Subsystem ➔ Engain_control Subsystem)
  - `engain_control/gate_result.py`
  - `tier2/engionality/gates/gate_affect_state_valid.py` ➔ **Inferred Boundary Crossing:** (Engionality Subsystem ➔ Gates Subsystem)
  - `tier2/engionality/gates/gate_intensity_bounds.py` ➔ **Inferred Boundary Crossing:** (Engionality Subsystem ➔ Gates Subsystem)
  - `tier2/engionality/gates/gate_no_lane_theft_in_packet.py` ➔ **Inferred Boundary Crossing:** (Engionality Subsystem ➔ Gates Subsystem)
  - `tier2/engionality/gates/gate_relationship_deltas_valid_if_present.py` ➔ **Inferred Boundary Crossing:** (Engionality Subsystem ➔ Gates Subsystem)
  - `tier2/engionality/gates/gate_required_fields.py` ➔ **Inferred Boundary Crossing:** (Engionality Subsystem ➔ Gates Subsystem)
  - `tier2/engionality/gates/gate_scene_mood_valid_if_present.py` ➔ **Inferred Boundary Crossing:** (Engionality Subsystem ➔ Gates Subsystem)

### Static Route from entrypoint: `tier2/godotsim/adapters/combat3d_integration.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/combat3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/adapters/combat3d_integration.py`
  - `tier2/godotsim/kernels/combat3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/adapters/dialogue3d_integration.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/dialogue3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/adapters/dialogue3d_integration.py`
  - `tier2/godotsim/kernels/dialogue3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/adapters/inventory3d_integration.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/inventory3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/adapters/inventory3d_integration.py`
  - `tier2/godotsim/kernels/inventory3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/adapters/navigation_adapter.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/slice_builders.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/adapters/navigation_adapter.py`
  - `tier2/godotsim/slice_builders.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Godotsim Subsystem)
  - `tier2/godotsim/slice_types.py`

### Static Route from entrypoint: `tier2/godotsim/adapters/spatial3d_adapter.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/spatial3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/adapters/spatial3d_adapter.py`
  - `tier2/godotsim/kernels/spatial3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/spatial3d.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Godotsim Subsystem)

### Static Route from entrypoint: `tier2/godotsim/gates/gate_floor_headless_parse_proof.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/piece3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/gates/gate_floor_headless_parse_proof.py`
  - `tier2/godotsim/kernels/piece3d_mr.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/gates/gate_ollama_diff_patcher_tests.py`
- **Advisory Next File to Inspect in Route:** `tools/ollama_diff_patcher.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/gates/gate_ollama_diff_patcher_tests.py`
  - `tools/ollama_diff_patcher.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Tools Subsystem)

### Static Route from entrypoint: `tier2/godotsim/gates/gate_piece3d_baseline.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/piece3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/gates/gate_piece3d_baseline.py`
  - `tier2/godotsim/kernels/piece3d_mr.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/gates/gate_piece_recipe_pack_001.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/piece3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/gates/gate_piece_recipe_pack_001.py`
  - `tier2/godotsim/kernels/piece3d_mr.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/gates/gate_piece_recipe_pack_001_visible_proof.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/builders/godot_scene_piece_builder.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/gates/gate_piece_recipe_pack_001_visible_proof.py`
  - `tier2/godotsim/builders/godot_scene_piece_builder.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Builders Subsystem)
  - `tier2/godotsim/kernels/piece3d_mr.py` ➔ **Inferred Boundary Crossing:** (Builders Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/gates/gate_piece_recipe_pack_002_door_proof.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/builders/godot_scene_piece_builder.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/gates/gate_piece_recipe_pack_002_door_proof.py`
  - `tier2/godotsim/builders/godot_scene_piece_builder.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Builders Subsystem)
  - `tier2/godotsim/kernels/piece3d_mr.py` ➔ **Inferred Boundary Crossing:** (Builders Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/gates/gate_player_body_visible_proof.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/builders/godot_scene_piece_builder.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/gates/gate_player_body_visible_proof.py`
  - `tier2/godotsim/builders/godot_scene_piece_builder.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Builders Subsystem)
  - `tier2/godotsim/kernels/piece3d_mr.py` ➔ **Inferred Boundary Crossing:** (Builders Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/gates/gate_player_movement_proof.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/builders/godot_scene_piece_builder.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/gates/gate_player_movement_proof.py`
  - `tier2/godotsim/builders/godot_scene_piece_builder.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Builders Subsystem)
  - `tier2/godotsim/kernels/piece3d_mr.py` ➔ **Inferred Boundary Crossing:** (Builders Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/gates/gate_player_movement_visible_observer_proof.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/builders/godot_scene_piece_builder.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/gates/gate_player_movement_visible_observer_proof.py`
  - `tier2/godotsim/builders/godot_scene_piece_builder.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Builders Subsystem)
  - `tier2/godotsim/kernels/piece3d_mr.py` ➔ **Inferred Boundary Crossing:** (Builders Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/gates/gate_static_room_visible_proof.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/builders/godot_scene_piece_builder.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/gates/gate_static_room_visible_proof.py`
  - `tier2/godotsim/builders/godot_scene_piece_builder.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Builders Subsystem)
  - `tier2/godotsim/kernels/piece3d_mr.py` ➔ **Inferred Boundary Crossing:** (Builders Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/gates/gate_trigger_zone_light_off_proof.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/gates/gate_trigger_zone_light_off_proof.py`

### Static Route from entrypoint: `tier2/godotsim/gates/gate_trigger_zone_multi_trigger_light_route_proof.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/gates/gate_trigger_zone_multi_trigger_light_route_proof.py`

### Static Route from entrypoint: `tier2/godotsim/gates/gate_visible_floor_render_proof.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/piece3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/gates/gate_visible_floor_render_proof.py`
  - `tier2/godotsim/kernels/piece3d_mr.py` ➔ **Inferred Boundary Crossing:** (Gates Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/kernels/dialogue3d_mr.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/kernels/dialogue3d_mr.py`

### Static Route from entrypoint: `tier2/godotsim/kernels/inventory3d_mr.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/kernels/inventory3d_mr.py`

### Static Route from entrypoint: `tier2/godotsim/kernels/navigation_mr.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/kernels/navigation_mr.py`

### Static Route from entrypoint: `tier2/godotsim/kernels/perception_mr.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/kernels/perception_mr.py`

### Static Route from entrypoint: `tier2/godotsim/kernels/quest3d_mr.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/kernels/quest3d_mr.py`

### Static Route from entrypoint: `tier2/godotsim/scan_old_vault_paths.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/scan_old_vault_paths.py`

### Static Route from entrypoint: `tier2/godotsim/scene_extractor.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/scene_extractor.py`

### Static Route from entrypoint: `tier2/godotsim/sim_runtime.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/combat3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/sim_runtime.py`
  - `tier2/godotsim/bridge_integration.py`
  - `tier2/godotsim/semantic_bridge.py`
  - `tier2/godotsim/spatial_skin_system.py`
  - `tier2/godotsim/environment_manager.py`
  - `tier2/godotsim/http_handlers.py`
  - `tier1/engainos/aproom/canon.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/reality_mode.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/authority/local_signed_transport.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/core/intent_shadow.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Core Subsystem)
  - `tier2/godotsim/command_dispatcher.py`
  - `tier2/godotsim/runtime_core.py`
  - `tier2/godotsim/adapters/behavior_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/behavior3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/combat3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/combat3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/dialogue3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/dialogue3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/inventory3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/inventory3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/perception_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/perception_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/spatial3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/spatial3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/spatial3d.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Godotsim Subsystem)
  - `tier2/godotsim/engain_hooks.py`
  - `tier2/godotsim/protocol_envelope.py`
  - `tier2/godotsim/scene_manager.py`
  - `tier2/godotsim/scene_extractor.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Mettaext Subsystem)
  - `tier2/godotsim/slice_builders.py`
  - `tier2/godotsim/slice_types.py`
  - `tier2/godotsim/vault_manager.py`
  - `tier2/godotsim/runtime_gateway.py`
  - `tier1/engainos/aproom/ap_complex_rules.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_core.py`
  - `tier1/engainos/aproom/authority_gate.py` [STUB] ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_rule_evaluator.py`
  - `tier1/engainos/aproom/ap_rule_loader.py`
  - `tier2/godotsim/presentation_observation.py`

### Static Route from entrypoint: `tier2/godotsim/test_bridge_entities_manifestation.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/bridge_integration.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/test_bridge_entities_manifestation.py`
  - `tier2/godotsim/bridge_integration.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier2/godotsim/semantic_bridge.py`
  - `tier2/godotsim/spatial_skin_system.py`

### Static Route from entrypoint: `tier2/godotsim/test_combat3d_adapter.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/combat3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/test_combat3d_adapter.py`
  - `tier2/godotsim/adapters/combat3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/combat3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)

### Static Route from entrypoint: `tier2/godotsim/test_combat_commit.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/combat3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/test_combat_commit.py`
  - `tier1/engainos/aproom/reality_mode.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Aproom Subsystem)
  - `tier2/godotsim/runtime_core.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier1/engainos/aproom/canon.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier2/godotsim/adapters/behavior_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/behavior3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/combat3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/combat3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/dialogue3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/dialogue3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/inventory3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/inventory3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/perception_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/perception_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/spatial3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/spatial3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/spatial3d.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Godotsim Subsystem)
  - `tier2/godotsim/bridge_integration.py`
  - `tier2/godotsim/semantic_bridge.py`
  - `tier2/godotsim/spatial_skin_system.py`
  - `tier2/godotsim/command_dispatcher.py`
  - `tier2/godotsim/scene_manager.py`
  - `tier2/godotsim/scene_extractor.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Mettaext Subsystem)
  - `tier2/godotsim/engain_hooks.py`
  - `tier2/godotsim/protocol_envelope.py`
  - `tier2/godotsim/slice_builders.py`
  - `tier2/godotsim/slice_types.py`
  - `tier2/godotsim/vault_manager.py`
  - `tier2/godotsim/runtime_gateway.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier1/engainos/aproom/ap_complex_rules.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_core.py`
  - `tier1/engainos/aproom/authority_gate.py` [STUB] ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_rule_evaluator.py`
  - `tier1/engainos/aproom/ap_rule_loader.py`
  - `tier1/engainos/core/intent_shadow.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Core Subsystem)

### Static Route from entrypoint: `tier2/godotsim/test_gateway_combat_rules.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/combat3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/test_gateway_combat_rules.py`
  - `tier2/godotsim/command_dispatcher.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier2/godotsim/runtime_core.py`
  - `tier1/engainos/aproom/canon.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/reality_mode.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier2/godotsim/adapters/behavior_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/behavior3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/combat3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/combat3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/dialogue3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/dialogue3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/inventory3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/inventory3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/perception_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/perception_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/spatial3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/spatial3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/spatial3d.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Godotsim Subsystem)
  - `tier2/godotsim/bridge_integration.py`
  - `tier2/godotsim/semantic_bridge.py`
  - `tier2/godotsim/spatial_skin_system.py`
  - `tier2/godotsim/engain_hooks.py`
  - `tier2/godotsim/protocol_envelope.py`
  - `tier2/godotsim/scene_manager.py`
  - `tier2/godotsim/scene_extractor.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Mettaext Subsystem)
  - `tier2/godotsim/slice_builders.py`
  - `tier2/godotsim/slice_types.py`
  - `tier2/godotsim/vault_manager.py`
  - `tier2/godotsim/http_handlers.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier1/engainos/authority/local_signed_transport.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/core/intent_shadow.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Core Subsystem)
  - `tier2/godotsim/runtime_gateway.py`
  - `tier1/engainos/aproom/ap_complex_rules.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_core.py`
  - `tier1/engainos/aproom/authority_gate.py` [STUB] ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_rule_evaluator.py`
  - `tier1/engainos/aproom/ap_rule_loader.py`
  - `tier2/godotsim/sim_runtime.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier2/godotsim/environment_manager.py`
  - `tier2/godotsim/presentation_observation.py`

### Static Route from entrypoint: `tier2/godotsim/test_presentation_observation.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/combat3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/test_presentation_observation.py`
  - `tier1/engainos/authority/local_signed_transport.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Authority Subsystem)
  - `tier2/godotsim/http_handlers.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier1/engainos/aproom/canon.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/reality_mode.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/core/intent_shadow.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Core Subsystem)
  - `tier2/godotsim/command_dispatcher.py`
  - `tier2/godotsim/runtime_core.py`
  - `tier2/godotsim/adapters/behavior_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/behavior3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/combat3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/combat3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/dialogue3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/dialogue3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/inventory3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/inventory3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/perception_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/perception_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/spatial3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/spatial3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/spatial3d.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Godotsim Subsystem)
  - `tier2/godotsim/bridge_integration.py`
  - `tier2/godotsim/semantic_bridge.py`
  - `tier2/godotsim/spatial_skin_system.py`
  - `tier2/godotsim/engain_hooks.py`
  - `tier2/godotsim/protocol_envelope.py`
  - `tier2/godotsim/scene_manager.py`
  - `tier2/godotsim/scene_extractor.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Mettaext Subsystem)
  - `tier2/godotsim/slice_builders.py`
  - `tier2/godotsim/slice_types.py`
  - `tier2/godotsim/vault_manager.py`
  - `tier2/godotsim/runtime_gateway.py`
  - `tier1/engainos/aproom/ap_complex_rules.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_core.py`
  - `tier1/engainos/aproom/authority_gate.py` [STUB] ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_rule_evaluator.py`
  - `tier1/engainos/aproom/ap_rule_loader.py`
  - `tier2/godotsim/presentation_observation.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier2/godotsim/sim_runtime.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier2/godotsim/environment_manager.py`

### Static Route from entrypoint: `tier2/godotsim/test_scene_load_handshake.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/combat3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/test_scene_load_handshake.py`
  - `tier2/godotsim/http_handlers.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier1/engainos/aproom/canon.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/reality_mode.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/authority/local_signed_transport.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/core/intent_shadow.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Core Subsystem)
  - `tier2/godotsim/command_dispatcher.py`
  - `tier2/godotsim/runtime_core.py`
  - `tier2/godotsim/adapters/behavior_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/behavior3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/combat3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/combat3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/dialogue3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/dialogue3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/inventory3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/inventory3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/perception_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/perception_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/spatial3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/spatial3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/spatial3d.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Godotsim Subsystem)
  - `tier2/godotsim/bridge_integration.py`
  - `tier2/godotsim/semantic_bridge.py`
  - `tier2/godotsim/spatial_skin_system.py`
  - `tier2/godotsim/engain_hooks.py`
  - `tier2/godotsim/protocol_envelope.py`
  - `tier2/godotsim/scene_manager.py`
  - `tier2/godotsim/scene_extractor.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Mettaext Subsystem)
  - `tier2/godotsim/slice_builders.py`
  - `tier2/godotsim/slice_types.py`
  - `tier2/godotsim/vault_manager.py`
  - `tier2/godotsim/runtime_gateway.py`
  - `tier1/engainos/aproom/ap_complex_rules.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_core.py`
  - `tier1/engainos/aproom/authority_gate.py` [STUB] ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_rule_evaluator.py`
  - `tier1/engainos/aproom/ap_rule_loader.py`
  - `tier2/godotsim/sim_runtime.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier2/godotsim/environment_manager.py`
  - `tier2/godotsim/presentation_observation.py`

### Static Route from entrypoint: `tier2/godotsim/test_scene_provenance.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/combat3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/test_scene_provenance.py`
  - `tier2/godotsim/runtime_core.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier1/engainos/aproom/canon.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/reality_mode.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier2/godotsim/adapters/behavior_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/behavior3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/combat3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/combat3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/dialogue3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/dialogue3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/inventory3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/inventory3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/perception_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/perception_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/spatial3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/spatial3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/spatial3d.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Godotsim Subsystem)
  - `tier2/godotsim/bridge_integration.py`
  - `tier2/godotsim/semantic_bridge.py`
  - `tier2/godotsim/spatial_skin_system.py`
  - `tier2/godotsim/command_dispatcher.py`
  - `tier2/godotsim/scene_manager.py`
  - `tier2/godotsim/scene_extractor.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Mettaext Subsystem)
  - `tier2/godotsim/engain_hooks.py`
  - `tier2/godotsim/protocol_envelope.py`
  - `tier2/godotsim/slice_builders.py`
  - `tier2/godotsim/slice_types.py`
  - `tier2/godotsim/vault_manager.py`

### Static Route from entrypoint: `tier2/godotsim/test_snapshot_ownership.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/combat3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/test_snapshot_ownership.py`
  - `tier2/godotsim/http_handlers.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier1/engainos/aproom/canon.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/reality_mode.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/authority/local_signed_transport.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/core/intent_shadow.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Core Subsystem)
  - `tier2/godotsim/command_dispatcher.py`
  - `tier2/godotsim/runtime_core.py`
  - `tier2/godotsim/adapters/behavior_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/behavior3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/combat3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/combat3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/dialogue3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/dialogue3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/inventory3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/inventory3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/perception_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/perception_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/spatial3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/spatial3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/spatial3d.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Godotsim Subsystem)
  - `tier2/godotsim/bridge_integration.py`
  - `tier2/godotsim/semantic_bridge.py`
  - `tier2/godotsim/spatial_skin_system.py`
  - `tier2/godotsim/engain_hooks.py`
  - `tier2/godotsim/protocol_envelope.py`
  - `tier2/godotsim/scene_manager.py`
  - `tier2/godotsim/scene_extractor.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Mettaext Subsystem)
  - `tier2/godotsim/slice_builders.py`
  - `tier2/godotsim/slice_types.py`
  - `tier2/godotsim/vault_manager.py`
  - `tier2/godotsim/runtime_gateway.py`
  - `tier1/engainos/aproom/ap_complex_rules.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_core.py`
  - `tier1/engainos/aproom/authority_gate.py` [STUB] ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_rule_evaluator.py`
  - `tier1/engainos/aproom/ap_rule_loader.py`
  - `tier2/godotsim/sim_runtime.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier2/godotsim/environment_manager.py`
  - `tier2/godotsim/presentation_observation.py`

### Static Route from entrypoint: `tier2/godotsim/test_snapshot_peek.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/combat3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/test_snapshot_peek.py`
  - `tier1/engainos/aproom/reality_mode.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Aproom Subsystem)
  - `tier2/godotsim/http_handlers.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier1/engainos/aproom/canon.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/authority/local_signed_transport.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Authority Subsystem)
  - `tier1/engainos/core/intent_shadow.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Core Subsystem)
  - `tier2/godotsim/command_dispatcher.py`
  - `tier2/godotsim/runtime_core.py`
  - `tier2/godotsim/adapters/behavior_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/behavior3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/combat3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/combat3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/dialogue3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/dialogue3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/inventory3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/inventory3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/perception_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/perception_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/spatial3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/spatial3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/spatial3d.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Godotsim Subsystem)
  - `tier2/godotsim/bridge_integration.py`
  - `tier2/godotsim/semantic_bridge.py`
  - `tier2/godotsim/spatial_skin_system.py`
  - `tier2/godotsim/engain_hooks.py`
  - `tier2/godotsim/protocol_envelope.py`
  - `tier2/godotsim/scene_manager.py`
  - `tier2/godotsim/scene_extractor.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Mettaext Subsystem)
  - `tier2/godotsim/slice_builders.py`
  - `tier2/godotsim/slice_types.py`
  - `tier2/godotsim/vault_manager.py`
  - `tier2/godotsim/runtime_gateway.py`
  - `tier1/engainos/aproom/ap_complex_rules.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_core.py`
  - `tier1/engainos/aproom/authority_gate.py` [STUB] ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_rule_evaluator.py`
  - `tier1/engainos/aproom/ap_rule_loader.py`
  - `tier2/godotsim/sim_runtime.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier2/godotsim/environment_manager.py`
  - `tier2/godotsim/presentation_observation.py`

### Static Route from entrypoint: `tier2/godotsim/test_stageroom_scene_delivery.py`
- **Advisory Next File to Inspect in Route:** `tier2/godotsim/kernels/combat3d_mr.py`
- **Dependency Traversal Flow:**
  - `tier2/godotsim/test_stageroom_scene_delivery.py`
  - `tier1/engainos/aproom/ap_complex_rules.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_core.py`
  - `tier1/engainos/bridgeroom/stageroom_scene_resolver.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Bridgeroom Subsystem)
  - `tier2/godotsim/adapters/combat3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/combat3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/command_dispatcher.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier2/godotsim/runtime_core.py`
  - `tier1/engainos/aproom/canon.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/reality_mode.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier2/godotsim/adapters/behavior_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/behavior3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/dialogue3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/dialogue3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/inventory3d_integration.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/inventory3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/perception_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/perception_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/adapters/spatial3d_adapter.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Adapters Subsystem)
  - `tier2/godotsim/kernels/spatial3d_mr.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Kernels Subsystem)
  - `tier2/godotsim/spatial3d.py` ➔ **Inferred Boundary Crossing:** (Adapters Subsystem ➔ Godotsim Subsystem)
  - `tier2/godotsim/bridge_integration.py`
  - `tier2/godotsim/semantic_bridge.py`
  - `tier2/godotsim/spatial_skin_system.py`
  - `tier2/godotsim/engain_hooks.py`
  - `tier2/godotsim/protocol_envelope.py`
  - `tier2/godotsim/scene_manager.py`
  - `tier2/godotsim/scene_extractor.py`
  - `tier3/mettaext/scene_identity.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Mettaext Subsystem)
  - `tier2/godotsim/slice_builders.py`
  - `tier2/godotsim/slice_types.py`
  - `tier2/godotsim/vault_manager.py`
  - `tier2/godotsim/runtime_gateway.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Godotsim Subsystem)
  - `tier1/engainos/aproom/authority_gate.py` [STUB] ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Aproom Subsystem)
  - `tier1/engainos/aproom/ap_rule_evaluator.py`
  - `tier1/engainos/aproom/ap_rule_loader.py`
  - `tier1/engainos/core/intent_shadow.py` ➔ **Inferred Boundary Crossing:** (Godotsim Subsystem ➔ Core Subsystem)

### Static Route from entrypoint: `tier2/topologist/classroom/run_topologist_classroom_probe.py`
- **Advisory Next File to Inspect in Route:** `tier2/topologist/artifactroom/topology_artifact.py`
- **Dependency Traversal Flow:**
  - `tier2/topologist/classroom/run_topologist_classroom_probe.py`
  - `tier2/topologist/artifactroom/topology_artifact.py` ➔ **Inferred Boundary Crossing:** (Classroom Subsystem ➔ Artifactroom Subsystem)
  - `tier2/topologist/reckoningroom/topology_validator.py` ➔ **Inferred Boundary Crossing:** (Classroom Subsystem ➔ Reckoningroom Subsystem)

### Static Route from entrypoint: `tier2/worldfield/grid_facts_emitter.py`
- **Advisory Next File to Inspect in Route:** `tier2/worldfield/trixel_world_adapter.py`
- **Dependency Traversal Flow:**
  - `tier2/worldfield/grid_facts_emitter.py`
  - `tier2/worldfield/trixel_world_adapter.py`
  - `tier2/worldfield/terrain_thresholds.py`
  - `tier2/worldfield/world_field_nucleus.py`

### Static Route from entrypoint: `tier2/worldfield/terrain_thresholds.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier2/worldfield/terrain_thresholds.py`

### Static Route from entrypoint: `tier2/worldfield/trixel_world_adapter.py`
- **Advisory Next File to Inspect in Route:** `tier2/worldfield/terrain_thresholds.py`
- **Dependency Traversal Flow:**
  - `tier2/worldfield/trixel_world_adapter.py`
  - `tier2/worldfield/terrain_thresholds.py`
  - `tier2/worldfield/world_field_nucleus.py`

### Static Route from entrypoint: `tier2/worldfield/world_field_nucleus.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier2/worldfield/world_field_nucleus.py`

### Static Route from entrypoint: `tier3/mettaext/build_scene_index.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/build_scene_index.py`

### Static Route from entrypoint: `tier3/mettaext/chapterroom/chapterroom_index_runner.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/chapterroom/passA_chapter_intake.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/chapterroom/chapterroom_index_runner.py`
  - `tier3/mettaext/chapterroom/passA_chapter_intake.py`
  - `tier3/mettaext/chapterroom/passB5_environment_detector.py`
  - `tier3/mettaext/chapterroom/passB_scene_boundary_provider.py`
  - `tier3/mettaext/chapterroom/passC_scene_packet_writer.py`

### Static Route from entrypoint: `tier3/mettaext/chapterroom/chapterroom_runner.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/chapterroom/chapterroom_runner.py`

### Static Route from entrypoint: `tier3/mettaext/chapterroom/passA_chapter_intake.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/chapterroom/passA_chapter_intake.py`

### Static Route from entrypoint: `tier3/mettaext/chapterroom/passB5_environment_detector.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/chapterroom/passB5_environment_detector.py`

### Static Route from entrypoint: `tier3/mettaext/chapterroom/passB_scene_boundary_provider.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/chapterroom/passB_scene_boundary_provider.py`

### Static Route from entrypoint: `tier3/mettaext/chapterroom/passC_scene_packet_writer.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/chapterroom/passC_scene_packet_writer.py`

### Static Route from entrypoint: `tier3/mettaext/engain_ingest.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/pipeline_runner.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/engain_ingest.py`
  - `tier3/mettaext/pipeline_runner.py`

### Static Route from entrypoint: `tier3/mettaext/master_pipeline.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/pipeline_runner.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/master_pipeline.py`
  - `tier3/mettaext/pipeline_runner.py`

### Static Route from entrypoint: `tier3/mettaext/narrative_to_game.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/pipeline_runner.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/narrative_to_game.py`
  - `tier3/mettaext/pipeline_runner.py`

### Static Route from entrypoint: `tier3/mettaext/passroom/pass1_explicit.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/passroom/pass1_explicit.py`

### Static Route from entrypoint: `tier3/mettaext/passroom/pass1_spatial.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/passroom/pass1_spatial.py`

### Static Route from entrypoint: `tier3/mettaext/passroom/pass2_enhanced.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass2_entity_filter.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/passroom/pass2_enhanced.py`
  - `tier3/mettaext/passroom/pass2_entity_filter.py`
  - `tier3/mettaext/world_rules_loader.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/passroom/pass2_event_builder.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/passroom/pass2_event_builder.py`

### Static Route from entrypoint: `tier3/mettaext/passroom/pass3_merge.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/passroom/pass3_merge.py`

### Static Route from entrypoint: `tier3/mettaext/passroom/pass4_zon_bridge.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/semantic_environment_extractor.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/passroom/pass4_zon_bridge.py`
  - `tier3/mettaext/semantic_environment_extractor.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/passroom/pass5_game_bridge.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/semantic_environment_extractor.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/passroom/pass5_game_bridge.py`
  - `tier3/mettaext/semantic_environment_extractor.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/pipeline_runner.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/pipeline_runner.py`

### Static Route from entrypoint: `tier3/mettaext/run1time.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/pipeline_runner.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/run1time.py`
  - `tier3/mettaext/pipeline_runner.py`

### Static Route from entrypoint: `tier3/mettaext/segmenter.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/segmenter.py`

### Static Route from entrypoint: `tier3/mettaext/semantic_environment_extractor.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/semantic_environment_extractor.py`

### Static Route from entrypoint: `tier3/mettaext/stageroom_manifest.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/stageroom_manifest.py`

### Static Route from entrypoint: `tier3/mettaext/tests/test_authored_scene_boundary_splitter.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass2_entity_filter.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_authored_scene_boundary_splitter.py`
  - `tier3/mettaext/chapterroom/passA_chapter_intake.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Chapterroom Subsystem)
  - `tier3/mettaext/chapterroom/passB_scene_boundary_provider.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Chapterroom Subsystem)
  - `tier3/mettaext/chapterroom/passC_scene_packet_writer.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Chapterroom Subsystem)
  - `tier3/mettaext/passroom/pass1_explicit.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_enhanced.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_entity_filter.py`
  - `tier3/mettaext/world_rules_loader.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/tests/test_authored_scene_markers_fenced_yaml.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/chapterroom/passB_scene_boundary_provider.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_authored_scene_markers_fenced_yaml.py`
  - `tier3/mettaext/chapterroom/passB_scene_boundary_provider.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Chapterroom Subsystem)
  - `tier3/mettaext/chapterroom/passC_scene_packet_writer.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Chapterroom Subsystem)

### Static Route from entrypoint: `tier3/mettaext/tests/test_entity_evidence_lifecycle.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass2_entity_filter.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_entity_evidence_lifecycle.py`
  - `tier3/mettaext/passroom/pass1_explicit.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_enhanced.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_entity_filter.py`
  - `tier3/mettaext/world_rules_loader.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)
  - `tier3/mettaext/passroom/pass3_merge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass4_zon_bridge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/semantic_environment_extractor.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)
  - `tier3/mettaext/passroom/pass5_game_bridge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/pipeline_runner.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/tests/test_entity_filter.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass2_entity_filter.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_entity_filter.py`
  - `tier3/mettaext/passroom/pass2_enhanced.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_entity_filter.py`
  - `tier3/mettaext/world_rules_loader.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)
  - `tier3/mettaext/passroom/pass3_merge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)

### Static Route from entrypoint: `tier3/mettaext/tests/test_identity_hierarchy.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass2_entity_filter.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_identity_hierarchy.py`
  - `tier3/mettaext/chapterroom/passA_chapter_intake.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Chapterroom Subsystem)
  - `tier3/mettaext/chapterroom/passB_scene_boundary_provider.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Chapterroom Subsystem)
  - `tier3/mettaext/chapterroom/passC_scene_packet_writer.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Chapterroom Subsystem)
  - `tier3/mettaext/passroom/pass1_explicit.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_enhanced.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_entity_filter.py`
  - `tier3/mettaext/world_rules_loader.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)
  - `tier3/mettaext/passroom/pass3_merge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass4_zon_bridge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/semantic_environment_extractor.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)
  - `tier3/mettaext/passroom/pass5_game_bridge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/pipeline_runner.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/tests/test_manifest_scoping.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/stageroom_manifest.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_manifest_scoping.py`
  - `tier3/mettaext/stageroom_manifest.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/tests/test_metadata_leakage.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass4_zon_bridge.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_metadata_leakage.py`
  - `tier3/mettaext/chapterroom/passA_chapter_intake.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Chapterroom Subsystem)
  - `tier3/mettaext/chapterroom/passB_scene_boundary_provider.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Chapterroom Subsystem)
  - `tier3/mettaext/chapterroom/passC_scene_packet_writer.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Chapterroom Subsystem)
  - `tier3/mettaext/passroom/pass4_zon_bridge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/semantic_environment_extractor.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)
  - `tier3/mettaext/passroom/pass5_game_bridge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/pipeline_runner.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/tests/test_orchestration_characterization.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/chapterroom/passA_chapter_intake.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_orchestration_characterization.py`
  - `tier3/mettaext/chapterroom/chapterroom_index_runner.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Chapterroom Subsystem)
  - `tier3/mettaext/chapterroom/passA_chapter_intake.py`
  - `tier3/mettaext/chapterroom/passB5_environment_detector.py`
  - `tier3/mettaext/chapterroom/passB_scene_boundary_provider.py`
  - `tier3/mettaext/chapterroom/passC_scene_packet_writer.py`
  - `tier3/mettaext/engain_ingest.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Mettaext Subsystem)
  - `tier3/mettaext/pipeline_runner.py`
  - `tier3/mettaext/master_pipeline.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Mettaext Subsystem)
  - `tier3/mettaext/narrative_to_game.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/tests/test_pass3_pass4_entity_handoff.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass2_entity_filter.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_pass3_pass4_entity_handoff.py`
  - `tier3/mettaext/passroom/pass1_explicit.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_enhanced.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_entity_filter.py`
  - `tier3/mettaext/world_rules_loader.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)
  - `tier3/mettaext/passroom/pass3_merge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass4_zon_bridge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/semantic_environment_extractor.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/tests/test_pass4_explicit_empty_entities.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass4_zon_bridge.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_pass4_explicit_empty_entities.py`
  - `tier3/mettaext/passroom/pass4_zon_bridge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/semantic_environment_extractor.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/tests/test_pattern1_physicality_attribution.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass2_entity_filter.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_pattern1_physicality_attribution.py`
  - `tier3/mettaext/passroom/pass2_enhanced.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_entity_filter.py`
  - `tier3/mettaext/world_rules_loader.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/tests/test_pattern4_participant_seeding.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass2_entity_filter.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_pattern4_participant_seeding.py`
  - `tier3/mettaext/passroom/pass1_explicit.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_enhanced.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_entity_filter.py`
  - `tier3/mettaext/world_rules_loader.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/tests/test_scene_content_observations.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass2_entity_filter.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_scene_content_observations.py`
  - `tier3/mettaext/passroom/pass1_explicit.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_enhanced.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_entity_filter.py`
  - `tier3/mettaext/world_rules_loader.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)
  - `tier3/mettaext/passroom/pass3_merge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass4_zon_bridge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/semantic_environment_extractor.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)
  - `tier3/mettaext/passroom/pass5_game_bridge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)

### Static Route from entrypoint: `tier3/mettaext/tests/test_scene_local_manifestation.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass2_entity_filter.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/tests/test_scene_local_manifestation.py`
  - `tier3/mettaext/passroom/pass1_explicit.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_enhanced.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass2_entity_filter.py`
  - `tier3/mettaext/world_rules_loader.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)
  - `tier3/mettaext/passroom/pass3_merge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass4_zon_bridge.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Passroom Subsystem)
  - `tier3/mettaext/semantic_environment_extractor.py` ➔ **Inferred Boundary Crossing:** (Passroom Subsystem ➔ Mettaext Subsystem)

### Static Route from entrypoint: `tier3/mettaext/vaultroom/vault_source_index.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/vaultroom/vault_source_index.py`

### Static Route from entrypoint: `tier3/mettaext/world_rules_loader.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/world_rules_loader.py`

### Static Route from entrypoint: `tier3/mettaext/zw_compiler.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/zw_compiler.py`

### Static Route from entrypoint: `tier3/mettaext/zw_world_rules_compiler.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/zw_world_rules_compiler.py`

### Static Route from entrypoint: `tier3/mettaext/zwify_python.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tier3/mettaext/zwify_python.py`

### Static Route from entrypoint: `tier3/mettaextgen2/compare_legacy.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaextgen2/lib/annotations.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaextgen2/compare_legacy.py`
  - `tier3/mettaextgen2/orchestrator.py`
  - `tier3/mettaextgen2/lib/annotations.py` [STUB] ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Lib Subsystem)
  - `tier3/mettaextgen2/lib/source.py`
  - `tier3/mettaextgen2/modules/artifact_assembler.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/lib/artifact_schema.py` ➔ **Inferred Boundary Crossing:** (Modules Subsystem ➔ Lib Subsystem)
  - `tier3/mettaextgen2/lib/lane_line.py`
  - `tier3/mettaextgen2/modules/dialogue_extractor.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/entity_extractor.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/linguistic_annotator.py`
  - `tier3/mettaextgen2/modules/scene_segmenter.py`
  - `tier3/mettaextgen2/modules/metadata_reader.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/presence_detector.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/reconciler.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/source_loader.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)

### Static Route from entrypoint: `tier3/mettaextgen2/corpus_runner.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaextgen2/lib/annotations.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaextgen2/corpus_runner.py`
  - `tier3/mettaextgen2/lib/lane_line.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Lib Subsystem)
  - `tier3/mettaextgen2/modules/source_loader.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/lib/annotations.py` [STUB] ➔ **Inferred Boundary Crossing:** (Modules Subsystem ➔ Lib Subsystem)
  - `tier3/mettaextgen2/lib/source.py`
  - `tier3/mettaextgen2/orchestrator.py`
  - `tier3/mettaextgen2/modules/artifact_assembler.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/lib/artifact_schema.py` ➔ **Inferred Boundary Crossing:** (Modules Subsystem ➔ Lib Subsystem)
  - `tier3/mettaextgen2/modules/dialogue_extractor.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/entity_extractor.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/linguistic_annotator.py`
  - `tier3/mettaextgen2/modules/scene_segmenter.py`
  - `tier3/mettaextgen2/modules/metadata_reader.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/presence_detector.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/reconciler.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)

### Static Route from entrypoint: `tier3/mettaextgen2/orchestrator.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaextgen2/lib/annotations.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaextgen2/orchestrator.py`
  - `tier3/mettaextgen2/lib/annotations.py` [STUB] ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Lib Subsystem)
  - `tier3/mettaextgen2/lib/source.py`
  - `tier3/mettaextgen2/modules/artifact_assembler.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/lib/artifact_schema.py` ➔ **Inferred Boundary Crossing:** (Modules Subsystem ➔ Lib Subsystem)
  - `tier3/mettaextgen2/lib/lane_line.py`
  - `tier3/mettaextgen2/modules/dialogue_extractor.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/entity_extractor.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/linguistic_annotator.py`
  - `tier3/mettaextgen2/modules/scene_segmenter.py`
  - `tier3/mettaextgen2/modules/metadata_reader.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/presence_detector.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/reconciler.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/source_loader.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)

### Static Route from entrypoint: `tier3/mettaextgen2/tests/test_gen2_grammar.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaextgen2/lib/annotations.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaextgen2/tests/test_gen2_grammar.py`
  - `tier3/mettaextgen2/lib/annotations.py` [STUB] ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Lib Subsystem)
  - `tier3/mettaextgen2/lib/source.py`
  - `tier3/mettaextgen2/lib/artifact_schema.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Lib Subsystem)
  - `tier3/mettaextgen2/lib/lane_line.py`
  - `tier3/mettaextgen2/modules/artifact_assembler.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Modules Subsystem)
  - `tier3/mettaextgen2/orchestrator.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Mettaextgen2 Subsystem)
  - `tier3/mettaextgen2/modules/dialogue_extractor.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/entity_extractor.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/linguistic_annotator.py`
  - `tier3/mettaextgen2/modules/scene_segmenter.py`
  - `tier3/mettaextgen2/modules/metadata_reader.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/presence_detector.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/reconciler.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/source_loader.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)

### Static Route from entrypoint: `tier3/mettaextgen2/tests/test_gen2_scene_048_5.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaextgen2/lib/annotations.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaextgen2/tests/test_gen2_scene_048_5.py`
  - `tier3/mettaextgen2/compare_legacy.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Mettaextgen2 Subsystem)
  - `tier3/mettaextgen2/orchestrator.py`
  - `tier3/mettaextgen2/lib/annotations.py` [STUB] ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Lib Subsystem)
  - `tier3/mettaextgen2/lib/source.py`
  - `tier3/mettaextgen2/modules/artifact_assembler.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/lib/artifact_schema.py` ➔ **Inferred Boundary Crossing:** (Modules Subsystem ➔ Lib Subsystem)
  - `tier3/mettaextgen2/lib/lane_line.py`
  - `tier3/mettaextgen2/modules/dialogue_extractor.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/entity_extractor.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/linguistic_annotator.py`
  - `tier3/mettaextgen2/modules/scene_segmenter.py`
  - `tier3/mettaextgen2/modules/metadata_reader.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/presence_detector.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/reconciler.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/source_loader.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)

### Static Route from entrypoint: `tier3/mettaextgen2/tests/test_gen2_units.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaextgen2/lib/annotations.py`
- **Dependency Traversal Flow:**
  - `tier3/mettaextgen2/tests/test_gen2_units.py`
  - `tier3/mettaextgen2/lib/annotations.py` [STUB] ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Lib Subsystem)
  - `tier3/mettaextgen2/lib/source.py`
  - `tier3/mettaextgen2/lib/artifact_schema.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Lib Subsystem)
  - `tier3/mettaextgen2/lib/lane_line.py`
  - `tier3/mettaextgen2/modules/artifact_assembler.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/entity_extractor.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/linguistic_annotator.py`
  - `tier3/mettaextgen2/modules/scene_segmenter.py`
  - `tier3/mettaextgen2/modules/metadata_reader.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/presence_detector.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/reconciler.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Modules Subsystem)
  - `tier3/mettaextgen2/orchestrator.py` ➔ **Inferred Boundary Crossing:** (Testing Suite ➔ Mettaextgen2 Subsystem)
  - `tier3/mettaextgen2/modules/dialogue_extractor.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)
  - `tier3/mettaextgen2/modules/source_loader.py` ➔ **Inferred Boundary Crossing:** (Mettaextgen2 Subsystem ➔ Modules Subsystem)

### Static Route from entrypoint: `tools/gameproof/run_gameproof_001.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tools/gameproof/run_gameproof_001.py`

### Static Route from entrypoint: `tools/gameproof/run_gameproof_002.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tools/gameproof/run_gameproof_002.py`

### Static Route from entrypoint: `tools/gameproof/run_gameproof_003.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/chapterroom/passA_chapter_intake.py`
- **Dependency Traversal Flow:**
  - `tools/gameproof/run_gameproof_003.py`
  - `tier3/mettaext/chapterroom/chapterroom_bridge.py` ➔ **Inferred Boundary Crossing:** (Gameproof Subsystem ➔ Chapterroom Subsystem)
  - `tier3/mettaext/chapterroom/passA_chapter_intake.py`
  - `tier3/mettaext/chapterroom/passB_scene_boundary_provider.py`
  - `tier3/mettaext/chapterroom/passC_scene_packet_writer.py`

### Static Route from entrypoint: `tools/gameproof/run_gameproof_004.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass1_explicit.py`
- **Dependency Traversal Flow:**
  - `tools/gameproof/run_gameproof_004.py`
  - `tier3/mettaext/passroom/passroom_bridge.py` ➔ **Inferred Boundary Crossing:** (Gameproof Subsystem ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass1_explicit.py`

### Static Route from entrypoint: `tools/gameproof/run_gameproof_005.py`
- **Advisory Next File to Inspect in Route:** `tier3/mettaext/passroom/pass1_explicit.py`
- **Dependency Traversal Flow:**
  - `tools/gameproof/run_gameproof_005.py`
  - `tier3/mettaext/passroom/pass1_spatial.py` ➔ **Inferred Boundary Crossing:** (Gameproof Subsystem ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/passroom_bridge.py` ➔ **Inferred Boundary Crossing:** (Gameproof Subsystem ➔ Passroom Subsystem)
  - `tier3/mettaext/passroom/pass1_explicit.py`

### Static Route from entrypoint: `tools/gameproof/run_gameproof_006.py`
- **Advisory Next File to Inspect in Route:** `tier2/topologist/gates/gate_accept_proposed_topology_artifact.py`
- **Dependency Traversal Flow:**
  - `tools/gameproof/run_gameproof_006.py`
  - `tier2/topologist/gates/gate_accept_proposed_topology_artifact.py` ➔ **Inferred Boundary Crossing:** (Gameproof Subsystem ➔ Gates Subsystem)

### Static Route from entrypoint: `tools/gameproof/run_gameproof_007.py`
- **Advisory Next File to Inspect in Route:** `tier2/cartographer/layoutroom/topology_metric_layout_solver.py`
- **Dependency Traversal Flow:**
  - `tools/gameproof/run_gameproof_007.py`
  - `tier2/cartographer/gates/gate_propose_metric_layout.py` ➔ **Inferred Boundary Crossing:** (Gameproof Subsystem ➔ Gates Subsystem)
  - `tier2/cartographer/layoutroom/topology_metric_layout_solver.py` ➔ **Inferred Boundary Crossing:** (Gameproof Subsystem ➔ Layoutroom Subsystem)
  - `tier2/cartographer/artifactroom/metric_layout_artifact.py` ➔ **Inferred Boundary Crossing:** (Layoutroom Subsystem ➔ Artifactroom Subsystem)
  - `tier2/cartographer/reckoningroom/metric_layout_validator.py` ➔ **Inferred Boundary Crossing:** (Gameproof Subsystem ➔ Reckoningroom Subsystem)

### Static Route from entrypoint: `tools/gameproof/run_gameproof_008.py`
- **Advisory Next File to Inspect in Route:** `tier1/mrlore/gates/gate_narrative_concurrence.py`
- **Dependency Traversal Flow:**
  - `tools/gameproof/run_gameproof_008.py`
  - `tier1/mrlore/gates/gate_narrative_concurrence.py` ➔ **Inferred Boundary Crossing:** (Gameproof Subsystem ➔ Gates Subsystem)
  - `tier1/mrlore/mrlore_narrative_concurrence_checker.py` ➔ **Inferred Boundary Crossing:** (Gameproof Subsystem ➔ Mrlore Subsystem)

### Static Route from entrypoint: `tools/ollama_diff_patcher.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tools/ollama_diff_patcher.py`

### Static Route from entrypoint: `tools/passB_fix/passB_day_boundary_runner.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tools/passB_fix/passB_day_boundary_runner.py`

### Static Route from entrypoint: `tools/retired/ollama_patcher.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tools/retired/ollama_patcher.py`

### Static Route from entrypoint: `tools/stop_stack_safe.py`
- **Advisory Next File to Inspect in Route:** `None`
- **Dependency Traversal Flow:**
  - `tools/stop_stack_safe.py`

## Source Defects and Analysis Limitations
### Source defects
- `out of root/okarchitect/okarchitect_engine.py`: SyntaxError: invalid character '–' (U+2013) (okarchitect_engine.py, line 2)
### Analysis limitations: files Atlas could not read
None.
### Analysis limitations: unresolved imports (possible dependencies, not counted)
- `out of root/gui/archive_gui/official_zw_spec_rules.py` imports `core.zw_core.parse_zw`: candidates `out of root/core/zw_core.py`, `tier1/engainos/core/zw_core.py`
- `out of root/gui/archive_gui/official_zw_validator.py` imports `core.zw_core.parse_zw`: candidates `out of root/core/zw_core.py`, `tier1/engainos/core/zw_core.py`
- `out of root/gui/archive_gui/zw.py` imports `official_zw_validator.ZWValidationError`: candidates `out of root/gui/archive_gui/official_zw_validator.py`, `out of root/gui/official_zw_validator.py`
- `out of root/gui/archive_gui/zw.py` imports `official_zw_validator.ZWValidator`: candidates `out of root/gui/archive_gui/official_zw_validator.py`, `out of root/gui/official_zw_validator.py`
- `out of root/gui/official_zw_spec_rules.py` imports `core.zw_core.parse_zw`: candidates `out of root/core/zw_core.py`, `tier1/engainos/core/zw_core.py`
- `out of root/gui/official_zw_validator.py` imports `core.zw_core.parse_zw`: candidates `out of root/core/zw_core.py`, `tier1/engainos/core/zw_core.py`
- `out of root/gui/old_zw_gui_enhanced.py` imports `core.zw_core.parse_zw`: candidates `out of root/core/zw_core.py`, `tier1/engainos/core/zw_core.py`
- `out of root/gui/zw_gui.py` imports `core.zw_core.parse_zw`: candidates `out of root/core/zw_core.py`, `tier1/engainos/core/zw_core.py`
- `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/bash.py` imports `base.CLIResult`: candidates `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/ckg/base.py`
- `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/bash.py` imports `base.ToolError`: candidates `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/ckg/base.py`
- `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/bash.py` imports `base.ToolResult`: candidates `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/ckg/base.py`
- `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/edit.py` imports `base.CLIResult`: candidates `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/ckg/base.py`
- `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/edit.py` imports `base.ToolError`: candidates `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/ckg/base.py`
- `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/edit.py` imports `base.ToolResult`: candidates `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/ckg/base.py`
- `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/edit.py` imports `run.maybe_truncate`: candidates `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/run.py`, `out of root/trae/trae-agent-main/trae_agent/tools/run.py`
- `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/edit.py` imports `run.run`: candidates `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/run.py`, `out of root/trae/trae-agent-main/trae_agent/tools/run.py`
- `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/execute_bash.py` imports `base.ToolError`: candidates `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/ckg/base.py`
- `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/execute_str_replace_editor.py` imports `base.ToolError`: candidates `out of root/trae/trae-agent-main/evaluation/patch_selection/trae_selector/tools/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/base.py`, `out of root/trae/trae-agent-main/trae_agent/tools/ckg/base.py`

## 5. Limitations
- **Static analysis cannot resolve dynamic imports (e.g. __import__, importlib, or dynamic string execution).**
  - **Claim Type:** gap
  - **Confidence:** High

- **Reflection and dynamic attribute retrieval may hide runtime dependencies.**
  - **Claim Type:** gap
  - **Confidence:** High

- **Static route paths are inferred from import syntax, not runtime-verified.**
  - **Claim Type:** gap
  - **Confidence:** Medium

- **Namespace packages without __init__.py are supported, but an import matching multiple scanned files is listed in unresolved_imports and contributes no dependency edge, so inbound counts and reachability are lower bounds.**
  - **Claim Type:** gap
  - **Confidence:** High
