# Repository structure: EngAIn

> Source-level architectural map: static evidence, not runtime confirmation.
> Structure diagram: containment only. No arrows are drawn; placement does not imply dependency or communication.

- Scanned at: 2026-11-13T15:06:40.208227Z
- Profile: `/mnt/data-drive/EngAIn_Recovery/07_TMP/claude-1000/-home-mytruelove-Desktop-burdens-of-a-forgotten-past-EngAIn/3fbe832b-7a92-403a-aaa2-5abc709740c9/scratchpad/atlas_slice/engain.profile.lifecycle-draft.json` (sha256 `f1344294f3b3432d2173855352c523c3992e3216aabb807346052fc6a72f2f0c`)
- Systems, components and externals are **declared** by the profile; file counts are from the scan.

```mermaid
%% Source-level architectural map: static evidence, not runtime confirmation.
%% Structure diagram: containment only. No arrows are drawn; placement does not imply dependency or communication.
flowchart TB
  subgraph r_4efa9e22eb3a["EngAIn · scanned repository"]
    direction LR
    subgraph s_59af8ff309b7["EngAInOS · system · 158 files"]
      direction TB
      c_85f2f4f027e3["adapters · 1 file"]
      c_a43a685da598["aproom · 16 files"]
      c_43f2ac8730b5["archive · 2 files"]
      c_764c3f340a7c["authority · 5 files"]
      c_0c54825cdca4["bridgeroom · 22 files"]
      c_ed565da1f434["core · 16 files"]
      c_50971acd4db5["gates · 40 files"]
      c_e011a0ead667["relays · 2 files"]
      c_1c3f635113a8["server · 3 files"]
      c_a36adbe2fa64["tests · 31 files"]
      c_c170ffecc83b["tools · 12 files"]
      c_0e6bb589944d["validators · 3 files"]
      u_59af8ff309b7["not in a declared component · 5 files"]
    end
    subgraph s_d0affc8f22e3["Godotsim · system · 67 files"]
      direction TB
      c_9631ecf9aa68["adapters · 9 files"]
      c_b92629076816["builders · 1 file"]
      c_fec89fecfdb3["gates · 13 files"]
      c_aaced6f60e2a["kernels · 10 files"]
      c_c9f8964fe922["mechanics · 0 files"]
      c_0bbf93abff5b["scripts · 0 files"]
      u_d0affc8f22e3["not in a declared component · 34 files"]
    end
    subgraph s_e7808b1ec26e["MrLore · system · 113 files"]
      direction TB
      u_e7808b1ec26e["not in a declared component · 113 files"]
    end
    subgraph s_b0c3748d9000["Paradox Machine · system · 28 files"]
      direction TB
      u_b0c3748d9000["not in a declared component · 28 files"]
    end
    subgraph s_64e75f1a4029["Engionality · system · 25 files"]
      direction TB
      u_64e75f1a4029["not in a declared component · 25 files"]
    end
    subgraph s_d4a75d122195["Worldfield · system · 5 files"]
      direction TB
      u_d4a75d122195["not in a declared component · 5 files"]
    end
    subgraph s_ff40a034d9bd["Cartographer · system · 9 files"]
      direction TB
      u_ff40a034d9bd["not in a declared component · 9 files"]
    end
    subgraph s_7747e4ae88e2["Topologist · system · 9 files"]
      direction TB
      u_7747e4ae88e2["not in a declared component · 9 files"]
    end
    subgraph s_6f8ab8f7f4bc["Mettaext · system · 51 files"]
      direction TB
      u_6f8ab8f7f4bc["not in a declared component · 51 files"]
    end
    subgraph s_d619531ded0a["Mettaext Gen2 · system · 23 files"]
      direction TB
      u_d619531ded0a["not in a declared component · 23 files"]
    end
    o_4efa9e22eb3a["outside declared systems · 240 files"]
  end
  x_312740102b8d["Trixel3.2D · external · not scanned · 4 declared bridge files in repository"]
  classDef system fill:#eef4ff,stroke:#4a6fa5
  classDef external fill:#f4f4f4,stroke:#888888
  classDef gap fill:#fff8e6,stroke:#b08a2e
  class s_59af8ff309b7 system
  class s_d0affc8f22e3 system
  class s_e7808b1ec26e system
  class s_b0c3748d9000 system
  class s_64e75f1a4029 system
  class s_d4a75d122195 system
  class s_ff40a034d9bd system
  class s_7747e4ae88e2 system
  class s_6f8ab8f7f4bc system
  class s_d619531ded0a system
  class x_312740102b8d external
  class o_4efa9e22eb3a gap
```

## Declared systems

| System | Roots | Files | Components | Not in a component |
|---|---|---|---|---|
| EngAInOS | `tier1/engainos` | 158 | adapters (1), aproom (16), archive (2), authority (5), bridgeroom (22), core (16), gates (40), relays (2), server (3), tests (31), tools (12), validators (3) | 5 |
| Godotsim | `tier2/godotsim` | 67 | adapters (9), builders (1), gates (13), kernels (10), mechanics (0), scripts (0) | 34 |
| MrLore | `tier1/mrlore` | 113 | none declared | 113 |
| Paradox Machine | `tier1/paradox_machine` | 28 | none declared | 28 |
| Engionality | `tier2/engionality` | 25 | none declared | 25 |
| Worldfield | `tier2/worldfield` | 5 | none declared | 5 |
| Cartographer | `tier2/cartographer` | 9 | none declared | 9 |
| Topologist | `tier2/topologist` | 9 | none declared | 9 |
| Mettaext | `tier3/mettaext` | 51 | none declared | 51 |
| Mettaext Gen2 | `tier3/mettaextgen2` | 23 | none declared | 23 |

## Declared externals

| External | Scanned | Bridge patterns | Bridge files found in repository |
|---|---|---|---|
| Trixel3.2D | no | `tier1/engainos/bridgeroom/trixel32d_*.py` | 4 |

## Declared lifecycle

Declared by the profile, separately from system membership. Paths with no declaration are `undeclared`.

| State | Files |
|---|---|
| active | 412 |
| retired | 0 |
| archived | 184 |
| undeclared | 132 |

## Import coupling between declared systems

> static import dependency between declared systems; not communication and not runtime use. Shares are of the pair's resolved edges; possible edges (unresolved imports) are listed apart and not counted.

| From | To | Edges | By source lifecycle | Main source files (share) | Possible edges |
|---|---|---|---|---|---|
| (outside declared systems) | EngAInOS | 22 | archived 1, undeclared 21 | `executors/trixel32d_complete_edge_loop_proof_v1.py` 22.7%<br>`executors/trixel32d_editor_handshake_proof_v1.py` 22.7%<br>`executors/trixel32d_request_loop_proof_v1.py` 22.7% | 6 |
| Godotsim | EngAInOS | 17 | active 17 | `tier2/godotsim/runtime_gateway.py` 29.4%<br>`tier2/godotsim/http_handlers.py` 23.5%<br>`tier2/godotsim/runtime_core.py` 11.8% | 0 |
| (outside declared systems) | Engionality | 15 | archived 15 | `out of root/tools/proofroom/engionality_showroom/probe_animation_engine.py` 20.0%<br>`out of root/tools/proofroom/engionality_showroom/probe_audio_engine.py` 20.0%<br>`out of root/tools/proofroom/engionality_showroom/probe_dialogue_engine.py` 20.0% | 0 |
| EngAInOS | (outside declared systems) | 10 | active 10 | `tier1/engainos/engainos_control_center.py` 10.0%<br>`tier1/engainos/gates/gate_acceptance_rule.py` 10.0%<br>`tier1/engainos/gates/gate_declared_truth_shape.py` 10.0% | 0 |
| Engionality | (outside declared systems) | 10 | active 10 | `tier2/engionality/engionality_control_center.py` 10.0%<br>`tier2/engionality/gates/gate_affect_packet_relationships.py` 10.0%<br>`tier2/engionality/gates/gate_affect_state_valid.py` 10.0% | 0 |
| MrLore | (outside declared systems) | 10 | active 10 | `tier1/mrlore/gates/gate_claims_structure.py` 10.0%<br>`tier1/mrlore/gates/gate_contradiction_stop_proof.py` 10.0%<br>`tier1/mrlore/gates/gate_contradictions_valid_if_present.py` 10.0% | 0 |
| EngAInOS | Godotsim | 9 | active 9 | `tier1/engainos/tests/test_trixel32d_semantic_integration.py` 44.4%<br>`tier1/engainos/bridgeroom/quest3d_integration.py` 11.1%<br>`tier1/engainos/bridgeroom/zon_bridge.py` 11.1% | 0 |
| (outside declared systems) | Mettaext | 6 | archived 2, undeclared 4 | `tools/gameproof/run_gameproof_005.py` 33.3%<br>`out of root/engain/semantic/extraction.py` 16.7%<br>`out of root/tools/scene_identity_audit.py` 16.7% | 0 |
| (outside declared systems) | Godotsim | 4 | archived 4 | `out of root/engain/kernels/navigation.py` 25.0%<br>`out of root/engain/kernels/perception.py` 25.0%<br>`out of root/engain/kernels/spatial.py` 25.0% | 0 |
| (outside declared systems) | Cartographer | 3 | undeclared 3 | `tools/gameproof/run_gameproof_007.py` 100.0% | 0 |
| Godotsim | Mettaext | 3 | active 3 | `tier2/godotsim/http_handlers.py` 33.3%<br>`tier2/godotsim/scene_manager.py` 33.3%<br>`tier2/godotsim/sim_runtime.py` 33.3% | 0 |
| (outside declared systems) | MrLore | 2 | undeclared 2 | `tools/gameproof/run_gameproof_008.py` 100.0% | 0 |
| (outside declared systems) | Paradox Machine | 2 | undeclared 2 | `scratch/test_temporal_contradiction.py` 100.0% | 0 |
| EngAInOS | Worldfield | 2 | active 2 | `tier1/engainos/tests/test_trixel32d_request_assembler.py` 100.0% | 0 |
| (outside declared systems) | Topologist | 1 | undeclared 1 | `tools/gameproof/run_gameproof_006.py` 100.0% | 0 |
| EngAInOS | Mettaext | 1 | active 1 | `tier1/engainos/bridgeroom/scene_loader.py` 100.0% | 0 |
| Godotsim | (outside declared systems) | 1 | active 1 | `tier2/godotsim/gates/gate_ollama_diff_patcher_tests.py` 100.0% | 0 |

## Scan coverage

| Mechanism | Scanned | Scope |
|---|---|---|
| python_import | yes | static import / from-import statements in .py files |
| function_return_to_argument | yes | function return value passed to another function's argument |
| file_write_to_file_read | yes | writer and reader of the same literal file path |
| http | no | HTTP routes and clients |
| subprocess | no | subprocess invocations |
| external_repository | no | code outside the scanned root |
| non_python_sources | no | GDScript, JSON contracts and other non-Python files |

- Files outside declared systems: 240
- Files with parse gaps: 1
- Files with unresolved imports (possible dependencies not drawn): 11
